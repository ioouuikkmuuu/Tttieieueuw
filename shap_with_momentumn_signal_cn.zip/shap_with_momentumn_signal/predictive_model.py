import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
import warnings
import sys
warnings.filterwarnings('ignore')

# 导入配置
import config


def load_data(index_name='hs300'):
    """
    加载指数数据
    :param index_name: 指数名称，'hs300' 或 'csi800'
    :return: DataFrame
    """
    file_path = f'data/{index_name}_daily_returns.csv'
    df = pd.read_csv(file_path)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    return df


def calculate_momentum_signals(df, short_window=5, medium_window=66, long_window=252):
    """
    计算三个动量信号：短期、中期、长期
    :param df: 包含日期和收益率的DataFrame
    :param short_window: 短期窗口大小
    :param medium_window: 中期窗口大小
    :param long_window: 长期窗口大小
    :return: 包含动量信号的DataFrame
    """
    # 短期动量：过去short_window个交易日的绝对收益除以波动率
    short_term_return = df['return'].rolling(window=short_window).sum()
    short_term_volatility = df['return'].rolling(window=short_window).std()
    df['short_momentum'] = short_term_return / short_term_volatility
    
    # 中期动量：过去medium_window个交易日的绝对收益除以波动率
    medium_term_return = df['return'].rolling(window=medium_window).sum()
    medium_term_volatility = df['return'].rolling(window=medium_window).std()
    df['medium_momentum'] = medium_term_return / medium_term_volatility
    
    # 长期动量：过去long_window个交易日的绝对收益除以波动率
    long_term_return = df['return'].rolling(window=long_window).sum()
    long_term_volatility = df['return'].rolling(window=long_window).std()
    df['long_momentum'] = long_term_return / long_term_volatility
    
    return df


def create_target_variable(df, future_days=5):
    """
    创建目标变量：未来5个交易日的回报
    :param df: 包含收益率的DataFrame
    :param future_days: 未来天数
    :return: 包含目标变量的DataFrame
    """
    df['future_return'] = df['return'].shift(-future_days).rolling(window=future_days).sum()
    return df


def prepare_features_and_target(df):
    """
    准备特征和目标变量
    :param df: 包含所有数据的DataFrame
    :return: 特征和目标变量
    """
    # 删除包含NaN的行
    df = df.dropna()
    
    # 选择特征
    features = ['short_momentum', 'medium_momentum', 'long_momentum']
    X = df[features]
    y = df['future_return']
    
    return X, y


def train_model(X, y):
    """
    训练随机森林回归模型
    :param X: 特征
    :param y: 目标变量
    :return: 训练好的模型
    """
    # 分割训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # 创建并训练模型
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    # 预测
    y_pred = model.predict(X_test)
    
    # 计算均方误差
    mse = mean_squared_error(y_test, y_pred)
    print(f"模型均方误差: {mse}")
    
    return model, X_test, y_test, y_pred


def calculate_information_ratio(y_true, y_pred):
    """
    计算信息比率（IR）
    :param y_true: 真实值
    :param y_pred: 预测值
    :return: 信息比率
    """
    # 计算预测误差
    residuals = y_true - y_pred
    
    # 计算平均误差
    mean_residual = np.mean(residuals)
    
    # 计算误差的标准差
    std_residual = np.std(residuals)
    
    # 计算信息比率
    if std_residual != 0:
        ir = mean_residual / std_residual
    else:
        ir = 0
    
    return ir


def optimize_momentum_parameters(df, future_days=5):
    """
    优化动量信号参数以最大化信息比率
    :param df: 包含收益率的DataFrame
    :param future_days: 未来天数
    :return: 最佳参数组合和对应的IR值
    """
    best_ir = -np.inf
    best_params = None
    
    # 定义参数搜索范围
    short_windows = [3, 5, 10]
    medium_windows = [20, 66, 120]
    long_windows = [120, 252, 300]
    
    total_combinations = len(short_windows) * len(medium_windows) * len(long_windows)
    print(f"开始优化参数，总共需要测试 {total_combinations} 种组合...")
    
    count = 0
    for short_window in short_windows:
        for medium_window in medium_windows:
            for long_window in long_windows:
                # 确保窗口大小递增
                if short_window < medium_window < long_window:
                    count += 1
                    print(f"测试参数组合 {count}/{total_combinations}: 短期={short_window}, 中期={medium_window}, 长期={long_window}")
                    
                    # 复制数据以避免修改原始数据
                    df_copy = df.copy()
                    
                    # 计算动量信号
                    df_copy = calculate_momentum_signals(df_copy, short_window, medium_window, long_window)
                    
                    # 创建目标变量
                    df_copy = create_target_variable(df_copy, future_days)
                    
                    # 准备特征和目标变量
                    X, y = prepare_features_and_target(df_copy)
                    
                    # 如果数据量不足，跳过这个参数组合
                    if len(X) < 10:
                        continue
                    
                    # 分割训练集和测试集
                    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
                    
                    # 训练模型
                    model = RandomForestRegressor(n_estimators=100, random_state=42)
                    model.fit(X_train, y_train)
                    
                    # 预测
                    y_pred = model.predict(X_test)
                    
                    # 计算信息比率
                    ir = calculate_information_ratio(y_test, y_pred)
                    
                    # 更新最佳参数
                    if ir > best_ir:
                        best_ir = ir
                        best_params = (short_window, medium_window, long_window)
                        print(f"发现更好的参数组合: 短期={short_window}, 中期={medium_window}, 长期={long_window}, IR={ir}")
    
    return best_params, best_ir


def main():
    """
    主函数
    """
    # 加载数据
    print("加载数据...")
    df = load_data(config.INDEX_NAME)
    
    # 优化动量信号参数
    print("优化动量信号参数...")
    best_params, best_ir = optimize_momentum_parameters(df, config.FUTURE_DAYS)
    
    if best_params:
        short_window, medium_window, long_window = best_params
        print(f"\n最佳参数组合:")
        print(f"短期窗口: {short_window}")
        print(f"中期窗口: {medium_window}")
        print(f"长期窗口: {long_window}")
        print(f"最佳IR值: {best_ir}")
        
        # 使用最佳参数重新计算动量信号
        print("\n使用最佳参数重新计算动量信号...")
        df = calculate_momentum_signals(df, short_window, medium_window, long_window)
        
        # 创建目标变量
        print("创建目标变量...")
        df = create_target_variable(df, config.FUTURE_DAYS)
        
        # 准备特征和目标变量
        print("准备特征和目标变量...")
        X, y = prepare_features_and_target(df)
        
        # 训练模型
        print("训练模型...")
        model, X_test, y_test, y_pred = train_model(X, y)
        
        # 计算信息比率
        print("计算信息比率...")
        ir = calculate_information_ratio(y_test, y_pred)
        print(f"模型信息比率 (IR): {ir}")
        
        # 输出特征重要性
        feature_names = ['短期动量', '中期动量', '长期动量']
        importances = model.feature_importances_
        print("\n特征重要性:")
        for name, importance in zip(feature_names, importances):
            print(f"{name}: {importance}")
    else:
        print("未能找到有效的参数组合")


if __name__ == "__main__":
    main()