import tushare as ts
import pandas as pd
import numpy as np
from datetime import datetime

# 设置Tushare API token（需要在Tushare官网注册获取）
# 请访问 https://tushare.pro/ 注册账号并获取token
ts.set_token('2876ea85cb005fb5fa17c809a98174f2d5aae8b1f830110a5ead6211')
pro = ts.pro_api()

# 注意：以下代码需要有效的Tushare token才能运行

def generate_sample_data():
    """生成示例数据以演示CSV文件格式"""
    # 生成2015年12月到当前日期的日期序列
    start_date = '2015-12-01'
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    # 创建日期范围
    dates = pd.date_range(start=start_date, end=end_date, freq='D')
    dates = dates[dates.weekday < 5]  # 只保留工作日
    
    # 生成HS300和中证800的模拟收益率数据
    n_days = len(dates)
    hs300_returns = pd.Series(
        data=np.random.normal(0, 0.02, n_days),  # 均值0，标准差2%的正态分布
        index=dates,
        name='hs300_return'
    )
    
    cs800_returns = pd.Series(
        data=np.random.normal(0, 0.02, n_days),  # 均值0，标准差2%的正态分布
        index=dates,
        name='cs800_return'
    )
    
    # 合并数据
    df = pd.DataFrame({
        'date': dates,
        'hs300_return': hs300_returns.values,
        'cs800_return': cs800_returns.values
    })
    
    return df

def fetch_hs300_data():
    """获取HS300指数数据（需要有效的Tushare token）"""
    # 获取HS300指数数据
    # 设置结束日期为今天
    end_date = datetime.now().strftime('%Y%m%d')
    hs300 = pro.index_daily(ts_code='000300.SH', start_date='20151201', end_date=end_date)
    
    # 打印原始数据的最后几行，检查是否包含未来日期
    print("HS300原始数据的最后5行:")
    print(hs300[['trade_date', 'close']].tail())
    
    # 转换日期格式
    hs300['date_obj'] = pd.to_datetime(hs300['trade_date'], format='%Y%m%d')
    
    # 过滤掉未来日期的数据
    today = pd.to_datetime('today').date()
    print("今天日期:", today)
    print("HS300数据中的最大日期:", hs300['date_obj'].max().date())
    print("过滤前HS300数据条数:", len(hs300))
    # 确保过滤条件正确应用
    hs300_filtered = hs300[hs300['date_obj'].dt.date <= today].copy()
    print("过滤后HS300数据条数:", len(hs300_filtered))
    # 检查过滤后的数据
    print("过滤后HS300数据中的最大日期:", hs300_filtered['date_obj'].max().date())
    hs300 = hs300_filtered
    
    # 计算每日收益率
    hs300.sort_values('trade_date', inplace=True)
    hs300['return'] = hs300['close'].pct_change()
    hs300['date'] = pd.to_datetime(hs300['trade_date'], format='%Y%m%d')
    hs300 = hs300[['date', 'return']]
    print("HS300转换日期格式后的最后5行（排序前）:")
    print(hs300.tail())
    print("HS300转换日期格式后的前5行（排序前）:")
    print(hs300.head())
    
    # 按日期排序
    hs300.sort_values('date', inplace=True)
    print("HS300排序后的最后5行:")
    print(hs300.tail())
    print("HS300排序后的前5行:")
    print(hs300.head())
    
    return hs300

def fetch_csi800_data():
    """获取中证800指数数据（需要有效的Tushare token）"""
    # 获取中证800指数数据
    # 设置结束日期为今天
    end_date = datetime.now().strftime('%Y%m%d')
    csi800 = pro.index_daily(ts_code='000906.SH', start_date='20151201', end_date=end_date)
    
    # 打印原始数据的最后几行，检查是否包含未来日期
    print("中证800原始数据的最后5行:")
    print(csi800[['trade_date', 'close']].tail())
    
    # 转换日期格式
    csi800['date_obj'] = pd.to_datetime(csi800['trade_date'], format='%Y%m%d')
    
    # 过滤掉未来日期的数据
    today = pd.to_datetime('today').date()
    print("今天日期:", today)
    print("中证800数据中的最大日期:", csi800['date_obj'].max().date())
    print("过滤前中证800数据条数:", len(csi800))
    # 确保过滤条件正确应用
    csi800_filtered = csi800[csi800['date_obj'].dt.date <= today].copy()
    print("过滤后中证800数据条数:", len(csi800_filtered))
    # 检查过滤后的数据
    print("过滤后中证800数据中的最大日期:", csi800_filtered['date_obj'].max().date())
    csi800 = csi800_filtered
    
    # 计算每日收益率
    csi800.sort_values('trade_date', inplace=True)
    csi800['return'] = csi800['close'].pct_change()
    csi800['date'] = pd.to_datetime(csi800['trade_date'], format='%Y%m%d')
    csi800 = csi800[['date', 'return']]
    print("中证800转换日期格式后的最后5行（排序前）:")
    print(csi800.tail())
    print("中证800转换日期格式后的前5行（排序前）:")
    print(csi800.head())
    
    # 按日期排序
    csi800.sort_values('date', inplace=True)
    print("中证800排序后的最后5行:")
    print(csi800.tail())
    print("中证800排序后的前5行:")
    print(csi800.head())
    
    return csi800

def save_to_csv(df, filename):
    """保存数据到CSV文件"""
    df.to_csv(filename, index=False)
    print(f"数据已保存到 {filename}")

if __name__ == "__main__":
    # 获取HS300数据
    hs300_data = fetch_hs300_data()
    
    # 保存HS300数据到CSV文件
    save_to_csv(hs300_data, 'data/hs300_daily_returns.csv')
    
    # 获取中证800数据
    csi800_data = fetch_csi800_data()
    
    # 保存中证800数据到CSV文件
    save_to_csv(csi800_data, 'data/csi800_daily_returns.csv')