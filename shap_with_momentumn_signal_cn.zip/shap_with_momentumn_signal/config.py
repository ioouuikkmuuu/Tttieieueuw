"""
配置文件
"""

# 指数配置
INDEX_NAME = 'csi800'  # 可选 'hs300' 或 'csi800'

# 预测配置
FUTURE_DAYS = 5