# CSI 800 Cumulative Returns and SHAP Contributions Analysis Report

## Overview

This report analyzes the cumulative returns of the CSI 800 index and marks the top 10 dates of SHAP contributions for three momentum factors (short-term, medium-term, and long-term) on the chart. This approach allows us to visually identify which dates had significant impact on model predictions and how these dates relate to market movements.

![Cumulative Returns with SHAP Contributions Analysis](csi800_cumulative_returns_with_shap_markers.png)

## Chart Description

### Main Chart
The main chart displays the cumulative returns curve of the CSI 800 index, with markers for the top 10 SHAP contribution dates for each momentum factor:
- Green triangles: Top 10 dates for short-term momentum factor SHAP contributions
- Blue circles: Top 10 dates for medium-term momentum factor SHAP contributions
- Red squares: Top 10 dates for long-term momentum factor SHAP contributions

### Positive Contributions Chart
The positive contributions chart shows only markers with positive SHAP contributions:

![Cumulative Returns with Positive SHAP Contributions Only](csi800_cumulative_returns_positive_only.png)

### Negative Contributions Chart
The negative contributions chart shows only markers with negative SHAP contributions:

![Cumulative Returns with Negative SHAP Contributions Only](csi800_cumulative_returns_negative_only.png)

## Top 10 SHAP Contribution Dates Analysis by Factor

### Top 10 Dates for Short-Term Momentum Factor SHAP Contributions

| Rank | Date       | SHAP Value | Market Status Description     |
|------|------------|------------|-------------------------------|
| 1    | 2024-09-24 | 0.036741   | Positive contribution during market upswing |
| 2    | 2024-09-23 | 0.035991   | Positive contribution during market upswing |
| 3    | 2024-09-20 | 0.035441   | Positive contribution during market upswing |
| 4    | 2024-09-19 | 0.034603   | Positive contribution during market upswing |
| 5    | 2024-02-06 | 0.033972   | Positive contribution during market upswing |
| 6    | 2024-02-05 | 0.032110   | Positive contribution during market upswing |
| 7    | 2024-09-25 | 0.031760   | Positive contribution during market upswing |
| 8    | 2024-02-02 | 0.031527   | Positive contribution during market upswing |
| 9    | 2022-03-16 | 0.031261   | Positive contribution during market upswing |
| 10   | 2024-09-18 | 0.030634   | Positive contribution during market upswing |

### Top 10 Dates for Medium-Term Momentum Factor SHAP Contributions

| Rank | Date       | SHAP Value | Market Status Description     |
|------|------------|------------|-------------------------------|
| 1    | 2024-09-24 | 0.048427   | Positive contribution during market upswing |
| 2    | 2024-09-23 | 0.047403   | Positive contribution during market upswing |
| 3    | 2024-09-20 | 0.046749   | Positive contribution during market upswing |
| 4    | 2024-09-19 | 0.044849   | Positive contribution during market upswing |
| 5    | 2024-02-05 | 0.041891   | Positive contribution during market upswing |
| 6    | 2024-02-06 | 0.041238   | Positive contribution during market upswing |
| 7    | 2024-09-25 | 0.040453   | Positive contribution during market upswing |
| 8    | 2024-02-02 | 0.039830   | Positive contribution during market upswing |
| 9    | 2022-03-16 | 0.039212   | Positive contribution during market upswing |
| 10   | 2022-03-15 | 0.038163   | Positive contribution during market upswing |

### Top 10 Dates for Long-Term Momentum Factor SHAP Contributions

| Rank | Date       | SHAP Value | Market Status Description     |
|------|------------|------------|-------------------------------|
| 1    | 2024-09-20 | 0.064290   | Positive contribution during market upswing |
| 2    | 2024-09-19 | 0.047162   | Positive contribution during market upswing |
| 3    | 2024-09-24 | 0.046707   | Positive contribution during market upswing |
| 4    | 2019-01-18 | 0.043198   | Positive contribution during market upswing |
| 5    | 2020-06-29 | 0.042959   | Positive contribution during market upswing |
| 6    | 2024-02-02 | 0.042208   | Positive contribution during market upswing |
| 7    | 2022-10-31 | 0.041593   | Positive contribution during market upswing |
| 8    | 2022-10-28 | 0.040304   | Positive contribution during market upswing |
| 9    | 2024-02-05 | 0.039177   | Positive contribution during market upswing |
| 10   | 2022-03-15 | 0.036085   | Positive contribution during market upswing |

### Bottom 10 Dates for Short-Term Momentum Factor SHAP Contributions

| Rank | Date       | SHAP Value | Market Status Description     |
|------|------------|------------|-------------------------------|
| 1    | 2024-10-08 | -0.034467  | Negative contribution during market decline |
| 2    | 2020-01-17 | -0.032135  | Negative contribution during market decline |
| 3    | 2020-01-20 | -0.028828  | Negative contribution during market decline |
| 4    | 2020-01-16 | -0.028496  | Negative contribution during market decline |
| 5    | 2018-02-02 | -0.025659  | Negative contribution during market decline |
| 6    | 2018-02-01 | -0.021979  | Negative contribution during market decline |
| 7    | 2018-02-05 | -0.021688  | Negative contribution during market decline |
| 8    | 2018-01-31 | -0.021084  | Negative contribution during market decline |
| 9    | 2020-01-21 | -0.018957  | Negative contribution during market decline |
| 10   | 2025-03-28 | -0.018841  | Negative contribution during market decline |

### Bottom 10 Dates for Medium-Term Momentum Factor SHAP Contributions

| Rank | Date       | SHAP Value | Market Status Description     |
|------|------------|------------|-------------------------------|
| 1    | 2022-04-19 | -0.035734  | Negative contribution during market decline |
| 2    | 2019-04-24 | -0.035570  | Negative contribution during market decline |
| 3    | 2022-04-18 | -0.029774  | Negative contribution during market decline |
| 4    | 2020-03-11 | -0.023241  | Negative contribution during market decline |
| 5    | 2019-04-25 | -0.022610  | Negative contribution during market decline |
| 6    | 2019-04-26 | -0.021292  | Negative contribution during market decline |
| 7    | 2024-12-27 | -0.020780  | Negative contribution during market decline |
| 8    | 2021-07-23 | -0.020731  | Negative contribution during market decline |
| 9    | 2024-12-30 | -0.020598  | Negative contribution during market decline |
| 10   | 2019-04-22 | -0.019243  | Negative contribution during market decline |

### Bottom 10 Dates for Long-Term Momentum Factor SHAP Contributions

| Rank | Date       | SHAP Value | Market Status Description     |
|------|------------|------------|-------------------------------|
| 1    | 2020-01-17 | -0.050571  | Negative contribution during market decline |
| 2    | 2020-01-20 | -0.049952  | Negative contribution during market decline |
| 3    | 2020-01-16 | -0.048523  | Negative contribution during market decline |
| 4    | 2018-02-01 | -0.047225  | Negative contribution during market decline |
| 5    | 2018-02-02 | -0.046945  | Negative contribution during market decline |
| 6    | 2018-02-05 | -0.040644  | Negative contribution during market decline |
| 7    | 2018-01-31 | -0.038122  | Negative contribution during market decline |
| 8    | 2018-01-30 | -0.036563  | Negative contribution during market decline |
| 9    | 2021-06-07 | -0.034680  | Negative contribution during market decline |
| 10   | 2021-06-04 | -0.033720  | Negative contribution during market decline |

## Conclusions

1. **Market Turning Point Identification**: Through SHAP contribution analysis, we can identify significant market turning points. Dates with large positive contributions typically correlate with market upswings, while dates with large negative contributions typically correlate with market downturns.

2. **Market Dynamics Across Different Time Scales**:
   - Short-term momentum factors primarily reflect recent market trend changes
   - Medium-term momentum factors reflect quarterly market trends
   - Long-term momentum factors reflect annual market trends

3. **Significance of Contribution Direction**:
   - Positive contributions indicate that the factor contributed to positive returns (pushing the market upward) on that date
   - Negative contributions indicate that the factor contributed to negative returns (pushing the market downward) on that date

4. **Temporal Clustering**: It can be observed that high contribution dates for the same factor tend to cluster temporally, indicating that markets become more sensitive to specific factors during certain periods.

## File Locations

- **Main Chart File**: `csi800_cumulative_returns_with_shap_markers.png`
- **Positive Contributions Chart File**: `csi800_cumulative_returns_positive_only.png`
- **Negative Contributions Chart File**: `csi800_cumulative_returns_negative_only.png`
- **Analysis Report File**: `csi800_cumulative_returns_shap_analysis_en.md`