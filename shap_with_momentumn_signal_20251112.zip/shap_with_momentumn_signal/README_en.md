# Application of SHAP in Investment Analysis

## Overview

This project aims to analyze the application of SHAP (SHapley Additive exPlanations) in the investment field, particularly how to use SHAP to explain the role of machine learning models in investment decisions. By using a random forest model to analyze momentum factors of the CSI 800 index, we can better understand the model's decision-making process and identify key factors that significantly impact market movements.

![Application of SHAP in Investment](shap_investment_analysis.png)

## Introduction to SHAP

SHAP is a game theory-based machine learning model interpretation method that assigns a contribution value (SHAP value) to each feature, representing the feature's impact on the model's prediction results. The core advantage of SHAP lies in its solid theoretical foundation, providing consistent and accurate feature importance explanations.

### Core Features of SHAP

1. **Consistency**: SHAP values are calculated based on Shapley values with a solid theoretical foundation
2. **Interpretability**: Clearly shows each feature's contribution to prediction results
3. **Global and Local Explanation**: Can analyze feature contributions for individual predictions and the entire dataset

## Random Forest Model

Random forest is an ensemble learning method that builds multiple decision trees and combines their prediction results to improve model accuracy and robustness. In this project, we use a random forest model to predict CSI 800 index returns and analyze the model's predictions through SHAP.

### Advantages of Random Forest

1. **High Accuracy**: Ensemble of multiple decision trees typically achieves high prediction accuracy
2. **Strong Robustness**: Resistant to noise and outliers
3. **Feature Importance**: Provides feature importance evaluation
4. **Overfitting Prevention**: Effectively prevents overfitting through random sampling and ensemble learning

### Reasons for Choosing Random Forest

1. **Good Prediction Performance**: Random forest performs excellently in financial data prediction
2. **Interpretability**: Combined with SHAP, provides good model explanation capability
3. **Handling Non-linear Relationships**: Can capture complex non-linear relationships in financial data

## Project Structure

```
shap_with_momentumn_signal/
├── data/
│   ├── csi800_daily_returns.csv
│   └── csi800_random_forest_model.pkl
├── all_dates_returns.csv
├── all_dates_returns_validation_en.md
├── complete_shap_momentum_analysis_report_en.md
├── csi800_cumulative_returns_shap_analysis_en.md
├── shap_returns_analysis_report_en.md
├── *.png (various analysis charts)
├── *.md (various analysis reports)
└── README_en.md
```

## Investment Value

This project reveals the role of momentum factors in CSI 800 index prediction through SHAP analysis, providing the following value to investors:

1. **Factor Validity Verification**: By analyzing the relationship between SHAP contributions and future returns, validates the effectiveness of momentum factors
2. **Market Turning Point Identification**: Identifies key market turning points through analysis of positive and negative SHAP contribution changes
3. **Strategy Optimization**: Provides optimization suggestions for momentum factor-based investment strategies

## File Locations

- **Main Analysis Report**: `complete_shap_momentum_analysis_report_en.md`
- **Cumulative Returns Analysis Report**: `csi800_cumulative_returns_shap_analysis_en.md`
- **Returns Validation Report**: `all_dates_returns_validation_en.md`
- **SHAP Returns Analysis Report**: `shap_returns_analysis_report_en.md`
- **Analysis Charts**: All `.png` files
- **This README File**: `README_en.md`