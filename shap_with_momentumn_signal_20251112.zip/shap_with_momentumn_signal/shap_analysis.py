import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import shap
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import config
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体支持
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


def load_and_prepare_data(index_name='csi800'):
    """
    加载并准备数据
    :param index_name: 指数名称
    :return: DataFrame
    """
    file_path = f'data/{index_name}_daily_returns.csv'
    df = pd.read_csv(file_path)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    return df


def calculate_momentum_signals(df, short_window=5, medium_window=66, long_window=252):
    """
    计算三个动量信号：短期、中期、长期
    :param df: 包含日期和收益率的DataFrame
    :param short_window: 短期窗口大小
    :param medium_window: 中期窗口大小
    :param long_window: 长期窗口大小
    :return: 包含动量信号的DataFrame
    """
    # 短期动量：过去short_window个交易日的绝对收益除以波动率
    short_term_return = df['return'].rolling(window=short_window).sum()
    short_term_volatility = df['return'].rolling(window=short_window).std()
    df['short_momentum'] = short_term_return / short_term_volatility
    
    # 中期动量：过去medium_window个交易日的绝对收益除以波动率
    medium_term_return = df['return'].rolling(window=medium_window).sum()
    medium_term_volatility = df['return'].rolling(window=medium_window).std()
    df['medium_momentum'] = medium_term_return / medium_term_volatility
    
    # 长期动量：过去long_window个交易日的绝对收益除以波动率
    long_term_return = df['return'].rolling(window=long_window).sum()
    long_term_volatility = df['return'].rolling(window=long_window).std()
    df['long_momentum'] = long_term_return / long_term_volatility
    
    return df


def create_target_variable(df, future_days=5):
    """
    创建目标变量：未来5个交易日的回报
    :param df: 包含收益率的DataFrame
    :param future_days: 未来天数
    :return: 包含目标变量的DataFrame
    """
    df['future_return'] = df['return'].shift(-future_days).rolling(window=future_days).sum()
    return df


def prepare_features_and_target(df):
    """
    准备特征和目标变量
    :param df: 包含所有数据的DataFrame
    :return: 特征和目标变量
    """
    # 删除包含NaN的行
    df = df.dropna()
    
    # 选择特征
    features = ['short_momentum', 'medium_momentum', 'long_momentum']
    X = df[features]
    y = df['future_return']
    
    return X, y, df


def train_model(X, y):
    """
    训练随机森林回归模型
    :param X: 特征
    :param y: 目标变量
    :return: 训练好的模型
    """
    # 分割训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # 创建并训练模型
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    return model, X_train, X_test, y_train, y_test


def get_momentum_contributions_for_date(model, X, date_str, df):
    """
    给定日期，返回三个动量的贡献度
    :param model: 训练好的模型
    :param X: 特征数据
    :param date_str: 日期字符串 (格式: 'yyyymmdd')
    :param df: 包含日期信息的DataFrame
    :return: 三个动量的贡献度
    """
    # 将日期字符串转换为datetime对象
    target_date = pd.to_datetime(date_str, format='%Y%m%d')
    
    # 找到最接近的日期索引
    date_diff = abs(df['date'] - target_date)
    closest_idx = date_diff.argmin()
    
    # 获取该日期的特征值
    feature_values = X.iloc[closest_idx].values.reshape(1, -1)
    
    # 使用SHAP计算贡献度
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(feature_values)
    
    # 获取特征名称
    feature_names = ['短期动量', '中期动量', '长期动量']
    
    # 返回贡献度
    contributions = dict(zip(feature_names, shap_values[0]))
    
    # 绘制瀑布图
    plot_waterfall(explainer, feature_values, feature_names, shap_values[0], date_str)
    
    return contributions


def plot_waterfall(explainer, feature_values, feature_names, shap_values, date_str):
    """
    绘制SHAP瀑布图
    :param explainer: SHAP解释器
    :param feature_values: 特征值
    :param feature_names: 特征名称
    :param shap_values: SHAP值
    :param date_str: 日期字符串
    :return: None
    """
    # 创建SHAP Explanation对象
    import shap
    explanation = shap.Explanation(
        values=shap_values,
        base_values=explainer.expected_value,
        data=feature_values[0],
        feature_names=feature_names
    )
    
    # 绘制瀑布图
    shap.waterfall_plot(explanation, show=False)
    plt.title(f'{date_str} 动量因子贡献度瀑布图')
    plt.tight_layout()
    plt.savefig(f'momentum_waterfall_{date_str}.png', dpi=300, bbox_inches='tight')
    plt.close()
    print(f"瀑布图已保存为 momentum_waterfall_{date_str}.png")


def plot_momentum_factors_over_time(model, X, df):
    """
    绘制三个动量因子随时间推移的变化
    :param model: 训练好的模型
    :param X: 特征数据
    :param df: 包含日期信息的DataFrame
    :return: None
    """
    # 使用SHAP计算所有样本的贡献度
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X)
    
    # 创建DataFrame存储贡献度
    contributions_df = pd.DataFrame(shap_values, columns=['短期动量', '中期动量', '长期动量'])
    contributions_df['date'] = df['date'].iloc[:len(shap_values)].values
    
    # 保存贡献度到CSV文件
    contributions_df.to_csv('momentum_shap_contributions.csv', index=False)
    print("SHAP贡献度已保存为 momentum_shap_contributions.csv")
    
    # 分析极端值
    analyze_extreme_values(contributions_df)
    
    # 绘制包含所有三个因子的图表
    plt.figure(figsize=(12, 6))
    
    # 绘制三条线
    plt.plot(contributions_df['date'], contributions_df['短期动量'], label='短期动量', linewidth=1)
    plt.plot(contributions_df['date'], contributions_df['中期动量'], label='中期动量', linewidth=1)
    plt.plot(contributions_df['date'], contributions_df['长期动量'], label='长期动量', linewidth=1)
    
    # 添加标题和标签
    plt.title('三个动量因子随时间推移的变化')
    plt.xlabel('日期')
    plt.ylabel('SHAP贡献度')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # 保存图表
    plt.savefig('momentum_factors_over_time.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("动量因子变化图已保存为 momentum_factors_over_time.png")
    
    # 为每个因子单独生成图表
    factors = ['短期动量', '中期动量', '长期动量']
    factor_names = ['短期动量', '中期动量', '长期动量']
    
    for factor in factors:
        plt.figure(figsize=(12, 6))
        
        # 绘制单个因子的线条
        plt.plot(contributions_df['date'], contributions_df[factor], label=factor, linewidth=1, color='blue')
        
        # 添加标题和标签
        plt.title(f'{factor}因子随时间推移的变化')
        plt.xlabel('日期')
        plt.ylabel('SHAP贡献度')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # 保存图表
        filename = f'momentum_factor_{factor}_over_time.png'
        plt.savefig(filename, dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"{factor}因子变化图已保存为 {filename}")


def analyze_momentum_contributions(date_str):
    """
    分析指定日期三个动量的贡献度
    :param date_str: 日期字符串 (格式: 'yyyymmdd')
    :return: 三个动量的贡献度字典
    """
    print("加载并准备数据...")
    df = load_and_prepare_data(config.INDEX_NAME)
    
    print("计算动量信号...")
    df = calculate_momentum_signals(df)
    
    print("创建目标变量...")
    df = create_target_variable(df, config.FUTURE_DAYS)
    
    print("准备特征和目标变量...")
    X, y, df = prepare_features_and_target(df)
    
    print("训练模型...")
    model, X_train, X_test, y_train, y_test = train_model(X, y)
    
    print(f"\n获取 {date_str} 的动量贡献度...")
    contributions = get_momentum_contributions_for_date(model, X, date_str, df)
    for factor, contribution in contributions.items():
        print(f"{factor}: {contribution:.6f}")
    
    return contributions


def analyze_momentum_change_around_date(date_str):
    """
    分析指定日期前后动量因子的变化
    :param date_str: 日期字符串 (格式: 'yyyymmdd')
    :return: None
    """
    print("加载并准备数据...")
    df = load_and_prepare_data(config.INDEX_NAME)
    
    print("计算动量信号...")
    df = calculate_momentum_signals(df)
    
    print("创建目标变量...")
    df = create_target_variable(df, config.FUTURE_DAYS)
    
    print("准备特征和目标变量...")
    X, y, df = prepare_features_and_target(df)
    
    print("训练模型...")
    model, X_train, X_test, y_train, y_test = train_model(X, y)
    
    # 将日期字符串转换为datetime对象
    target_date = pd.to_datetime(date_str, format='%Y%m%d')
    
    # 找到目标日期的索引
    date_diff = abs(df['date'] - target_date)
    target_idx = date_diff.argmin()
    
    # 确定分析的时间范围
    # 过去一个月（约22个交易日）
    start_idx = max(0, target_idx - 22)
    # 接下来5个交易日
    end_idx = min(len(df), target_idx + 5)
    
    # 获取分析范围内的数据
    analysis_df = df.iloc[start_idx:end_idx].copy()
    analysis_X = X.iloc[start_idx:end_idx]
    
    # 使用SHAP计算所有样本的贡献度
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(analysis_X)
    
    # 创建DataFrame存储贡献度
    contributions_df = pd.DataFrame(shap_values, columns=['短期动量', '中期动量', '长期动量'])
    contributions_df['date'] = analysis_df['date'].values
    
    # 找到目标日期在分析范围内的索引
    target_in_analysis = abs(contributions_df['date'] - target_date).argmin()
    
    # 计算过去一个月的平均贡献度
    past_month_contributions = contributions_df.iloc[:target_in_analysis+1][['短期动量', '中期动量', '长期动量']].mean()
    
    # 计算接下来5个交易日的平均贡献度
    future_5_contributions = contributions_df.iloc[target_in_analysis:][['短期动量', '中期动量', '长期动量']].mean()
    
    # 创建对比数据
    comparison_data = pd.DataFrame({
        '过去一个月': past_month_contributions,
        '接下来5个交易日': future_5_contributions
    })
    
    # 绘制对比图
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))
    
    # 第一个子图：柱状图对比
    comparison_data.plot(kind='bar', ax=ax1, color=['skyblue', 'lightcoral'])
    ax1.set_title(f'{date_str} 前后动量因子贡献度变化对比')
    ax1.set_xlabel('动量因子')
    ax1.set_ylabel('平均SHAP贡献度')
    ax1.set_xticklabels(ax1.get_xticklabels(), rotation=45)
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    # 在柱状图上添加数值标签
    for container in ax1.containers:
        ax1.bar_label(container, fmt='%.4f', padding=3)
    
    # 第二个子图：时间序列图
    contributions_df.plot(x='date', y=['短期动量', '中期动量', '长期动量'], ax=ax2)
    ax2.axvline(x=contributions_df['date'].iloc[target_in_analysis], color='red', linestyle='--', linewidth=1, label=f'目标日期 ({date_str})')
    ax2.set_title(f'{date_str} 前后动量因子贡献度时间序列')
    ax2.set_xlabel('日期')
    ax2.set_ylabel('SHAP贡献度')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    # 格式化日期显示
    fig.autofmt_xdate()
    
    plt.tight_layout()
    plt.savefig(f'momentum_change_around_{date_str}.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"动量因子变化图已保存为 momentum_change_around_{date_str}.png")
    
    # 打印详细信息
    print(f"\n{date_str} 前后动量因子贡献度变化分析:")
    print("\n过去一个月平均贡献度:")
    for factor, value in past_month_contributions.items():
        print(f"  {factor}: {value:.6f}")
    
    print("\n接下来5个交易日平均贡献度:")
    for factor, value in future_5_contributions.items():
        print(f"  {factor}: {value:.6f}")
    
    # 计算变化量
    change = future_5_contributions - past_month_contributions
    print("\n变化量 (接下来5个交易日 - 过去一个月):")
    for factor, value in change.items():
        print(f"  {factor}: {value:.6f}")


def analyze_extreme_values(contributions_df):
    """
    分析SHAP贡献度的极端值
    :param contributions_df: 包含SHAP贡献度的DataFrame
    :return: None
    """
    print("\n分析SHAP贡献度的极端值...")
    
    # 计算每个动量因子的1%分位数和99%分位数
    percentiles = [0.01, 0.99]
    
    for column in ['短期动量', '中期动量', '长期动量']:
        values = contributions_df[column]
        lower_percentile, upper_percentile = np.percentile(values, [p * 100 for p in percentiles])
        
        # 找出低于1%分位数和高于99%分位数的极端值
        lower_extremes = contributions_df[contributions_df[column] < lower_percentile]
        upper_extremes = contributions_df[contributions_df[column] > upper_percentile]
        
        print(f"\n{column}的极端值分析:")
        print(f"1%分位数: {lower_percentile:.6f}")
        print(f"99%分位数: {upper_percentile:.6f}")
        print(f"低于1%分位数的日期数量: {len(lower_extremes)}")
        print(f"高于99%分位数的日期数量: {len(upper_extremes)}")
        
        # 显示前5个极端值
        if len(lower_extremes) > 0:
            print("\n最低的5个值:")
            print(lower_extremes.nsmallest(5, column)[['date', column]])
        
        if len(upper_extremes) > 0:
            print("\n最高的5个值:")
            print(upper_extremes.nlargest(5, column)[['date', column]])
    
    print("\n极端值分析完成！")


def plot_momentum_factors():
    """
    绘制三个动量因子随时间推移的变化图
    :return: None
    """
    print("加载并准备数据...")
    df = load_and_prepare_data(config.INDEX_NAME)
    
    print("计算动量信号...")
    df = calculate_momentum_signals(df)
    
    print("创建目标变量...")
    df = create_target_variable(df, config.FUTURE_DAYS)
    
    print("准备特征和目标变量...")
    X, y, df = prepare_features_and_target(df)
    
    print("训练模型...")
    model, X_train, X_test, y_train, y_test = train_model(X, y)
    
    print("\n绘制动量因子随时间变化图...")
    plot_momentum_factors_over_time(model, X, df)


def main():
    """
    主函数
    """
    import sys
    
    if len(sys.argv) > 1:
        # 检查是否有特殊命令
        if sys.argv[1] == '--around-date' and len(sys.argv) > 2:
            # 分析指定日期前后的动量因子变化
            date_str = sys.argv[2]
            analyze_momentum_change_around_date(date_str)
        else:
            # 如果提供了日期参数，则分析指定日期的贡献度
            date_str = sys.argv[1]
            analyze_momentum_contributions(date_str)
    else:
        # 默认行为：分析贡献度并绘图
        # 示例：获取特定日期的贡献度
        # 注意：这里使用一个示例日期，实际使用时需要替换为有效的日期
        example_date = '20230101'
        analyze_momentum_contributions(example_date)
        
        # 绘制动量因子随时间变化图
        plot_momentum_factors()
        
        print("\nSHAP分析完成！")


if __name__ == "__main__":
    main()