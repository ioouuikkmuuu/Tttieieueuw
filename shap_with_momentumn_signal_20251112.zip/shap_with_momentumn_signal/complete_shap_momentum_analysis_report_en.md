# Complete SHAP Momentum Analysis Report

## Executive Summary

This report provides a comprehensive analysis of the CSI 800 index using SHAP (SHapley Additive exPlanations) to explain the contributions of three momentum factors (short-term, medium-term, and long-term) in predicting market returns. The analysis includes cumulative returns visualization with SHAP markers, future return performance of top SHAP contribution dates, and validation of the predictive power of SHAP values.

## Data Description

The analysis is based on the following data sources:
- **CSI 800 Daily Returns**: Historical daily return data for the CSI 800 index
- **Random Forest Model**: A trained model using three momentum factors to predict future returns
- **SHAP Values**: Calculated contributions of each momentum factor to the model's predictions

### SHAP Contribution Value Definition

SHAP (SHapley Additive exPlanations) is a game theory-based method for explaining machine learning model predictions. In this report, SHAP contribution values represent the contribution of each momentum factor to the model's prediction of returns:
- **Positive values**: Indicate that the momentum factor has a positive contribution to the daily return prediction, meaning the factor's presence increases the model's predicted return value for that day
- **Negative values**: Indicate that the momentum factor has a negative contribution to the daily return prediction, meaning the factor's presence decreases the model's predicted return value for that day
- **Absolute value magnitude**: Represents the importance of the momentum factor, with larger absolute values indicating greater influence on the model's predictions

### SHAP Contribution Time Series Chart

The following chart shows the evolution of SHAP contributions from the three momentum factors over time:

![SHAP Contribution Time Series](momentum_factors_over_time.png)

### Specific Date SHAP Contribution Analysis (September 23, 2024)

To provide deeper insights into how momentum factors contribute to market predictions on a specific date, we present the waterfall chart showing the SHAP contributions for September 23, 2024:

![SHAP Contributions for 2024-09-23](momentum_waterfall_20240923.png)

This visualization shows how each momentum factor contributed to the model's prediction for this specific date:
- **Short-term Momentum**: -0.000838
- **Medium-term Momentum**: -0.003792
- **Long-term Momentum**: 0.008508

From the chart, we can see that on September 23, 2024, the long-term momentum factor had a positive contribution to the model prediction, while the short-term and medium-term momentum factors had slight negative contributions. This indicates that on this date, long-term trends were dominant in market predictions.

## Cumulative Returns and SHAP Contributions Analysis

The chart below shows the cumulative returns of the CSI 800 index with markers indicating the top 10 positive and negative SHAP contribution dates for each momentum factor.

![Cumulative Returns with SHAP Markers](csi800_cumulative_returns_with_shap_markers.png)

### Key Observations:
1. **Market Turning Points**: Significant market turning points are often associated with high absolute SHAP values, indicating these factors play a crucial role in market movements.
2. **Factor Behavior**: Different momentum factors show varying patterns of contribution, with long-term factors generally having more sustained impact.

## Top 10 Positive SHAP Contribution Dates Future Returns Performance

The following chart shows the future returns of the top 10 dates with the highest positive SHAP contributions:

![Top 10 Positive SHAP Dates Future Returns](positive_shap_dates_future_returns.png)

### Analysis Results:
- The top 10 positive SHAP contribution dates show significantly higher future returns compared to the overall average
- This validates the predictive power of positive SHAP contributions

## Top 10 Negative SHAP Contribution Dates Future Returns Performance

The following chart shows the future returns of the top 10 dates with the highest negative SHAP contributions:

![Top 10 Negative SHAP Dates Future Returns](negative_shap_dates_future_returns.png)

### Analysis Results:
- The top 10 negative SHAP contribution dates show significantly lower future returns compared to the overall average
- This further validates the predictive power of SHAP values in identifying market downturns

## SHAP Contribution Time Series Analysis

The following chart shows the evolution of SHAP contributions from the three momentum factors over time:

![SHAP Contribution Time Series](momentum_factors_over_time.png)

### Key Insights:
1. **Temporal Patterns**: The time series reveals distinct patterns in how different momentum factors contribute to market predictions over time.
2. **Factor Dominance**: Long-term momentum factors tend to have more sustained periods of high contribution compared to short-term factors.
3. **Market Regime Changes**: Significant shifts in dominant factors often coincide with major market events or regime changes.

## Detailed SHAP Analysis for Specific Dates

To provide deeper insights into how momentum factors contribute to market predictions on specific dates, we present waterfall charts showing the SHAP contributions for individual dates.

### Example 1: January 1, 2023

The following waterfall chart shows the SHAP contributions of each momentum factor for January 1, 2023:

![SHAP Contributions for 2023-01-01](momentum_waterfall_20230101.png)

This visualization shows how each momentum factor contributed to the model's prediction for this specific date, with the total prediction being the sum of all individual contributions.

### Example 2: September 24, 2024

The following waterfall chart shows the SHAP contributions of each momentum factor for September 24, 2024:

![SHAP Contributions for 2024-09-24](momentum_waterfall_20240924.png)

This visualization shows how each momentum factor contributed to the model's prediction for this specific date, with the total prediction being the sum of all individual contributions.

## Conclusions and Insights

1. **Market Turning Point Identification**: SHAP analysis effectively identifies critical market turning points. Dates with high positive SHAP values typically correspond to market upswings, while dates with high negative SHAP values typically correspond to market downturns.

2. **Differences in Momentum Factor Effects Across Time Scales**:
   - Short-term momentum factors reflect recent market trend changes
   - Medium-term momentum factors reflect quarterly market trends
   - Long-term momentum factors reflect annual market trends
   - Long-term factors generally show stronger predictive power

3. **Validation of SHAP Contribution Effectiveness**: Both positive and negative SHAP contribution dates demonstrate significant predictive ability for future returns, validating the effectiveness of SHAP analysis.

4. **Temporal Clustering**: High contribution dates for the same factor often cluster temporally, indicating that markets become more sensitive to specific factors during certain periods.

5. **Practical Application Value**: SHAP analysis provides actionable insights for investment decisions by identifying key market drivers and potential turning points.

## File Locations

- **Main Chart File**: `csi800_cumulative_returns_with_shap_markers.png`
- **Positive Contributions Chart**: `csi800_cumulative_returns_positive_only.png`
- **Negative Contributions Chart**: `csi800_cumulative_returns_negative_only.png`
- **Data Files**: Located in the `data/` directory
- **Analysis Reports**: All markdown files in the project directory