"""
使用tushare获取真实股票数据
"""

import tushare as ts
import pandas as pd
import numpy as np
import time
from typing import List, Tuple
import sys
import os

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tushare_config import tushare_token


def get_stock_list(pro) -> List[str]:
    """
    获取股票列表
    
    Parameters:
    pro: tushare pro接口
    
    Returns:
    List[str]: 股票代码列表
    """
    # 获取股票列表
    try:
        stock_list = pro.stock_basic(exchange='', list_status='L', fields='ts_code,symbol,name')
        if stock_list.empty:
            print("未能获取到股票列表，请检查以下几点：")
            print("1. 检查tushare token是否正确设置")
            print("2. 检查tushare账户是否具有股票数据访问权限")
            print("3. 检查网络连接是否正常")
            return []
        return stock_list['ts_code'].tolist()
    except Exception as e:
        print(f"获取股票列表时出错: {e}")
        return []


def get_stock_data(pro, ts_code: str, start_date: str, end_date: str) -> pd.DataFrame:
    """
    获取单只股票的历史数据
    
    Parameters:
    pro: tushare pro接口
    ts_code (str): 股票代码
    start_date (str): 开始日期，格式YYYYMMDD
    end_date (str): 结束日期，格式YYYYMMDD
    
    Returns:
    pd.DataFrame: 股票历史数据
    """
    try:
        # 获取股票日线数据
        df = pro.daily(ts_code=ts_code, start_date=start_date, end_date=end_date)
        
        # 重命名列以匹配项目需求
        df = df.rename(columns={
            'trade_date': 'date',
            'ts_code': 'stock_code',
            'close': 'close_price'
        })
        
        # 转换日期格式
        df['date'] = pd.to_datetime(df['date'], format='%Y%m%d')
        
        # 按日期排序
        df = df.sort_values('date').reset_index(drop=True)
        
        return df[['date', 'stock_code', 'close_price']]
    except Exception as e:
        print(f"获取股票{ts_code}数据时出错: {e}")
        return pd.DataFrame()


def fetch_real_data(token: str, start_date: str = '20200101', end_date: str = '20231231', 
                   max_stocks: int = 50) -> pd.DataFrame:
    """
    获取真实股票数据
    
    Parameters:
    token (str): tushare token
    start_date (str): 开始日期，格式YYYYMMDD
    end_date (str): 结束日期，格式YYYYMMDD
    max_stocks (int): 最大股票数量
    
    Returns:
    pd.DataFrame: 股票数据
    """
    # 设置tushare token
    ts.set_token(token)
    pro = ts.pro_api()
    
    # 获取股票列表
    stock_list = get_stock_list(pro)
    
    # 限制股票数量
    stock_list = stock_list[:max_stocks]
    
    # 获取所有股票数据
    all_data = []
    for i, ts_code in enumerate(stock_list):
        print(f"正在获取第{i+1}/{len(stock_list)}只股票({ts_code})的数据...")
        
        # 获取股票数据
        stock_data = get_stock_data(pro, ts_code, start_date, end_date)
        
        if not stock_data.empty:
            all_data.append(stock_data)
        
        # 避免请求过于频繁
        time.sleep(0.1)
    
    # 合并所有数据
    if all_data:
        combined_data = pd.concat(all_data, ignore_index=True)
        return combined_data
    else:
        return pd.DataFrame()


def main():
    """
    主函数 - 示例用法
    """
    # 从配置文件读取token
    token = tushare_token
    
    if token == 'your_real_tushare_token_here':
        print("请先在tushare_config.py文件中设置您的tushare token")
        return
    
    # 获取数据
    print("开始获取股票数据...")
    data = fetch_real_data(token, start_date='20200101', end_date='20231231', max_stocks=30)
    
    if not data.empty:
        print(f"成功获取{len(data)}条数据记录")
        print(data.head())
        
        # 保存数据
        data.to_csv('real_stock_data.csv', index=False)
        print("数据已保存到 real_stock_data.csv")
    else:
        print("未能获取到数据")


if __name__ == "__main__":
    main()