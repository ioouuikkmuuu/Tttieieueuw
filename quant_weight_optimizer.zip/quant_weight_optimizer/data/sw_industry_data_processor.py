"""
申万行业数据处理器
用于处理申万各行业的daily return时序数据
"""

import pandas as pd
import numpy as np
from typing import Optional


def load_sw_industry_data(filepath: str) -> pd.DataFrame:
    """
    加载申万行业daily return数据
    
    申万行业数据格式要求：
    - 包含日期列（date）
    - 包含行业代码列（industry_code）或行业名称列（industry_name）
    - 包含收益率列（return）
    
    Parameters:
    filepath (str): 数据文件路径
    
    Returns:
    pd.DataFrame: 包含申万行业收益率数据的DataFrame
    """
    # 读取CSV文件
    data = pd.read_csv(filepath)
    
    # 转换日期列格式
    data['date'] = pd.to_datetime(data['date'])
    
    # 检查是否包含行业代码或行业名称列
    if 'industry_code' not in data.columns and 'industry_name' not in data.columns:
        raise ValueError("数据必须包含industry_code或industry_name列")
    
    # 如果包含行业名称但不包含行业代码，则创建行业代码
    if 'industry_code' not in data.columns and 'industry_name' in data.columns:
        # 简单映射行业名称到代码
        unique_industries = data['industry_name'].unique()
        industry_mapping = {name: f"IND{i:03d}" for i, name in enumerate(unique_industries, 1)}
        data['industry_code'] = data['industry_name'].map(industry_mapping)
    
    # 确保包含必要的列
    if 'return' not in data.columns:
        raise ValueError("数据必须包含return列")
    
    # 重命名列以匹配项目需求
    if 'industry_code' in data.columns:
        data = data.rename(columns={'industry_code': 'stock_code'})
    
    # 添加close_price列（通过累积收益率计算）
    # 假设初始价格为100
    data = data.sort_values(['stock_code', 'date']).reset_index(drop=True)
    data['close_price'] = data.groupby('stock_code')['return'].apply(
        lambda x: 100 * (1 + x).cumprod()
    ).reset_index(drop=True)
    
    # 按日期和行业代码排序
    data = data.sort_values(['stock_code', 'date']).reset_index(drop=True)
    
    return data[['date', 'stock_code', 'close_price', 'return']]


def convert_sw_data_for_model(filepath: str, output_path: Optional[str] = None) -> pd.DataFrame:
    """
    转换申万行业数据以适配动量因子模型
    
    Parameters:
    filepath (str): 原始申万行业数据文件路径
    output_path (Optional[str]): 转换后数据保存路径
    
    Returns:
    pd.DataFrame: 转换后的数据
    """
    # 加载数据
    data = load_sw_industry_data(filepath)
    
    # 保存转换后的数据
    if output_path:
        data.to_csv(output_path, index=False)
        print(f"转换后的数据已保存到 {output_path}")
    
    return data


def main():
    """
    主函数 - 示例用法
    """
    # 示例：转换申万行业数据
    # 注意：需要根据实际数据文件路径进行修改
    try:
        # 使用示例数据文件
        converted_data = convert_sw_data_for_model(
            'sample_sw_data.csv', 
            'converted_sw_industry_data.csv'
        )
        print("数据转换完成")
        print(converted_data.head(10))
    except FileNotFoundError:
        print("未找到数据文件，请确保文件路径正确")
    except ValueError as e:
        print(f"数据格式错误: {e}")
    except Exception as e:
        print(f"处理数据时出错: {e}")


if __name__ == "__main__":
    main()