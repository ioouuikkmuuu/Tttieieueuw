"""
使用申万行业数据运行动量信号模型
"""

import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')

# 导入配置
from config import data_config, model_config, optimization_config, explanation_config, evaluation_config

# 导入数据处理模块
from data.sw_industry_data_processor import load_sw_industry_data
from data.data_generator import load_real_data

# 导入其他模块
from factors.momentum_factors import calculate_momentum_factors, get_factor_descriptions
from model.predictor import MarketTrendPredictor
from optimization.hyperparameter_tuning import optimize_hyperparameters, update_model_with_optimal_params
from explanation.model_explanation import create_shap_explainer, calculate_shap_values, analyze_factor_importance, detect_trend_changes
from evaluation.metrics import calculate_performance_metrics
from utils.helpers import validate_data, format_metrics_for_display


def run_sw_industry_model(data_file_path: str):
    """
    使用申万行业数据运行模型
    
    Parameters:
    data_file_path (str): 申万行业数据文件路径
    """
    print("=== 使用申万行业数据运行动量信号模型 ===")
    
    # 1. 数据加载
    print("\n1. 加载申万行业数据...")
    try:
        raw_data = load_real_data(data_file_path)
        print(f"加载了 {len(raw_data)} 条数据记录")
    except Exception as e:
        print(f"加载数据失败: {e}")
        return
    
    # 2. 动量因子计算
    print("\n2. 计算动量因子...")
    factor_data = calculate_momentum_factors(raw_data, data_config)
    print(f"计算了 {len(factor_data)} 条因子数据记录")
    
    # 显示因子描述
    factor_descriptions = get_factor_descriptions(data_config)
    print("\n因子描述:")
    for factor, description in factor_descriptions.items():
        print(f"  {factor}: {description}")
    
    # 3. 模型训练
    print("\n3. 训练模型...")
    predictor = MarketTrendPredictor(model_config)
    
    # 准备特征和目标变量
    features = predictor.prepare_features(factor_data)
    target = predictor.prepare_target(factor_data)
    
    # 验证数据
    required_features = ['short_momentum', 'medium_momentum', 'long_momentum']
    if not validate_data(features, required_features):
        print("特征数据验证失败")
        return
    
    # 4. 超参数优化
    print("\n4. 超参数优化...")
    optimization_result = optimize_hyperparameters(
        features, 
        target, 
        optimization_config
    )
    print(f"最优参数: {optimization_result['best_params']}")
    print(f"最优值 (RMSE): {optimization_result['best_value']:.6f}")
    
    # 使用最优参数更新模型
    update_model_with_optimal_params(predictor, optimization_result['best_params'])
    
    # 重新训练模型
    predictor.train(features, target)
    
    # 5. 模型评估
    print("\n5. 评估模型...")
    # 进行预测
    predictions = predictor.predict(features)
    
    evaluation_metrics = predictor.evaluate(features, target)
    print("模型评估指标:")
    print(format_metrics_for_display(evaluation_metrics))
    
    # 计算预测收益率的综合性能指标
    performance_metrics = calculate_performance_metrics(pd.Series(predictions), config=evaluation_config)
    print("\n预测收益率综合性能指标:")
    print(format_metrics_for_display(performance_metrics))
    
    # 6. 模型解释
    print("\n6. 模型解释...")
    explainer = create_shap_explainer(predictor, features)
    shap_values = calculate_shap_values(explainer, features, explanation_config)
    
    # 分析因子重要性
    importance_df = analyze_factor_importance(shap_values, features.columns.tolist())
    print("\n因子重要性排序:")
    print(importance_df.to_string(index=False))
    
    # 检测趋势变化
    trend_changes = detect_trend_changes(shap_values, features)
    print("\n检测到的显著趋势变化:")
    if trend_changes['significant_changes']:
        for factor, shap_val in trend_changes['significant_changes'].items():
            print(f"  {factor}: {shap_val:.6f}")
    else:
        print("  未检测到显著趋势变化")
    
    # 7. 总结
    print("\n7. 总结")
    print("动量信号模型构建完成。模型能够：")
    print("  1. 计算短期、中期和长期动量因子")
    print("  2. 使用随机森林模型预测市场趋势")
    print("  3. 通过Optuna优化模型超参数")
    print("  4. 使用SHAP解释模型预测结果")
    print("  5. 监控不同动量因子的表现")
    print("  6. 检测市场趋势是否发生变化")
    
    print("\n模型性能指标:")
    print(f"  信息比率 (IR): {evaluation_metrics['information_ratio']:.4f}")
    print(f"  均方根误差 (RMSE): {evaluation_metrics['rmse']:.6f}")


def main():
    """
    主函数
    """
    # 使用转换后的申万行业数据运行模型
    run_sw_industry_model('converted_sw_industry_data.csv')


if __name__ == "__main__":
    main()