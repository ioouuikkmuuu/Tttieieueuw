"""
验证tushare token有效性
"""

import tushare as ts
from tushare_config import tushare_token

# 设置tushare token
ts.set_token(tushare_token)
pro = ts.pro_api()

print("正在验证token...")

# 方法1: 尝试获取用户信息
try:
    user_info = pro.user()
    if not user_info.empty:
        print("Token有效")
        print("用户信息:")
        print(user_info)
    else:
        print("Token无效或权限不足")
except Exception as e:
    print(f"验证token时出错: {e}")

# 方法2: 尝试获取一个简单的接口
try:
    # 获取tushare版本信息
    version_info = pro.version()
    print("\n版本信息:")
    print(version_info)
except Exception as e:
    print(f"\n获取版本信息时出错: {e}")
    print("这可能是接口不存在或权限不足")

# 方法3: 直接检查token长度和格式
print(f"\nToken长度: {len(tushare_token)}")
if len(tushare_token) == 56 and tushare_token.isalnum():
    print("Token格式正确")
else:
    print("Token格式可能不正确")