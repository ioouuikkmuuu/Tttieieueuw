"""
调试tushare接口调用 - 版本2
"""

import tushare as ts
from tushare_config import tushare_token

# 设置tushare token
ts.set_token(tushare_token)
pro = ts.pro_api()

# 测试获取股票列表 - 不带参数
print("正在测试获取股票列表(不带参数)...")
try:
    stock_list = pro.stock_basic()
    print(f"成功获取到{len(stock_list)}只股票")
    print(stock_list.head())
except Exception as e:
    print(f"获取股票列表时出错: {e}")

# 测试获取股票列表 - 带部分参数
print("\n正在测试获取股票列表(带部分参数)...")
try:
    stock_list = pro.stock_basic(list_status='L')
    print(f"成功获取到{len(stock_list)}只股票")
    print(stock_list.head())
except Exception as e:
    print(f"获取股票列表时出错: {e}")