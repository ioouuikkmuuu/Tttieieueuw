import pandas as pd
import os

def convert_excel_to_csv():
    # 定义文件路径
    excel_file_path = 'data/test a.xlsx'
    csv_file_path = 'data/sw_industry_daily_returns.csv'
    
    # 检查Excel文件是否存在
    if not os.path.exists(excel_file_path):
        print(f"Excel文件 {excel_file_path} 不存在")
        return
    
    # 读取Excel文件
    try:
        # 读取第一个工作表
        df = pd.read_excel(excel_file_path, sheet_name=0)
        
        # 保存为CSV文件
        df.to_csv(csv_file_path, index=False)
        print(f"成功将 {excel_file_path} 转换为 {csv_file_path}")
        print("数据预览：")
        print(df.head())
        
    except Exception as e:
        print(f"转换过程中出现错误: {e}")

if __name__ == "__main__":
    convert_excel_to_csv()