"""
工具模块
包含通用的工具函数
"""

import pandas as pd
import numpy as np
from typing import Any, Dict, List


def validate_data(data: pd.DataFrame, required_columns: List[str]) -> bool:
    """
    验证数据是否包含必需的列
    
    Parameters:
    data (pd.DataFrame): 要验证的数据
    required_columns (List[str]): 必需的列名列表
    
    Returns:
    bool: 数据是否有效
    """
    missing_columns = set(required_columns) - set(data.columns)
    if missing_columns:
        print(f"数据缺少以下必需列: {missing_columns}")
        return False
    return True


def calculate_returns(prices: pd.Series, period: int = 1) -> pd.Series:
    """
    计算收益率
    
    Parameters:
    prices (pd.Series): 价格序列
    period (int): 计算收益率的周期
    
    Returns:
    pd.Series: 收益率序列
    """
    returns = prices.pct_change(period)
    return returns


def normalize_data(data: pd.DataFrame, columns: List[str] = None) -> pd.DataFrame:
    """
    标准化数据
    
    Parameters:
    data (pd.DataFrame): 要标准化的数据
    columns (List[str]): 要标准化的列名列表，如果为None则标准化所有数值列
    
    Returns:
    pd.DataFrame: 标准化后的数据
    """
    data_copy = data.copy()
    
    # 如果没有指定列，则选择所有数值列
    if columns is None:
        columns = data_copy.select_dtypes(include=[np.number]).columns.tolist()
    
    # 标准化指定列
    for col in columns:
        if col in data_copy.columns:
            mean = data_copy[col].mean()
            std = data_copy[col].std()
            if std != 0:
                data_copy[col] = (data_copy[col] - mean) / std
            else:
                data_copy[col] = 0
    
    return data_copy


def save_results_to_csv(results: Dict[str, Any], filename: str) -> None:
    """
    将结果保存到CSV文件
    
    Parameters:
    results (Dict[str, Any]): 要保存的结果
    filename (str): 文件名
    """
    # 将字典转换为DataFrame
    if isinstance(results, dict):
        # 如果值是标量，创建单行DataFrame
        if all(np.isscalar(v) for v in results.values()):
            df = pd.DataFrame([results])
        # 如果值是序列，创建多行DataFrame
        else:
            df = pd.DataFrame(results)
        
        # 保存到CSV
        df.to_csv(filename, index=False)
        print(f"结果已保存到 {filename}")
    else:
        print("结果格式不支持，无法保存到CSV")


def format_metrics_for_display(metrics: Dict[str, float]) -> str:
    """
    格式化指标用于显示
    
    Parameters:
    metrics (Dict[str, float]): 指标字典
    
    Returns:
    str: 格式化后的指标字符串
    """
    formatted = []
    for key, value in metrics.items():
        if isinstance(value, float):
            formatted.append(f"{key}: {value:.4f}")
        else:
            formatted.append(f"{key}: {value}")
    
    return "\n".join(formatted)


if __name__ == "__main__":
    # 这里可以添加测试代码
    pass