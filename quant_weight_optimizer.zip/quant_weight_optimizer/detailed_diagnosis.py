"""
详细诊断tushare连接问题
"""

import tushare as ts
from tushare_config import tushare_token
import sys

print("Python版本:", sys.version)
print("tushare版本:", ts.__version__ if hasattr(ts, '__version__') else "未知")

# 设置tushare token
ts.set_token(tushare_token)
pro = ts.pro_api()

print(f"\ntoken长度: {len(tushare_token)}")
print(f"token前10位: {tushare_token[:10]}")

# 检查API连接
print("\n检查API连接...")
try:
    # 尝试获取服务器时间
    api_time = pro.api()
    print("API连接成功")
    print("服务器时间:", api_time)
except Exception as e:
    print(f"API连接失败: {e}")

# 检查用户信息
print("\n检查用户信息...")
try:
    user_info = pro.user()
    if user_info.empty:
        print("用户信息为空，可能是token无效或权限不足")
    else:
        print("用户信息:")
        print(user_info)
except Exception as e:
    print(f"获取用户信息时出错: {e}")

# 尝试获取一个不需要高权限的接口
print("\n尝试获取不需要高权限的接口...")
try:
    # 获取市场信息
    markets = pro.api()
    print("市场信息获取成功")
    print(markets)
except Exception as e:
    print(f"获取市场信息时出错: {e}")