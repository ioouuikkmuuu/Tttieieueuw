import pandas as pd
import numpy as np
import argparse
from config import data_config, model_config, optimization_config, explanation_config
from data.data_generator import load_real_data
from factors.momentum_factors import calculate_momentum_factors
from model.predictor import MarketTrendPredictor
from optimization.hyperparameter_tuning import optimize_hyperparameters, update_model_with_optimal_params
from explanation.model_explanation import create_shap_explainer, calculate_shap_values

# 加载申万行业数据
print('加载申万行业数据...')
raw_data = load_real_data('converted_sw_industry_data_v2.csv')
print(f'加载了 {len(raw_data)} 条数据记录')

# 计算动量因子
print('计算动量因子...')
factor_data = calculate_momentum_factors(raw_data, data_config)
print(f'计算了 {len(factor_data)} 条因子数据记录')

# 创建预测器
predictor = MarketTrendPredictor(model_config)

# 准备特征和目标变量
features = predictor.prepare_features(factor_data)
target = predictor.prepare_target(factor_data)

# 超参数优化
print('进行超参数优化...')
optimization_result = optimize_hyperparameters(
    features, 
    target, 
    optimization_config
)
print(f"最优参数: {optimization_result['best_params']}")
print(f"最优值 (RMSE): {optimization_result['best_value']:.6f}")

# 使用最优参数更新模型
update_model_with_optimal_params(predictor, optimization_result['best_params'])

# 重新训练模型
predictor.train(features, target)
print('模型训练完成')

# 创建SHAP解释器
explainer = create_shap_explainer(predictor, features)

# 解析命令行参数
parser = argparse.ArgumentParser(description='分析指定日期后一周的因子权重变化')
parser.add_argument('--start_date', type=str, default='2025-04-07', help='起始日期 (格式: YYYY-MM-DD)')
parser.add_argument('--end_date', type=str, help='结束日期 (格式: YYYY-MM-DD)')
args = parser.parse_args()

# 确定日期范围
start_date = pd.Timestamp(args.start_date)
if args.end_date:
    end_date = pd.Timestamp(args.end_date)
else:
    # 默认为起始日期后一周
    end_date = start_date + pd.Timedelta(days=7)

# 确保索引是日期类型
features_with_date = features.copy()
features_with_date['date'] = factor_data['date'].values
features_with_date['date'] = pd.to_datetime(features_with_date['date'])

# 分割数据
before_data = features_with_date[features_with_date['date'] < start_date]
week_data = features_with_date[(features_with_date['date'] >= start_date) & (features_with_date['date'] <= end_date)]

print(f'目标日期: {start_date} 到 {end_date}')
print(f'目标日期前的数据点数量: {len(before_data)}')
print(f'目标日期后一周的数据点数量: {len(week_data)}')

# 检查一周内是否有数据
if len(week_data) == 0:
    print('目标日期后一周内没有数据，无法进行分析')
    exit()

# 计算两个时期的SHAP值
before_shap_values = calculate_shap_values(explainer, before_data.drop('date', axis=1), explanation_config)
week_shap_values = calculate_shap_values(explainer, week_data.drop('date', axis=1), explanation_config)

# 计算平均SHAP值
before_mean_shap = np.mean(np.abs(before_shap_values), axis=0)
week_mean_shap = np.mean(np.abs(week_shap_values), axis=0)

# 创建比较DataFrame
comparison_df = pd.DataFrame({
    'feature': features.columns.tolist(),
    'before_mean_shap': before_mean_shap,
    'week_mean_shap': week_mean_shap,
    'change': week_mean_shap - before_mean_shap,
    'change_percentage': (week_mean_shap - before_mean_shap) / before_mean_shap * 100
})

print('\n因子权重变化分析:')
print(comparison_df.to_string(index=False))