"""
模型配置文件
包含各种参数设置和配置选项
"""

# 数据配置
data_config = {
    # 动量窗口设置
    'momentum_windows': {
        'short': 21,      # 短期动量窗口（交易日）
        'medium': 63,     # 中期动量窗口（交易日）
        'long': 252       # 长期动量窗口（交易日）
    },
    
    # 目标变量设置
    'target_config': {
        'prediction_horizon': 5,   # 预测周期（交易日）
        'return_type': 'log'       # 收益率类型: 'log' 或 'simple'
    }
}

# 模型配置
model_config = {
    # 随机森林默认参数
    'rf_default_params': {
        'n_estimators': 100,
        'max_depth': 10,
        'min_samples_split': 5,
        'min_samples_leaf': 2,
        'random_state': 42
    },
    
    # 特征重要性阈值
    'feature_importance_threshold': 0.01
}

# 超参数优化配置
optimization_config = {
    # Optuna优化参数
    'n_trials': 50,           # 试验次数
    'timeout': 3600,          # 超时时间（秒）
    'direction': 'minimize',  # 优化方向
    'metric': 'rmse',         # 优化指标
    
    # 参数搜索空间
    'search_space': {
        'n_estimators': {
            'type': 'int',
            'low': 50,
            'high': 300
        },
        'max_depth': {
            'type': 'int',
            'low': 3,
            'high': 20
        },
        'min_samples_split': {
            'type': 'int',
            'low': 2,
            'high': 20
        },
        'min_samples_leaf': {
            'type': 'int',
            'low': 1,
            'high': 10
        }
    }
}

# 模型解释配置
explanation_config = {
    # SHAP配置
    'shap_config': {
        'sample_size': 1000,    # SHAP计算采样大小
        'plot_type': 'bar'      # SHAP图类型
    }
}

# 评估配置
evaluation_config = {
    # 性能评估参数
    'risk_free_rate': 0.02,    # 无风险利率（年化）
    'trading_days': 252        # 年交易日数
}