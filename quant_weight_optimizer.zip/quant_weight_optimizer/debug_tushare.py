"""
调试tushare接口调用
"""

import tushare as ts
from tushare_config import tushare_token

# 设置tushare token
ts.set_token(tushare_token)
pro = ts.pro_api()

# 测试获取股票列表
print("正在测试获取股票列表...")
try:
    stock_list = pro.stock_basic(exchange='', list_status='L', fields='ts_code,symbol,name')
    print(f"成功获取到{len(stock_list)}只股票")
    print(stock_list.head())
except Exception as e:
    print(f"获取股票列表时出错: {e}")

# 测试获取单只股票数据
print("\n正在测试获取单只股票数据...")
try:
    # 使用一个常见的股票代码测试
    df = pro.daily(ts_code='000001.SZ', start_date='20200101', end_date='20200131')
    print(f"成功获取到{len(df)}条数据记录")
    print(df.head())
except Exception as e:
    print(f"获取股票数据时出错: {e}")