"""
模型解释模块
使用SHAP解释模型预测结果，监控不同动量因子的表现
"""

import shap
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any, List
from model.predictor import MarketTrendPredictor


def create_shap_explainer(model: MarketTrendPredictor, features: pd.DataFrame) -> shap.Explainer:
    """
    创建SHAP解释器
    
    Parameters:
    model (MarketTrendPredictor): 训练好的市场趋势预测器
    features (pd.DataFrame): 特征数据
    
    Returns:
    shap.Explainer: SHAP解释器
    """
    # 创建TreeSHAP解释器
    explainer = shap.TreeExplainer(model.model)
    return explainer


def calculate_shap_values(explainer: shap.Explainer, features: pd.DataFrame, config: Dict = None) -> np.ndarray:
    """
    计算SHAP值
    
    Parameters:
    explainer (shap.Explainer): SHAP解释器
    features (pd.DataFrame): 特征数据
    config (Dict): SHAP配置参数
    
    Returns:
    np.ndarray: SHAP值
    """
    # 使用配置中的采样大小，如果未提供则使用全部数据
    if config and 'shap_config' in config:
        sample_size = config['shap_config'].get('sample_size', len(features))
        # 如果配置的采样大小小于特征数据长度，则进行采样
        if sample_size < len(features):
            features_sample = features.sample(n=sample_size, random_state=42)
        else:
            features_sample = features
    else:
        features_sample = features
    
    # 计算SHAP值
    shap_values = explainer.shap_values(features_sample)
    return shap_values


def plot_shap_summary(shap_values: np.ndarray, features: pd.DataFrame, feature_names: List[str] = None) -> None:
    """
    绘制SHAP摘要图
    
    Parameters:
    shap_values (np.ndarray): SHAP值
    features (pd.DataFrame): 特征数据
    feature_names (List[str]): 特征名称列表
    """
    # 如果没有提供特征名称，则使用特征数据的列名
    if feature_names is None:
        feature_names = features.columns.tolist()
    
    # 绘制SHAP摘要图
    shap.summary_plot(shap_values, features, feature_names=feature_names, show=False)
    plt.tight_layout()
    plt.savefig('shap_summary_plot.png')
    plt.close()


def analyze_factor_importance(shap_values: np.ndarray, feature_names: List[str]) -> pd.DataFrame:
    """
    分析因子重要性
    
    Parameters:
    shap_values (np.ndarray): SHAP值
    feature_names (List[str]): 特征名称列表
    
    Returns:
    pd.DataFrame: 因子重要性分析结果
    """
    # 计算每个特征的平均绝对SHAP值
    mean_abs_shap_values = np.mean(np.abs(shap_values), axis=0)
    
    # 创建重要性DataFrame
    importance_df = pd.DataFrame({
        'feature': feature_names,
        'importance': mean_abs_shap_values
    }).sort_values('importance', ascending=False)
    
    return importance_df


def detect_trend_changes(shap_values: np.ndarray, features: pd.DataFrame, threshold: float = 0.1) -> Dict[str, Any]:
    """
    检测市场趋势变化
    
    Parameters:
    shap_values (np.ndarray): SHAP值
    features (pd.DataFrame): 特征数据
    threshold (float): 趋势变化阈值
    
    Returns:
    Dict[str, Any]: 趋势变化检测结果
    """
    # 计算每个因子的SHAP值变化
    mean_shap_values = np.mean(shap_values, axis=0)
    
    # 获取特征名称
    feature_names = features.columns.tolist()
    
    # 检测显著变化的因子
    significant_changes = {}
    for i, (feature, shap_val) in enumerate(zip(feature_names, mean_shap_values)):
        if abs(shap_val) > threshold:
            significant_changes[feature] = shap_val
    
    return {
        'significant_changes': significant_changes,
        'mean_shap_values': dict(zip(feature_names, mean_shap_values))
    }


if __name__ == "__main__":
    # 这里可以添加测试代码
    pass