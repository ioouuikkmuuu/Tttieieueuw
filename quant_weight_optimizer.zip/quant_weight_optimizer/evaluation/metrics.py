"""
模型评估模块
计算模型性能指标，如信息比率(IR)等
"""

import pandas as pd
import numpy as np
from typing import Dict, List
from scipy import stats


def calculate_information_ratio(returns: pd.Series, benchmark_returns: pd.Series = None) -> float:
    """
    计算信息比率 (Information Ratio)
    
    Parameters:
    returns (pd.Series): 投资组合收益率序列
    benchmark_returns (pd.Series): 基准收益率序列，默认为0（即无风险收益率）
    
    Returns:
    float: 信息比率
    """
    # 如果没有提供基准收益率，则使用0作为基准
    if benchmark_returns is None:
        benchmark_returns = pd.Series(0, index=returns.index)
    
    # 计算超额收益
    excess_returns = returns - benchmark_returns
    
    # 计算信息比率
    mean_excess_return = np.mean(excess_returns)
    std_excess_return = np.std(excess_returns)
    
    # 避免除以零
    if std_excess_return == 0:
        return 0
    
    return mean_excess_return / std_excess_return


def calculate_sharpe_ratio(returns: pd.Series, risk_free_rate: float = 0.0, config: Dict = None) -> float:
    """
    计算夏普比率 (Sharpe Ratio)
    
    Parameters:
    returns (pd.Series): 投资组合收益率序列
    risk_free_rate (float): 无风险利率
    config (Dict): 评估配置参数
    
    Returns:
    float: 夏普比率
    """
    # 使用配置中的无风险利率，如果未提供则使用参数中的值
    if config and 'risk_free_rate' in config:
        risk_free_rate = config['risk_free_rate']
    
    # 计算超额收益
    excess_returns = returns - risk_free_rate
    
    # 计算夏普比率
    mean_excess_return = np.mean(excess_returns)
    std_excess_return = np.std(excess_returns)
    
    # 避免除以零
    if std_excess_return == 0:
        return 0
    
    return mean_excess_return / std_excess_return


def calculate_max_drawdown(returns: pd.Series) -> float:
    """
    计算最大回撤 (Max Drawdown)
    
    Parameters:
    returns (pd.Series): 投资组合收益率序列
    
    Returns:
    float: 最大回撤
    """
    # 计算累积收益
    cumulative_returns = (1 + returns).cumprod()
    
    # 计算运行最大值
    running_max = cumulative_returns.expanding().max()
    
    # 计算回撤
    drawdown = (cumulative_returns - running_max) / running_max
    
    # 返回最大回撤
    return drawdown.min()


def calculate_performance_metrics(returns: pd.Series, benchmark_returns: pd.Series = None, config: Dict = None) -> Dict[str, float]:
    """
    计算综合性能指标
    
    Parameters:
    returns (pd.Series): 投资组合收益率序列
    benchmark_returns (pd.Series): 基准收益率序列
    config (Dict): 评估配置参数
    
    Returns:
    Dict[str, float]: 性能指标字典
    """
    # 使用配置中的年交易日数，如果未提供则使用默认值
    if config and 'trading_days' in config:
        trading_days = config['trading_days']
    else:
        trading_days = 252
    
    metrics = {}
    
    # 计算信息比率
    metrics['information_ratio'] = calculate_information_ratio(returns, benchmark_returns)
    
    # 计算夏普比率
    if config:
        metrics['sharpe_ratio'] = calculate_sharpe_ratio(returns, risk_free_rate=config.get('risk_free_rate', 0.0), config=config)
    else:
        metrics['sharpe_ratio'] = calculate_sharpe_ratio(returns)
    
    # 计算最大回撤
    metrics['max_drawdown'] = calculate_max_drawdown(returns)
    
    # 计算年化收益率
    metrics['annualized_return'] = np.mean(returns) * trading_days
    
    # 计算年化波动率
    metrics['annualized_volatility'] = np.std(returns) * np.sqrt(trading_days)
    
    # 计算胜率
    metrics['win_rate'] = np.sum(returns > 0) / len(returns)
    
    return metrics


def compare_factor_performance(factor_returns: Dict[str, pd.Series]) -> pd.DataFrame:
    """
    比较不同因子的表现
    
    Parameters:
    factor_returns (Dict[str, pd.Series]): 不同因子的收益率序列
    
    Returns:
    pd.DataFrame: 因子表现比较结果
    """
    # 计算每个因子的性能指标
    results = []
    for factor_name, returns in factor_returns.items():
        metrics = calculate_performance_metrics(returns)
        metrics['factor'] = factor_name
        results.append(metrics)
    
    # 创建结果DataFrame
    comparison_df = pd.DataFrame(results)
    
    # 设置因子列为索引
    comparison_df = comparison_df.set_index('factor')
    
    return comparison_df


if __name__ == "__main__":
    # 这里可以添加测试代码
    pass