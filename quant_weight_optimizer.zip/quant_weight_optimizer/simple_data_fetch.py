"""
简单验证tushare daily price data获取
"""

import tushare as ts
from tushare_config import tushare_token

# 设置tushare token
ts.set_token(tushare_token)
pro = ts.pro_api()

# 获取单只股票的日线数据
print("正在获取平安银行(000001.SZ)的日线数据...")
try:
    # 获取平安银行近一个月的数据
    df = pro.daily(ts_code='000001.SZ', start_date='20230101', end_date='20230131')
    print(f"成功获取到{len(df)}条数据记录")
    if not df.empty:
        print("数据预览：")
        print(df.head())
        print("\n列名：")
        print(df.columns.tolist())
    else:
        print("数据为空")
except Exception as e:
    print(f"获取数据时出错: {e}")
    import traceback
    traceback.print_exc()