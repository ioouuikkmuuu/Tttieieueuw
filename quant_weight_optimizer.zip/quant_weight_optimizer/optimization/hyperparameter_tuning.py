"""
超参数优化模块
使用Optuna进行模型超参数优化
"""

import optuna
import pandas as pd
import numpy as np
from typing import Dict, Any
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from model.predictor import MarketTrendPredictor


def objective(trial: optuna.Trial, features: pd.DataFrame, target: pd.Series, config: Dict = None) -> float:
    """
    Optuna优化目标函数
    
    Parameters:
    trial (optuna.Trial): Optuna试验对象
    features (pd.DataFrame): 特征数据
    target (pd.Series): 目标变量
    config (Dict): 优化配置参数
    
    Returns:
    float: 优化目标值（负的RMSE）
    """
    # 使用配置中的参数搜索空间，如果未提供则使用默认值
    if config and 'search_space' in config:
        search_space = config['search_space']
        
        # 定义超参数搜索空间
        params = {}
        for param_name, param_config in search_space.items():
            if param_config['type'] == 'int':
                params[param_name] = trial.suggest_int(
                    param_name, 
                    param_config['low'], 
                    param_config['high']
                )
        params['random_state'] = 42
    else:
        # 默认搜索空间
        params = {
            'n_estimators': trial.suggest_int('n_estimators', 50, 300),
            'max_depth': trial.suggest_int('max_depth', 3, 15),
            'min_samples_split': trial.suggest_int('min_samples_split', 2, 20),
            'min_samples_leaf': trial.suggest_int('min_samples_leaf', 1, 10),
            'random_state': 42
        }
    
    # 创建模型
    model = MarketTrendPredictor()
    model.model.set_params(**params)
    
    # 分割数据
    valid_indices = ~target.isna()
    features_clean = features[valid_indices]
    target_clean = target[valid_indices]
    
    # 如果数据量不足，返回较差的结果
    if len(features_clean) < 10:
        return float('inf')
    
    # 分割训练和验证集
    X_train, X_val, y_train, y_val = train_test_split(
        features_clean, target_clean, test_size=0.2, random_state=42
    )
    
    # 训练模型
    model.model.fit(X_train, y_train)
    
    # 预测
    predictions = model.model.predict(X_val)
    
    # 计算RMSE
    rmse = np.sqrt(mean_squared_error(y_val, predictions))
    
    return rmse


def optimize_hyperparameters(features: pd.DataFrame, target: pd.Series, config: Dict = None) -> Dict[str, Any]:
    """
    使用Optuna优化超参数
    
    Parameters:
    features (pd.DataFrame): 特征数据
    target (pd.Series): 目标变量
    config (Dict): 优化配置参数
    
    Returns:
    Dict[str, Any]: 最优参数和结果
    """
    # 使用配置中的参数，如果未提供则使用默认值
    if config:
        n_trials = config.get('n_trials', 50)
        timeout = config.get('timeout', 3600)
        direction = config.get('direction', 'minimize')
    else:
        n_trials = 50
        timeout = 3600
        direction = 'minimize'
    
    # 创建研究对象
    study = optuna.create_study(direction=direction)
    
    # 运行优化
    study.optimize(
        lambda trial: objective(trial, features, target, config), 
        n_trials=n_trials, 
        timeout=timeout
    )
    
    # 返回最优参数
    return {
        'best_params': study.best_params,
        'best_value': study.best_value,
        'study': study
    }


def update_model_with_optimal_params(model: MarketTrendPredictor, optimal_params: Dict[str, Any]) -> None:
    """
    使用最优参数更新模型
    
    Parameters:
    model (MarketTrendPredictor): 市场趋势预测器
    optimal_params (Dict[str, Any]): 最优参数
    """
    model.model.set_params(**optimal_params)


if __name__ == "__main__":
    # 这里可以添加测试代码
    pass