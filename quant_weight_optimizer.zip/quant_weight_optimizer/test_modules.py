"""
模块测试脚本
用于验证各个模块的功能
"""

import pandas as pd
import numpy as np

from data.data_generator import generate_simulated_data
from factors.momentum_factors import calculate_momentum_factors, get_factor_descriptions
from model.predictor import MarketTrendPredictor
from optimization.hyperparameter_tuning import optimize_hyperparameters
from explanation.model_explanation import create_shap_explainer, calculate_shap_values, analyze_factor_importance
from evaluation.metrics import calculate_information_ratio, calculate_performance_metrics
from utils.helpers import validate_data, calculate_returns


def test_data_generation():
    """测试数据生成模块"""
    print("=== 测试数据生成模块 ===")
    data = generate_simulated_data(n_stocks=5, n_days=100)
    print(f"生成了 {len(data)} 条数据记录")
    print(f"数据列: {list(data.columns)}")
    print(f"股票数量: {data['stock_code'].nunique()}")
    print()


def test_factor_calculation():
    """测试因子计算模块"""
    print("=== 测试因子计算模块 ===")
    # 生成测试数据
    raw_data = generate_simulated_data(n_stocks=10, n_days=252)
    
    # 计算动量因子
    factor_data = calculate_momentum_factors(raw_data)
    
    # 显示因子描述
    factor_descriptions = get_factor_descriptions()
    print("因子描述:")
    for factor, description in factor_descriptions.items():
        print(f"  {factor}: {description}")
    
    # 检查因子值
    print(f"\n因子数据记录数: {len(factor_data)}")
    print(f"因子列: {list(factor_data.columns)}")
    
    # 显示部分因子值
    print("\n部分因子值:")
    print(factor_data[['stock_code', 'date', 'short_momentum', 'medium_momentum', 'long_momentum']].head(10))
    print()


def test_model_training():
    """测试模型训练模块"""
    print("=== 测试模型训练模块 ===")
    # 生成测试数据
    raw_data = generate_simulated_data(n_stocks=20, n_days=300)
    
    # 计算动量因子
    factor_data = calculate_momentum_factors(raw_data)
    
    # 创建预测器
    predictor = MarketTrendPredictor()
    
    # 准备特征和目标变量
    features = predictor.prepare_features(factor_data)
    target = predictor.prepare_target(factor_data)
    
    # 验证数据
    required_features = ['short_momentum', 'medium_momentum', 'long_momentum']
    if not validate_data(features, required_features):
        print("特征数据验证失败")
        return
    
    print(f"特征数据形状: {features.shape}")
    print(f"目标变量形状: {target.shape}")
    
    # 训练模型
    predictor.train(features, target)
    print("模型训练完成")
    
    # 进行预测
    predictions = predictor.predict(features)
    print(f"预测结果形状: {predictions.shape}")
    
    # 评估模型
    evaluation_metrics = predictor.evaluate(features, target)
    print("模型评估指标:")
    for metric, value in evaluation_metrics.items():
        print(f"  {metric}: {value:.6f}")
    print()


def test_hyperparameter_optimization():
    """测试超参数优化模块"""
    print("=== 测试超参数优化模块 ===")
    # 生成测试数据
    raw_data = generate_simulated_data(n_stocks=15, n_days=200)
    
    # 计算动量因子
    factor_data = calculate_momentum_factors(raw_data)
    
    # 创建预测器
    predictor = MarketTrendPredictor()
    
    # 准备特征和目标变量
    features = predictor.prepare_features(factor_data)
    target = predictor.prepare_target(factor_data)
    
    # 验证数据
    required_features = ['short_momentum', 'medium_momentum', 'long_momentum']
    if not validate_data(features, required_features):
        print("特征数据验证失败")
        return
    
    # 执行超参数优化（减少试验次数以加快测试）
    # 创建测试配置
    test_config = {
        'n_trials': 5,
        'timeout': 300,
        'direction': 'minimize'
    }
    optimization_result = optimize_hyperparameters(features, target, config=test_config)
    print(f"最优参数: {optimization_result['best_params']}")
    print(f"最优值 (RMSE): {optimization_result['best_value']:.6f}")
    print()


def test_model_explanation():
    """测试模型解释模块"""
    print("=== 测试模型解释模块 ===")
    # 生成测试数据
    raw_data = generate_simulated_data(n_stocks=10, n_days=252)
    
    # 计算动量因子
    factor_data = calculate_momentum_factors(raw_data)
    
    # 创建预测器
    predictor = MarketTrendPredictor()
    
    # 准备特征和目标变量
    features = predictor.prepare_features(factor_data)
    target = predictor.prepare_target(factor_data)
    
    # 训练模型
    predictor.train(features, target)
    
    # 创建SHAP解释器
    explainer = create_shap_explainer(predictor, features)
    print("SHAP解释器创建完成")
    
    # 计算SHAP值
    shap_values = calculate_shap_values(explainer, features)
    print(f"SHAP值形状: {shap_values.shape}")
    
    # 分析因子重要性
    importance_df = analyze_factor_importance(shap_values, features.columns.tolist())
    print("\n因子重要性排序:")
    print(importance_df.to_string(index=False))
    print()


def test_evaluation_metrics():
    """测试评估指标模块"""
    print("=== 测试评估指标模块 ===")
    # 生成模拟收益率数据
    np.random.seed(42)
    returns = pd.Series(np.random.normal(0.001, 0.02, 252))  # 252个交易日的模拟收益率
    
    # 计算信息比率
    ir = calculate_information_ratio(returns)
    print(f"信息比率 (IR): {ir:.6f}")
    
    # 计算综合性能指标
    metrics = calculate_performance_metrics(returns)
    print("\n综合性能指标:")
    for metric, value in metrics.items():
        print(f"  {metric}: {value:.6f}")
    print()


def test_utils():
    """测试工具模块"""
    print("=== 测试工具模块 ===")
    # 生成测试数据
    data = generate_simulated_data(n_stocks=5, n_days=100)
    
    # 测试数据验证
    required_columns = ['date', 'stock_code', 'close_price']
    is_valid = validate_data(data, required_columns)
    print(f"数据验证结果: {'通过' if is_valid else '失败'}")
    
    # 测试收益率计算
    sample_prices = data[data['stock_code'] == data['stock_code'].iloc[0]]['close_price']
    returns = calculate_returns(sample_prices)
    print(f"收益率序列长度: {len(returns)}")
    print(f"收益率示例: {returns.tail().values}")
    print()


def main():
    """主测试函数"""
    print("开始模块测试\n")
    
    test_data_generation()
    test_factor_calculation()
    test_model_training()
    test_hyperparameter_optimization()
    test_model_explanation()
    test_evaluation_metrics()
    test_utils()
    
    print("所有模块测试完成")


if __name__ == "__main__":
    main()