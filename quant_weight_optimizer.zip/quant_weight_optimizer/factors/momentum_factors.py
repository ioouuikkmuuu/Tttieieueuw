"""
动量因子计算模块
包含短期、中期和长期动量因子的计算方法
"""

import pandas as pd
import numpy as np
from typing import Dict, Optional


def calculate_momentum_factors(data: pd.DataFrame, config: Optional[Dict] = None) -> pd.DataFrame:
    """
    计算动量因子
    
    Parameters:
    data (pd.DataFrame): 包含股票价格数据的DataFrame，必须包含date, stock_code, close_price列
    config (Optional[Dict]): 配置参数，包含动量窗口设置
    
    Returns:
    pd.DataFrame: 包含动量因子的DataFrame
    """
    # 确保数据按日期排序
    data = data.sort_values(['stock_code', 'date']).reset_index(drop=True)
    
    # 计算收益率
    data['return'] = data.groupby('stock_code')['close_price'].pct_change()
    
    # 使用配置中的窗口参数，如果未提供则使用默认值
    if config and 'momentum_windows' in config:
        short_window = config['momentum_windows'].get('short', 21)
        medium_window = config['momentum_windows'].get('medium', 63)
        long_window = config['momentum_windows'].get('long', 252)
    else:
        short_window, medium_window, long_window = 21, 63, 252
    
    # 计算不同时间窗口的动量因子
    # 短期动量
    data['short_momentum'] = data.groupby('stock_code')['return'].rolling(
        window=short_window, min_periods=short_window).mean().reset_index(0, drop=True)
    
    # 中期动量
    data['medium_momentum'] = data.groupby('stock_code')['return'].rolling(
        window=medium_window, min_periods=medium_window).mean().reset_index(0, drop=True)
    
    # 长期动量
    data['long_momentum'] = data.groupby('stock_code')['return'].rolling(
        window=long_window, min_periods=long_window).mean().reset_index(0, drop=True)
    
    return data


def get_factor_descriptions(config: Optional[Dict] = None) -> Dict[str, str]:
    """
    获取因子描述信息
    
    Parameters:
    config (Optional[Dict]): 配置参数，包含动量窗口设置
    
    Returns:
    Dict[str, str]: 因子名称和描述的映射
    """
    # 使用配置中的窗口参数，如果未提供则使用默认值
    if config and 'momentum_windows' in config:
        short_window = config['momentum_windows'].get('short', 21)
        medium_window = config['momentum_windows'].get('medium', 63)
        long_window = config['momentum_windows'].get('long', 252)
    else:
        short_window, medium_window, long_window = 21, 63, 252
    
    return {
        'short_momentum': f'短期动量因子，基于过去{short_window}个交易日的平均收益率',
        'medium_momentum': f'中期动量因子，基于过去{medium_window}个交易日的平均收益率',
        'long_momentum': f'长期动量因子，基于过去{long_window}个交易日的平均收益率'
    }


if __name__ == "__main__":
    # 这里可以添加测试代码
    pass