# 量化权重优化器 (Quant Weight Optimizer)

这是一个用于预测市场趋势变化的动量信号模型，通过SHAP监控短中长三类动量因子的表现，判断市场趋势是否发生变化，并通过Optuna动态调节超参数，使得模型更好地捕捉市场变化。

## 项目结构

```
quant_weight_optimizer/
├── data/                 # 数据处理模块
│   ├── data_generator.py # 模拟数据生成器
│   └── tushare_data_fetcher.py # tushare数据获取器
├── factors/              # 因子计算模块
│   └── momentum_factors.py # 动量因子计算
├── model/                # 模型模块
│   └── predictor.py      # 市场趋势预测器
├── optimization/         # 超参数优化模块
│   └── hyperparameter_tuning.py # 超参数优化
├── explanation/          # 模型解释模块
│   └── model_explanation.py # 模型解释和趋势变化检测
├── evaluation/           # 模型评估模块
│   └── metrics.py        # 性能指标计算
├── utils/                # 工具模块
│   └── helpers.py        # 通用工具函数
├── main.py               # 主程序入口
└── requirements.txt      # 项目依赖
```

## 功能特点

1. **动量因子计算**：计算短期、中期和长期动量因子
2. **机器学习预测**：使用随机森林模型预测市场趋势
3. **超参数优化**：通过Optuna自动优化模型超参数
4. **模型解释**：使用SHAP解释模型预测结果
5. **趋势监控**：监控不同动量因子的表现，检测市场趋势变化
6. **性能评估**：计算信息比率(IR)等指标评估模型性能

## 安装依赖

```bash
pip install -r requirements.txt
```

## 使用方法

### 1. 使用模拟数据

```bash
python main.py
```

### 1.1 使用演示数据

如果遇到tushare token问题，可以使用演示数据来体验项目功能：

```bash
# 生成演示数据
python run_with_demo_data.py

# 使用演示数据运行模型
python main.py
```

在`main.py`中，确保以下代码被注释掉或修改为使用演示数据：

```python
if __name__ == "__main__":
    # 使用模拟数据运行
    main()
    
    # 如果生成了演示数据，可以使用以下代码运行
    # main(use_real_data=True, real_data_path="demo_stock_data.csv")
```

### 2. 使用真实数据

#### 2.1 获取tushare token

1. 访问 [tushare官网](https://tushare.pro/) 注册账号
2. 获取您的token

#### 2.2 设置tushare token

请在`tushare_config.py`文件中设置您的tushare token：

1. 打开`tushare_config.py`文件
2. 将`your_real_tushare_token_here`替换为您从[tushare官网](https://tushare.pro/)获取的真实token

#### 2.3 真实数据格式

真实数据需要符合以下格式：

| 列名 | 类型 | 描述 |
|------|------|------|
| date | datetime | 交易日期 |
| stock_code | string | 股票代码 (如: 000001.SZ) |
| close_price | float | 收盘价 |

示例数据：
```csv
date,stock_code,close_price
2020-01-02,000001.SZ,15.87
2020-01-03,000001.SZ,15.91
2020-01-06,000001.SZ,15.80
```

#### 2.4 获取数据

```bash
python data/tushare_data_fetcher.py
```

此脚本将从tushare获取股票数据并保存为`real_stock_data.csv`文件。

#### 2.5 运行模型

要使用真实数据运行模型，请修改`main.py`文件末尾的执行代码，取消注释并设置正确的数据文件路径：

```python
if __name__ == "__main__":
    # 使用模拟数据运行
    main()
    
    # 使用真实数据运行
    main(use_real_data=True, real_data_path="real_stock_data.csv")
```

### 3. 使用申万行业数据

#### 3.1 数据格式

申万行业数据需要符合以下格式：

| 列名 | 类型 | 描述 |
|------|------|------|
| date | datetime | 交易日期 |
| industry_name | string | 行业名称 (如: 银行) |
| return | float | 日收益率 |

示例数据：
```csv
date,industry_name,return
2020-01-01,银行,0.005
2020-01-01,保险,0.003
2020-01-02,银行,0.001
2020-01-02,保险,-0.002
```

#### 3.2 数据处理

1. 将申万行业数据保存为CSV文件 (例如: `sw_industry_data.csv`)
2. 运行数据处理器脚本:

```bash
python -m data.sw_industry_data_processor
```

此脚本将处理数据并生成`converted_sw_industry_data.csv`文件，该文件格式与模型兼容。

#### 3.3 运行模型

使用处理后的申万行业数据运行模型：

```bash
python run_sw_industry_model.py
```

此脚本将自动加载处理后的数据，计算动量因子，训练模型，并输出性能指标。

## 模块说明

### data/data_generator.py

- `generate_simulated_data()`: 生成模拟的股票价格数据用于测试
- `load_real_data()`: 加载真实数据

### data/tushare_data_fetcher.py

- `get_stock_list()`: 获取股票列表
- `get_stock_data()`: 获取单只股票的历史数据
- `fetch_real_data()`: 获取多只股票的历史数据

### factors/momentum_factors.py

- `calculate_momentum_factors()`: 计算短期、中期和长期动量因子
- `get_factor_descriptions()`: 获取因子描述信息

### model/predictor.py

- `MarketTrendPredictor`: 市场趋势预测器类
  - `prepare_features()`: 准备特征数据
  - `prepare_target()`: 准备目标变量
  - `train()`: 训练模型
  - `predict()`: 进行预测
  - `evaluate()`: 评估模型性能

### optimization/hyperparameter_tuning.py

- `optimize_hyperparameters()`: 使用Optuna优化超参数
- `update_model_with_optimal_params()`: 使用最优参数更新模型

### explanation/model_explanation.py

- `create_shap_explainer()`: 创建SHAP解释器
- `calculate_shap_values()`: 计算SHAP值
- `analyze_factor_importance()`: 分析因子重要性
- `detect_trend_changes()`: 检测市场趋势变化

### evaluation/metrics.py

- `calculate_information_ratio()`: 计算信息比率
- `calculate_sharpe_ratio()`: 计算夏普比率
- `calculate_max_drawdown()`: 计算最大回撤
- `calculate_performance_metrics()`: 计算综合性能指标

### utils/helpers.py

- `validate_data()`: 验证数据完整性
- `calculate_returns()`: 计算收益率
- `normalize_data()`: 标准化数据
- `save_results_to_csv()`: 保存结果到CSV文件
- `format_metrics_for_display()`: 格式化指标用于显示

## 项目工作流程

1. **数据准备**：生成模拟数据或加载真实数据
2. **因子计算**：计算短、中、长期动量因子
3. **模型训练**：使用随机森林模型训练预测器
4. **超参数优化**：通过Optuna优化模型超参数
5. **模型评估**：计算信息比率等指标评估模型性能
6. **模型解释**：使用SHAP解释模型预测结果
7. **趋势监控**：监控因子表现，检测市场趋势变化

## Jupyter Notebook演示

项目包含了Jupyter Notebook演示文件，用于交互式地展示模型的使用方法和结果：

1. `momentum_signal_model_demo.ipynb`：使用模拟数据的完整演示
2. `sw_industry_momentum_model_demo.ipynb`：使用申万行业数据的完整演示
3. `sw_industry_shap_analysis.ipynb`：分析指定日期前后短中长期因子权重变化的SHAP分析演示

要运行这些演示，请启动Jupyter Notebook服务器：

```bash
jupyter notebook
```

然后在浏览器中打开相应的`.ipynb`文件。

对于`sw_industry_shap_analysis.ipynb`，可以通过修改Notebook中的`--target_date`参数来自定义分析日期。

## 注意事项

- 项目目前使用模拟数据进行测试，如需使用真实数据，可以使用tushare数据获取器
- 模型超参数优化的试验次数可以在`main.py`中调整`n_trials`参数
- SHAP趋势变化检测的阈值可以在`model_explanation.py`中调整`threshold`参数
- 使用tushare获取数据需要有效的token，可以在[tushare官网](https://tushare.pro/)注册获取
- tushare token需要在`tushare_config.py`文件中设置
- `analyze_shap_change_week.py`和`analyze_shap_comprehensive.py`脚本支持通过命令行参数自定义分析日期，具体请查看脚本帮助信息