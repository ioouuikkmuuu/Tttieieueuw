#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
测试Excel文件分割器的示例脚本
"""

import os
import sys

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from file_split import FileSplitter

def main():
    print("开始测试Excel文件分割器...")
    
    # 创建文件分割器实例 - 按类别分割Excel文件
    print("\n1. 按Category列分割Excel文件:")
    splitter1 = FileSplitter(
        file_pattern="sample_data.xlsx",
        split_col_identifier="Category",
        output_format="excel_products_by_{value}.xlsx"
    )
    
    # 执行分割
    splitter1.split_files(output_directory="excel_output")
    
    print("\nExcel文件分割完成！请查看excel_output目录中的结果文件。")

if __name__ == "__main__":
    main()