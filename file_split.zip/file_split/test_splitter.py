#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
测试文件分割器的示例脚本
"""

import os
import sys

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from file_split import FileSplitter

def main():
    print("开始测试文件分割器...")
    
    # 创建文件分割器实例 - 按类别分割
    print("\n1. 按Category列分割文件:")
    splitter1 = FileSplitter(
        file_pattern="sample_data.csv",
        split_col_identifier="Category",
        output_format="products_by_{value}.csv"
    )
    
    # 执行分割
    splitter1.split_files()
    
    # 创建另一个文件分割器实例 - 按销售员分割
    print("\n2. 按Salesperson列分割文件:")
    splitter2 = FileSplitter(
        file_pattern="sample_data.csv",
        split_col_identifier="Salesperson",
        output_format="sales_by_{value}.csv"
    )
    
    # 执行分割
    splitter2.split_files()
    
    print("\n文件分割完成！请查看output目录中的结果文件。")

if __name__ == "__main__":
    main()