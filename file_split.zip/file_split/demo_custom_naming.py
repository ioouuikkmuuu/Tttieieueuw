#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
演示自定义命名格式的示例脚本
展示如何在output format中使用identifier列下的具体值来命名文件
"""

import os
import sys

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from file_split import FileSplitter

def main():
    print("演示自定义命名格式...")
    
    # 示例1: 使用Category值作为文件名的一部分
    print("\n1. 按Category列分割，使用Category值命名:")
    splitter1 = FileSplitter(
        file_pattern="sample_data.csv",
        split_col_identifier="Category",
        output_format="{value}_products.csv"  # 使用{value}占位符，它会被替换为Category列的实际值
    )
    
    # 执行分割到custom_output1目录
    splitter1.split_files(output_directory="custom_output1")
    
    # 示例2: 使用Salesperson值作为文件名的一部分
    print("\n2. 按Salesperson列分割，使用Salesperson值命名:")
    splitter2 = FileSplitter(
        file_pattern="sample_data.csv",
        split_col_identifier="Salesperson",
        output_format="{value}_sales_data.csv"  # 使用{value}占位符，它会被替换为Salesperson列的实际值
    )
    
    # 执行分割到custom_output2目录
    splitter2.split_files(output_directory="custom_output2")
    
    # 示例3: 更复杂的命名格式
    print("\n3. 按Category列分割，使用复杂命名格式:")
    splitter3 = FileSplitter(
        file_pattern="sample_data.csv",
        split_col_identifier="Category",
        output_format="data_{value}_segment_2023.csv"  # 更复杂的格式
    )
    
    # 执行分割到custom_output3目录
    splitter3.split_files(output_directory="custom_output3")
    
    print("\n自定义命名演示完成！请查看各个output目录中的结果文件。")

if __name__ == "__main__":
    main()