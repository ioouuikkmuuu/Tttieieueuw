# 文件分割器 (File Splitter)

一个基于Python的文件分割工具，可以根据指定列的值将CSV或Excel文件分割成多个文件。

## 功能特点

- 支持CSV和Excel文件格式
- 根据指定列的唯一值进行分割
- 可自定义输出文件命名格式
- 自动创建输出目录
- 包含错误处理机制

## 安装依赖

```bash
pip install -r requirements.txt
```

## 使用方法

### 基本用法

```python
from file_split import FileSplitter

# 创建文件分割器实例
splitter = FileSplitter(
    file_pattern="*.csv",              # 文件模式
    split_col_identifier="Category",   # 分割列标识符
    output_format="split_{value}.csv"  # 输出文件命名格式
)

# 执行分割
splitter.split_files()
```

### 参数说明

- `file_pattern`: 文件模式（如 "*.csv" 或 "data*.xlsx"）
- `split_col_identifier`: 分割列标识符（列名）
- `output_format`: 输出文件命名格式，使用 `{value}` 占位符表示列的值

### 示例

假设有一个名为 `sales_data.csv` 的文件：

```csv
Product,Category,Price,Quantity
Apple,Fruit,1.2,100
Banana,Fruit,0.8,150
Carrot,Vegetable,0.5,200
Broccoli,Vegetable,1.5,80
```

使用以下代码进行分割：

```python
splitter = FileSplitter(
    file_pattern="sales_data.csv",
    split_col_identifier="Category",
    output_format="sales_{value}.csv"
)

splitter.split_files()
```

将会生成两个文件：
- `sales_Fruit.csv`
- `sales_Vegetable.csv`

## 方法说明

### `locate_files(directory=".")`
定位文件夹中符合模式的文件

### `split_files(directory=".", output_directory="output")`
分割所有找到的文件

### `_split_single_file(file_path, output_directory)`
分割单个文件（内部方法）

## 注意事项

- 确保输入文件格式正确
- 确保指定的列存在于文件中
- 输出目录将自动创建