# 自定义参数使用指南

## 功能说明

FileSplitter类现在支持在`file_pattern`和`output_format`中使用自定义参数。这些参数可以通过`custom_parameters`字典传递给类构造函数。

## 使用方法

### 1. 初始化时传递自定义参数

```python
from file_split import FileSplitter

# 定义自定义参数
custom_params = {
    "TODAY": "20251117",
    "VERSION": "v1.0",
    "PROJECT": "sales_data"
}

# 创建FileSplitter实例
splitter = FileSplitter(
    file_pattern="sample_data.csv",
    split_col_identifier="Category",
    output_format="{value}_{TODAY}.csv",
    custom_parameters=custom_params  # 传递自定义参数
)
```

### 2. 在output_format中使用参数

在`output_format`中，可以使用以下两种类型的占位符：

1. `{value}` - 自动替换为分割列的值
2. `{PARAM_NAME}` - 替换为`custom_parameters`中定义的参数值

示例：
```python
# 使用{value}和{TODAY}参数
output_format="{value}_{TODAY}.csv"

# 使用多个自定义参数
output_format="{PROJECT}_{value}_{TODAY}_{VERSION}.csv"
```

### 3. 在file_pattern中使用参数

同样，`file_pattern`也支持自定义参数：

```python
# 使用自定义参数作为文件模式的一部分
file_pattern="{PROJECT}_data.csv"
```

## 实际示例

### 示例1: 基本使用
```python
custom_params = {"TODAY": "20251117"}
splitter = FileSplitter(
    file_pattern="sample_data.csv",
    split_col_identifier="Category",
    output_format="{value}_{TODAY}.csv",
    custom_parameters=custom_params
)
```

生成的文件：
- `Fruit_20251117.csv`
- `Vegetable_20251117.csv`
- `Meat_20251117.csv`

### 示例2: 复杂参数使用
```python
custom_params = {
    "TODAY": "20251117",
    "VERSION": "v1.0",
    "PROJECT": "sales_data"
}
splitter = FileSplitter(
    file_pattern="sample_data.csv",
    split_col_identifier="Salesperson",
    output_format="{PROJECT}_{value}_{TODAY}_{VERSION}.csv",
    custom_parameters=custom_params
)
```

生成的文件：
- `sales_data_John_20251117_v1.0.csv`
- `sales_data_Jane_20251117_v1.0.csv`

## 与其他模块集成

要与您现有的模块集成，只需将该模块提供的参数作为字典传递给`custom_parameters`参数：

```python
# 假设您有一个日期处理模块
from your_date_module import get_today_string
from your_config_module import get_project_version

custom_params = {
    "TODAY": get_today_string(),  # 从您的模块获取日期
    "VERSION": get_project_version(),  # 从您的模块获取版本
    # 可以添加更多参数
}

splitter = FileSplitter(
    file_pattern="sample_data.csv",
    split_col_identifier="Category",
    output_format="{value}_{TODAY}_{VERSION}.csv",
    custom_parameters=custom_params
)
```

这样，您就可以轻松地将FileSplitter类与现有的参数提供模块集成。