# 命名约定演示说明

## 功能说明

FileSplitter类支持在输出文件名格式中使用identifier列下的具体值来命名文件。这是通过`output_format`参数中的`{value}`占位符实现的。

## 工作原理

当创建FileSplitter实例时，指定的`output_format`参数可以包含`{value}`占位符，该占位符会在文件分割过程中被替换为实际的列值。

例如：
```python
splitter = FileSplitter(
    file_pattern="sample_data.csv",
    split_col_identifier="Category",
    output_format="{value}_products.csv"  # {value}会被替换为Category列的实际值
)
```

## 演示结果

### 示例1: 基本命名格式
- 输入：按"Category"列分割
- 输出格式：`"{value}_products.csv"`
- 生成文件：
  - `Fruit_products.csv`
  - `Vegetable_products.csv`
  - `Meat_products.csv`

### 示例2: 销售员数据命名
- 输入：按"Salesperson"列分割
- 输出格式：`"{value}_sales_data.csv"`
- 生成文件：
  - `John_sales_data.csv`
  - `Jane_sales_data.csv`

### 示例3: 复杂命名格式
- 输入：按"Category"列分割
- 输出格式：`"data_{value}_segment_2023.csv"`
- 生成文件：
  - `data_Fruit_segment_2023.csv`
  - `data_Vegetable_segment_2023.csv`
  - `data_Meat_segment_2023.csv`

## 使用方法

要使用此功能，只需在创建FileSplitter实例时，在`output_format`参数中包含`{value}`占位符即可。系统会自动将每个分割文件中的列值替换到文件名中。