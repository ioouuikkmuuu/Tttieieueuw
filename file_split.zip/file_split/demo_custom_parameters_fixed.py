#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
演示自定义参数功能的示例脚本（修复版）
展示如何在file_pattern和output_format中使用自定义参数（如{TODAY}）
"""

import os
import sys
from datetime import datetime

# 添加当前目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from file_split import FileSplitter

def main():
    print("演示自定义参数功能...")
    
    # 模拟从其他模块获取的参数
    today = datetime.now().strftime("%Y%m%d")
    custom_params = {
        "TODAY": today,
        "VERSION": "v1.0",
        "PROJECT": "sales_data"
    }
    
    print(f"使用的自定义参数: {custom_params}")
    
    # 示例1: 在output_format中使用{TODAY}参数
    print("\n1. 在输出文件名中使用{TODAY}参数:")
    splitter1 = FileSplitter(
        file_pattern="sample_data.csv",
        split_col_identifier="Category",
        output_format="{value}_{TODAY}.csv",  # 使用{TODAY}占位符
        custom_parameters=custom_params
    )
    
    # 执行分割到custom_params_output1目录
    splitter1.split_files(output_directory="custom_params_output1")
    
    # 示例2: 在file_pattern中使用参数（假设我们有一些带日期标记的文件）
    print("\n2. 演示更复杂的参数使用:")
    splitter2 = FileSplitter(
        file_pattern="sample_data.csv",  # 这里也可以使用参数，例如 "{PROJECT}_data.csv"
        split_col_identifier="Salesperson",
        output_format="{PROJECT}_{value}_{TODAY}_{VERSION}.csv",
        custom_parameters=custom_params
    )
    
    # 执行分割到custom_params_output2目录
    splitter2.split_files(output_directory="custom_params_output2")
    
    # 示例3: 结合使用自定义参数和value参数避免文件名冲突
    print("\n3. 结合使用自定义参数和value参数:")
    splitter3 = FileSplitter(
        file_pattern="sample_data.csv",
        split_col_identifier="Category",
        output_format="{PROJECT}_{value}_summary_{TODAY}.csv",
        custom_parameters=custom_params
    )
    
    # 执行分割到custom_params_output3目录
    splitter3.split_files(output_directory="custom_params_output3")
    
    print("\n自定义参数演示完成！请查看各个output目录中的结果文件。")

if __name__ == "__main__":
    main()