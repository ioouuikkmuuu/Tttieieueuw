import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

class DataGenerator:
    """
    模拟数据生成器
    生成申万行业过去5年的日收益率数据
    """
    
    def __init__(self):
        # 申万一级行业列表
        self.sw_industries = [
            '农林牧渔', '采掘', '化工', '钢铁', '有色金属', '电子', '家用电器', 
            '食品饮料', '纺织服装', '轻工制造', '医药生物', '公用事业', 
            '交通运输', '房地产', '商业贸易', '休闲服务', '综合', '建筑材料',
            '建筑装饰', '电气设备', '国防军工', '计算机', '传媒', '通信',
            '银行', '非银金融', '汽车', '机械设备'
        ]
        
    def generate_trading_days(self, start_date='2019-01-01', end_date='2024-01-01'):
        """
        生成交易日序列（排除周末）
        """
        start = pd.to_datetime(start_date)
        end = pd.to_datetime(end_date)
        
        # 生成所有日期
        all_dates = pd.date_range(start=start, end=end, freq='D')
        
        # 排除周末
        trading_days = all_dates[all_dates.weekday < 5]
        
        return trading_days
    
    def generate_returns_data(self, start_date='2019-01-01', end_date='2024-01-01', 
                            volatility=0.02, trend=0.0001):
        """
        生成模拟的行业日收益率数据
        
        Parameters:
        -----------
        start_date : str
            开始日期
        end_date : str  
            结束日期
        volatility : float
            波动率参数
        trend : float
            趋势参数
            
        Returns:
        --------
        pd.DataFrame
            index: 交易日期
            columns: 申万行业
            values: 日收益率
        """
        trading_days = self.generate_trading_days(start_date, end_date)
        n_days = len(trading_days)
        n_industries = len(self.sw_industries)
        
        # 设置随机种子确保可重复性
        np.random.seed(42)
        
        # 生成相关性矩阵
        correlation_matrix = self.generate_correlation_matrix(n_industries)
        
        # 生成独立的随机数
        independent_returns = np.random.normal(0, volatility, (n_days, n_industries))
        
        # 应用相关性
        L = np.linalg.cholesky(correlation_matrix)
        correlated_returns = independent_returns @ L.T
        
        # 添加行业特定的趋势和波动
        industry_trends = np.random.normal(trend, trend/2, n_industries)
        industry_vols = np.random.uniform(0.8, 1.2, n_industries) * volatility
        
        # 调整收益率
        for i in range(n_industries):
            correlated_returns[:, i] = (correlated_returns[:, i] * industry_vols[i] + 
                                      industry_trends[i])
        
        # 创建DataFrame
        returns_df = pd.DataFrame(
            correlated_returns,
            index=trading_days,
            columns=self.sw_industries
        )
        
        return returns_df
    
    def generate_correlation_matrix(self, n_industries):
        """
        生成行业间相关性矩阵
        """
        # 创建基础相关性矩阵
        base_corr = 0.3  # 基础相关性
        correlation_matrix = np.full((n_industries, n_industries), base_corr)
        np.fill_diagonal(correlation_matrix, 1.0)
        
        # 添加一些随机性
        random_adj = np.random.uniform(-0.2, 0.2, (n_industries, n_industries))
        random_adj = (random_adj + random_adj.T) / 2  # 确保对称性
        np.fill_diagonal(random_adj, 0)
        
        correlation_matrix += random_adj
        
        # 确保矩阵正定
        eigenvals, eigenvecs = np.linalg.eigh(correlation_matrix)
        eigenvals = np.maximum(eigenvals, 0.01)  # 确保所有特征值为正
        correlation_matrix = eigenvecs @ np.diag(eigenvals) @ eigenvecs.T
        
        # 重新标准化对角线为1
        D = np.sqrt(np.diag(np.diag(correlation_matrix)))
        correlation_matrix = np.linalg.inv(D) @ correlation_matrix @ np.linalg.inv(D)
        
        return correlation_matrix
    
    def save_data(self, data, filename='sw_industry_returns.csv'):
        """
        保存数据到CSV文件
        """
        filepath = f'/Users/mac/Downloads/auxiliary/{filename}'
        data.to_csv(filepath)
        print(f"数据已保存到: {filepath}")
        return filepath
    
    def load_data(self, filename='sw_industry_returns.csv'):
        """
        从CSV文件加载数据
        """
        filepath = f'/Users/mac/Downloads/auxiliary/{filename}'
        try:
            data = pd.read_csv(filepath, index_col=0, parse_dates=True)
            print(f"数据已从 {filepath} 加载")
            return data
        except FileNotFoundError:
            print(f"文件 {filepath} 不存在")
            return None
    
    def get_data_info(self, data):
        """
        获取数据基本信息
        """
        info = {
            'shape': data.shape,
            'date_range': (data.index.min(), data.index.max()),
            'industries': list(data.columns),
            'missing_values': data.isnull().sum().sum(),
            'mean_return': data.mean().mean(),
            'mean_volatility': data.std().mean()
        }
        return info

# 使用示例和接口函数
def generate_mock_data():
    """
    生成模拟数据的接口函数
    """
    generator = DataGenerator()
    
    # 生成过去5年数据
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=5*365)).strftime('%Y-%m-%d')
    
    print(f"正在生成 {start_date} 到 {end_date} 的模拟数据...")
    
    # 生成数据
    returns_data = generator.generate_returns_data(start_date, end_date)
    
    # 保存数据
    filepath = generator.save_data(returns_data)
    
    # 显示数据信息
    info = generator.get_data_info(returns_data)
    print("\n数据信息:")
    for key, value in info.items():
        print(f"{key}: {value}")
    
    return returns_data, filepath

def load_mock_data(filename='sw_industry_returns.csv'):
    """
    加载模拟数据的接口函数
    """
    generator = DataGenerator()
    return generator.load_data(filename)

if __name__ == "__main__":
    # 生成并保存模拟数据
    data, filepath = generate_mock_data()
    print(f"\n数据预览:")
    print(data.head())
    print(f"\n数据统计:")
    print(data.describe())