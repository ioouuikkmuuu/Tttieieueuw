import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

class Portfolio:
    """
    单个投资组合类
    管理持仓、现金、收益等信息
    """
    
    def __init__(self, name, portfolio_type, initial_capital=1000000):
        """
        初始化投资组合
        
        Parameters:
        -----------
        name : str
            组合名称
        portfolio_type : str
            组合类型 ('long_only', 'long_short', 'benchmark')
        initial_capital : float
            初始资金
        """
        self.name = name
        self.portfolio_type = portfolio_type
        self.initial_capital = initial_capital
        
        # 持仓信息
        self.positions = {}  # {industry: weight}
        self.cash = initial_capital
        self.nav = initial_capital
        
        # 历史记录
        self.history = []
        self.rebalance_history = []
        
        # 性能指标
        self.returns_series = pd.Series(dtype=float)
        self.cumulative_returns = pd.Series(dtype=float)
        
    def update_positions(self, new_positions, rebalance_date, rebalance_type='full'):
        """
        更新持仓
        
        Parameters:
        -----------
        new_positions : dict
            新持仓 {industry: weight}
        rebalance_date : pd.Timestamp
            调仓日期
        rebalance_type : str
            调仓类型 ('full', 'partial')
        """
        old_positions = self.positions.copy()
        
        # 记录调仓信息
        rebalance_info = {
            'date': rebalance_date,
            'type': rebalance_type,
            'old_positions': old_positions,
            'new_positions': new_positions.copy(),
            'nav_before': self.nav,
            'cash_before': self.cash
        }
        
        # 更新持仓
        self.positions = new_positions.copy()
        
        # 重置现金（调仓后损益兑现）
        if rebalance_type == 'full':
            self.cash = self.nav
            
        rebalance_info['nav_after'] = self.nav
        rebalance_info['cash_after'] = self.cash
        
        self.rebalance_history.append(rebalance_info)
        
    def calculate_daily_return(self, date, industry_returns):
        """
        计算单日收益率
        
        Parameters:
        -----------
        date : pd.Timestamp
            日期
        industry_returns : pd.Series
            当日各行业收益率
            
        Returns:
        --------
        float
            当日组合收益率
        """
        if not self.positions:
            return 0.0
            
        portfolio_return = 0.0
        
        for industry, weight in self.positions.items():
            if industry in industry_returns.index:
                portfolio_return += weight * industry_returns[industry]
                
        return portfolio_return
    
    def update_nav(self, date, industry_returns, is_special_date=False, 
                   date_type=None, rank_info=None):
        """
        更新净值
        
        Parameters:
        -----------
        date : pd.Timestamp
            日期
        industry_returns : pd.Series
            当日各行业收益率
        is_special_date : bool
            是否为特殊日期（调仓相关日期）
        date_type : str
            日期类型 ('rebalance_base', 'rebalance_prep', 'rebalance_effective')
        rank_info : dict
            排名信息
        """
        # 计算当日收益率
        daily_return = self.calculate_daily_return(date, industry_returns)
        
        # 更新净值
        self.nav = self.nav * (1 + daily_return)
        
        # 记录历史
        record = {
            'date': date,
            'nav': self.nav,
            'daily_return': daily_return,
            'cumulative_return': (self.nav / self.initial_capital) - 1,
            'cash': self.cash,
            'positions': self.positions.copy(),
            'is_special_date': is_special_date,
            'date_type': date_type,
            'rank_info': rank_info
        }
        
        self.history.append(record)
        
        # 更新收益率序列
        self.returns_series.loc[date] = daily_return
        self.cumulative_returns.loc[date] = (self.nav / self.initial_capital) - 1
        
    def get_performance_metrics(self):
        """
        计算性能指标
        
        Returns:
        --------
        dict
            性能指标字典
        """
        if len(self.returns_series) == 0:
            return {}
            
        returns = self.returns_series.dropna()
        
        # 基本指标
        total_return = (self.nav / self.initial_capital) - 1
        annualized_return = (1 + total_return) ** (252 / len(returns)) - 1
        volatility = returns.std() * np.sqrt(252)
        
        # 风险调整指标
        sharpe_ratio = annualized_return / volatility if volatility > 0 else 0
        
        # 最大回撤
        cumulative = (1 + returns).cumprod()
        rolling_max = cumulative.expanding().max()
        drawdown = (cumulative - rolling_max) / rolling_max
        max_drawdown = drawdown.min()
        
        # 信息比率（需要基准）
        ir = np.nan  # 将在组合管理器中计算
        
        return {
            'total_return': total_return,
            'annualized_return': annualized_return,
            'volatility': volatility,
            'sharpe_ratio': sharpe_ratio,
            'max_drawdown': max_drawdown,
            'information_ratio': ir,
            'final_nav': self.nav,
            'num_observations': len(returns)
        }
    
    def get_history_df(self):
        """
        获取历史记录DataFrame
        
        Returns:
        --------
        pd.DataFrame
            历史记录
        """
        if not self.history:
            return pd.DataFrame()
            
        df = pd.DataFrame(self.history)
        df.set_index('date', inplace=True)
        return df
    
    def get_rebalance_history_df(self):
        """
        获取调仓历史DataFrame
        
        Returns:
        --------
        pd.DataFrame
            调仓历史
        """
        if not self.rebalance_history:
            return pd.DataFrame()
            
        rebalance_records = []
        for record in self.rebalance_history:
            flat_record = {
                'date': record['date'],
                'type': record['type'],
                'nav_before': record['nav_before'],
                'nav_after': record['nav_after'],
                'cash_before': record['cash_before'],
                'cash_after': record['cash_after']
            }
            
            # 展开持仓变化
            all_industries = set(list(record['old_positions'].keys()) + 
                               list(record['new_positions'].keys()))
            
            for industry in all_industries:
                old_weight = record['old_positions'].get(industry, 0)
                new_weight = record['new_positions'].get(industry, 0)
                flat_record[f'old_{industry}'] = old_weight
                flat_record[f'new_{industry}'] = new_weight
                flat_record[f'change_{industry}'] = new_weight - old_weight
                
            rebalance_records.append(flat_record)
            
        df = pd.DataFrame(rebalance_records)
        if len(df) > 0:
            df.set_index('date', inplace=True)
        return df

class PortfolioManager:
    """
    投资组合管理器
    管理多个投资组合，执行调仓逻辑
    """
    
    def __init__(self, returns_data):
        """
        初始化组合管理器
        
        Parameters:
        -----------
        returns_data : pd.DataFrame
            行业收益率数据
        """
        self.returns_data = returns_data
        self.portfolios = {}
        self.benchmark_portfolio = None
        
    def create_portfolio(self, name, portfolio_type, initial_capital=1000000):
        """
        创建投资组合
        
        Parameters:
        -----------
        name : str
            组合名称
        portfolio_type : str
            组合类型
        initial_capital : float
            初始资金
            
        Returns:
        --------
        Portfolio
            创建的组合对象
        """
        portfolio = Portfolio(name, portfolio_type, initial_capital)
        self.portfolios[name] = portfolio
        
        if portfolio_type == 'benchmark':
            self.benchmark_portfolio = portfolio
            
        return portfolio
    
    def calculate_target_positions(self, ranking_df, strategy_config):
        """
        根据排名和策略配置计算目标持仓
        
        Parameters:
        -----------
        ranking_df : pd.DataFrame
            行业排名数据
        strategy_config : dict
            策略配置 {
                'long_top_n': int,
                'short_bottom_n': int,
                'long_weight': float,
                'short_weight': float
            }
            
        Returns:
        --------
        dict
            目标持仓 {industry: weight}
        """
        if ranking_df is None or len(ranking_df) == 0:
            return {}
            
        positions = {}
        
        # Long positions (前N名)
        long_top_n = strategy_config.get('long_top_n', 0)
        if long_top_n > 0:
            top_industries = ranking_df.head(long_top_n)['industry'].tolist()
            long_weight_per_industry = strategy_config.get('long_weight', 1.0) / long_top_n
            
            for industry in top_industries:
                positions[industry] = long_weight_per_industry
                
        # Short positions (后N名)
        short_bottom_n = strategy_config.get('short_bottom_n', 0)
        if short_bottom_n > 0:
            bottom_industries = ranking_df.tail(short_bottom_n)['industry'].tolist()
            short_weight_per_industry = -strategy_config.get('short_weight', 1.0) / short_bottom_n
            
            for industry in bottom_industries:
                positions[industry] = short_weight_per_industry
                
        return positions
    
    def execute_rebalance(self, portfolio_name, target_positions, rebalance_date):
        """
        执行调仓
        
        Parameters:
        -----------
        portfolio_name : str
            组合名称
        target_positions : dict
            目标持仓
        rebalance_date : pd.Timestamp
            调仓日期
        """
        if portfolio_name not in self.portfolios:
            return
            
        portfolio = self.portfolios[portfolio_name]
        
        # 执行调仓（损益兑现，重置为现金）
        portfolio.update_positions(target_positions, rebalance_date, 'full')
        
    def run_backtest(self, rebalance_schedule, ranking_results, strategy_configs):
        """
        运行回测
        
        Parameters:
        -----------
        rebalance_schedule : pd.DataFrame
            调仓时间表
        ranking_results : dict
            排名结果 {date: ranking_df}
        strategy_configs : dict
            策略配置 {portfolio_name: strategy_config}
        """
        # 获取所有交易日
        all_dates = self.returns_data.index.sort_values()
        
        # 初始化调仓计划
        rebalance_plan = {}
        for _, row in rebalance_schedule.iterrows():
            base_date = row['rebalance_base_date']
            prep_date = row['rebalance_prep_date']
            effective_date = row['rebalance_effective_date']
            
            if base_date in ranking_results:
                ranking_df = ranking_results[base_date]
                
                # 为每个组合计算目标持仓
                for portfolio_name, strategy_config in strategy_configs.items():
                    if portfolio_name in self.portfolios:
                        target_positions = self.calculate_target_positions(ranking_df, strategy_config)
                        
                        if prep_date not in rebalance_plan:
                            rebalance_plan[prep_date] = {}
                        rebalance_plan[prep_date][portfolio_name] = {
                            'target_positions': target_positions,
                            'effective_date': effective_date,
                            'ranking_df': ranking_df
                        }
        
        # 逐日更新
        for date in all_dates:
            if date not in self.returns_data.index:
                continue
                
            industry_returns = self.returns_data.loc[date]
            
            # 检查是否为调仓准备日
            is_rebalance_prep = date in rebalance_plan
            is_rebalance_effective = False
            is_rebalance_base = False
            
            # 检查是否为调仓生效日
            for prep_date, prep_info in rebalance_plan.items():
                for portfolio_name, portfolio_info in prep_info.items():
                    if date == portfolio_info['effective_date']:
                        is_rebalance_effective = True
                        break
                        
            # 检查是否为调仓基准日
            for ranking_date in ranking_results.keys():
                if date == ranking_date:
                    is_rebalance_base = True
                    break
            
            # 确定日期类型
            date_type = None
            if is_rebalance_base:
                date_type = 'rebalance_base'
            elif is_rebalance_prep:
                date_type = 'rebalance_prep'
            elif is_rebalance_effective:
                date_type = 'rebalance_effective'
                
            is_special_date = any([is_rebalance_base, is_rebalance_prep, is_rebalance_effective])
            
            # 获取排名信息
            rank_info = None
            if is_rebalance_base and date in ranking_results:
                rank_info = ranking_results[date].to_dict('records')
            
            # 执行调仓（在调仓准备日）
            if is_rebalance_prep:
                for portfolio_name, portfolio_info in rebalance_plan[date].items():
                    self.execute_rebalance(
                        portfolio_name, 
                        portfolio_info['target_positions'], 
                        date
                    )
            
            # 更新所有组合的净值
            for portfolio in self.portfolios.values():
                portfolio.update_nav(
                    date, 
                    industry_returns, 
                    is_special_date, 
                    date_type, 
                    rank_info
                )
    
    def calculate_information_ratios(self):
        """
        计算信息比率（相对于基准）
        
        Returns:
        --------
        dict
            各组合的信息比率
        """
        if self.benchmark_portfolio is None:
            return {}
            
        benchmark_returns = self.benchmark_portfolio.returns_series
        information_ratios = {}
        
        for name, portfolio in self.portfolios.items():
            if name == self.benchmark_portfolio.name:
                continue
                
            portfolio_returns = portfolio.returns_series
            
            # 对齐日期
            common_dates = portfolio_returns.index.intersection(benchmark_returns.index)
            if len(common_dates) == 0:
                information_ratios[name] = np.nan
                continue
                
            portfolio_aligned = portfolio_returns.loc[common_dates]
            benchmark_aligned = benchmark_returns.loc[common_dates]
            
            # 计算超额收益
            excess_returns = portfolio_aligned - benchmark_aligned
            
            # 计算信息比率
            if excess_returns.std() > 0:
                ir = excess_returns.mean() / excess_returns.std() * np.sqrt(252)
            else:
                ir = np.nan
                
            information_ratios[name] = ir
            
        return information_ratios
    
    def get_all_performance_metrics(self):
        """
        获取所有组合的性能指标
        
        Returns:
        --------
        pd.DataFrame
            性能指标汇总
        """
        metrics_list = []
        information_ratios = self.calculate_information_ratios()
        
        for name, portfolio in self.portfolios.items():
            metrics = portfolio.get_performance_metrics()
            metrics['portfolio_name'] = name
            metrics['portfolio_type'] = portfolio.portfolio_type
            metrics['information_ratio'] = information_ratios.get(name, np.nan)
            metrics_list.append(metrics)
            
        return pd.DataFrame(metrics_list)
    
    def export_results(self, filename='portfolio_results.xlsx'):
        """
        导出回测结果
        
        Parameters:
        -----------
        filename : str
            文件名
        """
        filepath = f'/Users/mac/Downloads/auxiliary/{filename}'
        
        with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
            # 性能指标汇总
            performance_df = self.get_all_performance_metrics()
            performance_df.to_excel(writer, sheet_name='performance_summary', index=False)
            
            # 各组合的详细历史
            for name, portfolio in self.portfolios.items():
                # 净值历史
                history_df = portfolio.get_history_df()
                if len(history_df) > 0:
                    history_df.to_excel(writer, sheet_name=f'{name}_history')
                    
                # 调仓历史
                rebalance_df = portfolio.get_rebalance_history_df()
                if len(rebalance_df) > 0:
                    rebalance_df.to_excel(writer, sheet_name=f'{name}_rebalance')
                    
        print(f"回测结果已导出到: {filepath}")
        return filepath

# 使用示例函数
def create_sample_portfolios(returns_data):
    """
    创建示例投资组合
    
    Parameters:
    -----------
    returns_data : pd.DataFrame
        收益率数据
        
    Returns:
    --------
    PortfolioManager
        组合管理器
    """
    manager = PortfolioManager(returns_data)
    
    # 创建Long Only组合（前5名）
    manager.create_portfolio('Long_Top5', 'long_only', 1000000)
    
    # 创建Long/Short组合（前5名long，后5名short）
    manager.create_portfolio('LongShort_5_5', 'long_short', 1000000)
    
    # 创建基准组合（等权重）
    manager.create_portfolio('Equal_Weight_Benchmark', 'benchmark', 1000000)
    
    return manager

if __name__ == "__main__":
    # 示例用法
    from data_generator import load_mock_data
    
    # 加载数据
    returns_data = load_mock_data()
    
    if returns_data is not None:
        # 创建组合管理器
        manager = create_sample_portfolios(returns_data)
        
        print(f"\n创建了 {len(manager.portfolios)} 个投资组合:")
        for name, portfolio in manager.portfolios.items():
            print(f"  - {name} ({portfolio.portfolio_type}): {portfolio.initial_capital:,.0f} 元")