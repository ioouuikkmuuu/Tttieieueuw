import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

class RankingCalculator:
    """
    排名计算器
    计算过去N个月的绝对涨跌幅并进行排名
    """
    
    def __init__(self, returns_data):
        """
        初始化排名计算器
        
        Parameters:
        -----------
        returns_data : pd.DataFrame
            日收益率数据，index为日期，columns为行业
        """
        self.returns_data = returns_data.copy()
        self.cumulative_returns = (1 + self.returns_data).cumprod()
        
    def calculate_period_returns(self, end_date, lookback_months=3):
        """
        计算指定日期前N个月的累计收益率
        
        Parameters:
        -----------
        end_date : str or pd.Timestamp
            结束日期
        lookback_months : int
            回看月数
            
        Returns:
        --------
        pd.Series
            各行业在指定期间的累计收益率
        """
        end_date = pd.to_datetime(end_date)
        start_date = end_date - pd.DateOffset(months=lookback_months)
        
        # 找到最接近的交易日
        available_dates = self.returns_data.index
        
        # 找到开始日期
        start_dates_mask = available_dates <= start_date
        if start_dates_mask.any():
            actual_start_date = available_dates[start_dates_mask][-1]
        else:
            actual_start_date = available_dates[0]
            
        # 找到结束日期
        end_dates_mask = available_dates <= end_date
        if end_dates_mask.any():
            actual_end_date = available_dates[end_dates_mask][-1]
        else:
            return None
            
        # 计算期间收益率
        if actual_start_date in self.cumulative_returns.index and actual_end_date in self.cumulative_returns.index:
            start_values = self.cumulative_returns.loc[actual_start_date]
            end_values = self.cumulative_returns.loc[actual_end_date]
            period_returns = (end_values / start_values) - 1
            
            # 添加元数据
            period_returns.name = f'returns_{lookback_months}m'
            period_returns.attrs = {
                'start_date': actual_start_date,
                'end_date': actual_end_date,
                'lookback_months': lookback_months
            }
            
            return period_returns
        else:
            return None
    
    def calculate_rankings(self, end_date, lookback_months=3, ascending=False):
        """
        计算排名
        
        Parameters:
        -----------
        end_date : str or pd.Timestamp
            结束日期
        lookback_months : int
            回看月数
        ascending : bool
            True为升序排名（收益率低的排名靠前），False为降序排名（收益率高的排名靠前）
            
        Returns:
        --------
        pd.DataFrame
            包含收益率、排名和分数的DataFrame
        """
        period_returns = self.calculate_period_returns(end_date, lookback_months)
        
        if period_returns is None:
            return None
            
        # 计算排名（1为最好）
        rankings = period_returns.rank(ascending=ascending, method='min')
        
        # 计算分数（标准化到0-100）
        scores = ((period_returns.rank(pct=True, ascending=not ascending)) * 100).round(2)
        
        # 组合结果
        result_df = pd.DataFrame({
            'industry': period_returns.index,
            'returns': period_returns.values,
            'rank': rankings.values.astype(int),
            'score': scores.values
        })
        
        # 按排名排序
        result_df = result_df.sort_values('rank').reset_index(drop=True)
        
        # 添加元数据
        result_df.attrs = {
            'end_date': end_date,
            'lookback_months': lookback_months,
            'ranking_date': period_returns.attrs['end_date'],
            'start_date': period_returns.attrs['start_date']
        }
        
        return result_df
    
    def calculate_rolling_rankings(self, start_date, end_date, lookback_months=3, 
                                 frequency='M', ascending=False):
        """
        计算滚动排名
        
        Parameters:
        -----------
        start_date : str or pd.Timestamp
            开始日期
        end_date : str or pd.Timestamp
            结束日期
        lookback_months : int
            回看月数
        frequency : str
            计算频率 ('M'=月末, 'W'=周末, 'D'=每日)
        ascending : bool
            排名顺序
            
        Returns:
        --------
        dict
            键为日期，值为排名DataFrame的字典
        """
        start_date = pd.to_datetime(start_date)
        end_date = pd.to_datetime(end_date)
        
        # 生成计算日期序列
        if frequency == 'M':
            calc_dates = pd.date_range(start=start_date, end=end_date, freq='M')
        elif frequency == 'W':
            calc_dates = pd.date_range(start=start_date, end=end_date, freq='W')
        else:
            calc_dates = pd.date_range(start=start_date, end=end_date, freq='D')
            
        rolling_rankings = {}
        
        for calc_date in calc_dates:
            ranking_result = self.calculate_rankings(calc_date, lookback_months, ascending)
            if ranking_result is not None:
                rolling_rankings[calc_date] = ranking_result
                
        return rolling_rankings
    
    def get_top_bottom_industries(self, ranking_df, top_n=5, bottom_n=5):
        """
        获取排名前N和后N的行业
        
        Parameters:
        -----------
        ranking_df : pd.DataFrame
            排名结果DataFrame
        top_n : int
            前N名数量
        bottom_n : int
            后N名数量
            
        Returns:
        --------
        dict
            包含top和bottom行业列表的字典
        """
        if ranking_df is None or len(ranking_df) == 0:
            return {'top': [], 'bottom': []}
            
        top_industries = ranking_df.head(top_n)['industry'].tolist()
        bottom_industries = ranking_df.tail(bottom_n)['industry'].tolist()
        
        return {
            'top': top_industries,
            'bottom': bottom_industries,
            'top_data': ranking_df.head(top_n),
            'bottom_data': ranking_df.tail(bottom_n)
        }
    
    def analyze_ranking_stability(self, rolling_rankings, top_n=5):
        """
        分析排名稳定性
        
        Parameters:
        -----------
        rolling_rankings : dict
            滚动排名结果
        top_n : int
            分析前N名的稳定性
            
        Returns:
        --------
        pd.DataFrame
            排名稳定性分析结果
        """
        if not rolling_rankings:
            return None
            
        # 提取每个日期的前N名
        top_industries_by_date = {}
        for date, ranking_df in rolling_rankings.items():
            top_industries_by_date[date] = ranking_df.head(top_n)['industry'].tolist()
            
        # 计算每个行业出现在前N名的频率
        all_industries = set()
        for industries in top_industries_by_date.values():
            all_industries.update(industries)
            
        stability_data = []
        for industry in all_industries:
            appearances = sum(1 for industries in top_industries_by_date.values() 
                            if industry in industries)
            frequency = appearances / len(top_industries_by_date)
            
            stability_data.append({
                'industry': industry,
                'appearances': appearances,
                'frequency': frequency,
                'stability_score': frequency * 100
            })
            
        stability_df = pd.DataFrame(stability_data)
        stability_df = stability_df.sort_values('stability_score', ascending=False)
        
        return stability_df
    
    def export_rankings(self, rolling_rankings, filename='ranking_results.xlsx'):
        """
        导出排名结果到Excel文件
        
        Parameters:
        -----------
        rolling_rankings : dict
            滚动排名结果
        filename : str
            文件名
        """
        filepath = f'/Users/mac/Downloads/auxiliary/{filename}'
        
        with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
            # 写入每个日期的排名
            for date, ranking_df in rolling_rankings.items():
                sheet_name = date.strftime('%Y%m%d')
                ranking_df.to_excel(writer, sheet_name=sheet_name, index=False)
                
            # 写入稳定性分析
            stability_df = self.analyze_ranking_stability(rolling_rankings)
            if stability_df is not None:
                stability_df.to_excel(writer, sheet_name='stability_analysis', index=False)
                
        print(f"排名结果已导出到: {filepath}")
        return filepath

# 使用示例函数
def calculate_industry_rankings(returns_data, end_date, lookback_months=3):
    """
    计算行业排名的接口函数
    
    Parameters:
    -----------
    returns_data : pd.DataFrame
        收益率数据
    end_date : str
        结束日期
    lookback_months : int
        回看月数
        
    Returns:
    --------
    pd.DataFrame
        排名结果
    """
    calculator = RankingCalculator(returns_data)
    ranking_result = calculator.calculate_rankings(end_date, lookback_months)
    
    if ranking_result is not None:
        print(f"\n{end_date} 前 {lookback_months} 个月行业排名:")
        print(ranking_result.to_string(index=False))
        
        # 获取前5和后5
        top_bottom = calculator.get_top_bottom_industries(ranking_result)
        print(f"\n前5名行业: {top_bottom['top']}")
        print(f"后5名行业: {top_bottom['bottom']}")
        
    return ranking_result

if __name__ == "__main__":
    # 示例用法
    from data_generator import load_mock_data
    
    # 加载数据
    returns_data = load_mock_data()
    
    if returns_data is not None:
        # 计算最新排名
        latest_date = returns_data.index[-1]
        ranking_result = calculate_industry_rankings(returns_data, latest_date, 3)
        
        # 计算滚动排名
        calculator = RankingCalculator(returns_data)
        start_date = returns_data.index[-252]  # 过去一年
        rolling_rankings = calculator.calculate_rolling_rankings(
            start_date, latest_date, lookback_months=3, frequency='M'
        )
        
        print(f"\n计算了 {len(rolling_rankings)} 个月的滚动排名")
        
        # 导出结果
        if rolling_rankings:
            calculator.export_rankings(rolling_rankings)