import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

from data_generator import DataGenerator
from ranking_calculator import RankingCalculator
from date_manager import DateManager
from portfolio_manager import Portfolio, PortfolioManager
from rebalance_logic import RebalanceLogic

class PortfolioSimulation:
    """
    投资组合模拟器
    用于构建和回测不同的投资策略
    
    支持的策略类型：
    1. Long Only: 做多排名前N的行业
    2. Long/Short: 做多前N，做空后N
    3. Benchmark: 等权重基准组合
    """
    
    def __init__(self, initial_capital=1000000, rebalance_frequency='monthly'):
        """
        初始化模拟器
        
        Parameters:
        -----------
        initial_capital : float
            初始资金，默认100万
        rebalance_frequency : str
            调仓频率，默认月度
        """
        self.initial_capital = initial_capital
        self.rebalance_frequency = rebalance_frequency
        
        # 初始化各个组件
        self.data_generator = DataGenerator()
        self.ranking_calculator = RankingCalculator()
        self.date_manager = DateManager()
        self.portfolio_manager = PortfolioManager()
        self.rebalance_logic = RebalanceLogic()
        
        # 存储模拟结果
        self.simulation_results = {}
        self.performance_metrics = {}
        
    def setup_simulation(self, start_date='2019-01-01', end_date='2024-01-01', 
                        ranking_lookback_months=3):
        """
        设置模拟参数
        
        Parameters:
        -----------
        start_date : str
            回测开始日期
        end_date : str
            回测结束日期
        ranking_lookback_months : int
            排名回看月数
        """
        self.start_date = pd.Timestamp(start_date)
        self.end_date = pd.Timestamp(end_date)
        self.ranking_lookback_months = ranking_lookback_months
        
        print(f"=== 模拟设置 ===")
        print(f"回测期间: {start_date} 至 {end_date}")
        print(f"初始资金: {self.initial_capital:,.0f} 元")
        print(f"调仓频率: {self.rebalance_frequency}")
        print(f"排名回看期: {ranking_lookback_months} 个月")
        
        # 生成模拟数据
        print(f"\n正在生成模拟数据...")
        self.returns_data = self.data_generator.generate_mock_data()
        print(f"数据生成完成，包含 {len(self.returns_data)} 个交易日")
        
        # 筛选回测期间的数据
        mask = (self.returns_data.index >= self.start_date) & (self.returns_data.index <= self.end_date)
        self.returns_data = self.returns_data[mask]
        print(f"回测期间数据: {len(self.returns_data)} 个交易日")
        
        # 生成调仓日期
        print(f"\n正在生成调仓日期...")
        self.rebalance_schedule = self.date_manager.generate_rebalance_schedule(
            self.returns_data, self.start_date, self.end_date, self.rebalance_frequency
        )
        print(f"调仓次数: {len(self.rebalance_schedule)} 次")
        
        # 初始化排名计算器
        self.ranking_calculator.set_data(self.returns_data)
        
    def create_long_only_strategy(self, strategy_name, top_n=5):
        """
        创建Long Only策略
        
        Parameters:
        -----------
        strategy_name : str
            策略名称
        top_n : int
            做多前N个行业
        """
        portfolio = Portfolio(strategy_name, 'long_only', self.initial_capital)
        
        strategy_config = {
            'type': 'long_only',
            'top_n': top_n,
            'portfolio': portfolio
        }
        
        self.portfolio_manager.add_portfolio(portfolio)
        
        print(f"创建Long Only策略: {strategy_name} (前{top_n}行业)")
        return strategy_config
    
    def create_long_short_strategy(self, strategy_name, long_n=5, short_n=5):
        """
        创建Long/Short策略
        
        Parameters:
        -----------
        strategy_name : str
            策略名称
        long_n : int
            做多前N个行业
        short_n : int
            做空后N个行业
        """
        portfolio = Portfolio(strategy_name, 'long_short', self.initial_capital)
        
        strategy_config = {
            'type': 'long_short',
            'long_n': long_n,
            'short_n': short_n,
            'portfolio': portfolio
        }
        
        self.portfolio_manager.add_portfolio(portfolio)
        
        print(f"创建Long/Short策略: {strategy_name} (多{long_n}/空{short_n})")
        return strategy_config
    
    def create_benchmark_strategy(self, strategy_name='Benchmark'):
        """
        创建基准策略（等权重）
        
        Parameters:
        -----------
        strategy_name : str
            策略名称
        """
        portfolio = Portfolio(strategy_name, 'benchmark', self.initial_capital)
        
        # 等权重分配到所有行业
        industries = self.returns_data.columns.tolist()
        equal_weight = 1.0 / len(industries)
        benchmark_positions = {industry: equal_weight for industry in industries}
        portfolio.positions = benchmark_positions
        
        strategy_config = {
            'type': 'benchmark',
            'portfolio': portfolio
        }
        
        self.portfolio_manager.add_portfolio(portfolio)
        
        print(f"创建基准策略: {strategy_name} (等权重{len(industries)}行业)")
        return strategy_config
    
    def run_simulation(self, strategies):
        """
        运行模拟回测
        
        Parameters:
        -----------
        strategies : list
            策略配置列表
        """
        print(f"\n=== 开始模拟回测 ===")
        print(f"策略数量: {len(strategies)}")
        
        # 获取所有交易日
        trading_days = self.returns_data.index.tolist()
        
        # 为每个策略初始化结果记录
        for strategy in strategies:
            portfolio = strategy['portfolio']
            portfolio_name = portfolio.name
            
            self.simulation_results[portfolio_name] = {
                'daily_nav': [],
                'daily_returns': [],
                'daily_positions': [],
                'rebalance_dates': [],
                'ranking_history': []
            }
        
        # 按日期循环进行回测
        for i, current_date in enumerate(trading_days):
            print(f"\r处理日期: {current_date.strftime('%Y-%m-%d')} ({i+1}/{len(trading_days)})", end="")
            
            # 检查是否为调仓日
            rebalance_info = self._get_rebalance_info(current_date)
            
            if rebalance_info:
                # 执行调仓逻辑
                self._execute_rebalance(strategies, current_date, rebalance_info)
            
            # 计算当日收益并更新NAV
            current_returns = self.returns_data.loc[current_date]
            
            for strategy in strategies:
                portfolio = strategy['portfolio']
                portfolio_name = portfolio.name
                
                # 计算当日组合收益
                if portfolio.positions:
                    daily_return = sum(
                        weight * current_returns.get(industry, 0) 
                        for industry, weight in portfolio.positions.items()
                    )
                else:
                    daily_return = 0.0
                
                # 更新NAV
                new_nav = portfolio.nav * (1 + daily_return)
                portfolio.nav = new_nav
                
                # 记录结果
                self.simulation_results[portfolio_name]['daily_nav'].append(new_nav)
                self.simulation_results[portfolio_name]['daily_returns'].append(daily_return)
                self.simulation_results[portfolio_name]['daily_positions'].append(portfolio.positions.copy())
                
                # 记录调仓日期
                if rebalance_info:
                    self.simulation_results[portfolio_name]['rebalance_dates'].append(current_date)
        
        print(f"\n回测完成！")
        
        # 转换结果为DataFrame
        self._convert_results_to_dataframe(trading_days)
        
        # 计算性能指标
        self._calculate_performance_metrics()
        
    def _get_rebalance_info(self, current_date):
        """
        获取调仓信息
        
        Parameters:
        -----------
        current_date : pd.Timestamp
            当前日期
            
        Returns:
        --------
        dict or None
            调仓信息
        """
        for schedule in self.rebalance_schedule:
            if schedule['rebalance_prep_date'] == current_date:
                return schedule
        return None
    
    def _execute_rebalance(self, strategies, current_date, rebalance_info):
        """
        执行调仓
        
        Parameters:
        -----------
        strategies : list
            策略列表
        current_date : pd.Timestamp
            当前日期
        rebalance_info : dict
            调仓信息
        """
        # 计算排名（基于调仓基准日）
        ranking_date = rebalance_info['ranking_base_date']
        
        try:
            rankings = self.ranking_calculator.calculate_ranking(
                ranking_date, self.ranking_lookback_months
            )
        except Exception as e:
            print(f"\n警告: 无法计算 {ranking_date} 的排名: {e}")
            return
        
        # 获取当日收益率（用于调仓准备日收益计算）
        current_returns = self.returns_data.loc[current_date]
        
        # 为每个策略执行调仓
        for strategy in strategies:
            portfolio = strategy['portfolio']
            strategy_type = strategy['type']
            
            # 根据策略类型确定目标持仓
            if strategy_type == 'long_only':
                target_positions = self._get_long_only_positions(rankings, strategy['top_n'])
            elif strategy_type == 'long_short':
                target_positions = self._get_long_short_positions(
                    rankings, strategy['long_n'], strategy['short_n']
                )
            elif strategy_type == 'benchmark':
                # 基准策略不调仓
                continue
            else:
                continue
            
            # 执行调仓（使用调仓逻辑模块）
            if target_positions:
                try:
                    rebalance_record = self.rebalance_logic.execute_rebalance_with_nav_reset(
                        portfolio, 
                        target_positions,
                        rebalance_info['rebalance_prep_date'],
                        rebalance_info['rebalance_effective_date'],
                        current_returns
                    )
                    
                    # 记录排名历史
                    self.simulation_results[portfolio.name]['ranking_history'].append({
                        'date': current_date,
                        'rankings': rankings.copy(),
                        'target_positions': target_positions.copy()
                    })
                    
                except Exception as e:
                    print(f"\n警告: {portfolio.name} 调仓失败: {e}")
    
    def _get_long_only_positions(self, rankings, top_n):
        """
        获取Long Only策略的目标持仓
        
        Parameters:
        -----------
        rankings : pd.Series
            行业排名
        top_n : int
            前N个行业
            
        Returns:
        --------
        dict
            目标持仓权重
        """
        if rankings is None or len(rankings) == 0:
            return {}
            
        # 选择排名前N的行业
        top_industries = rankings.head(top_n).index.tolist()
        
        # 等权重分配
        weight_per_industry = 1.0 / len(top_industries)
        target_positions = {industry: weight_per_industry for industry in top_industries}
        
        return target_positions
    
    def _get_long_short_positions(self, rankings, long_n, short_n):
        """
        获取Long/Short策略的目标持仓
        
        Parameters:
        -----------
        rankings : pd.Series
            行业排名
        long_n : int
            做多前N个行业
        short_n : int
            做空后N个行业
            
        Returns:
        --------
        dict
            目标持仓权重
        """
        if rankings is None or len(rankings) == 0:
            return {}
            
        target_positions = {}
        
        # 做多前N个行业
        top_industries = rankings.head(long_n).index.tolist()
        long_weight = 1.0 / len(top_industries)
        for industry in top_industries:
            target_positions[industry] = long_weight
        
        # 做空后N个行业
        bottom_industries = rankings.tail(short_n).index.tolist()
        short_weight = -1.0 / len(bottom_industries)  # 负权重表示做空
        for industry in bottom_industries:
            target_positions[industry] = short_weight
        
        return target_positions
    
    def _convert_results_to_dataframe(self, trading_days):
        """
        将结果转换为DataFrame格式
        
        Parameters:
        -----------
        trading_days : list
            交易日列表
        """
        for portfolio_name, results in self.simulation_results.items():
            # 创建日度结果DataFrame
            daily_df = pd.DataFrame({
                'date': trading_days,
                'nav': results['daily_nav'],
                'daily_return': results['daily_returns']
            })
            daily_df.set_index('date', inplace=True)
            
            # 计算累计收益
            daily_df['cumulative_return'] = (daily_df['nav'] / self.initial_capital - 1) * 100
            
            results['daily_df'] = daily_df
    
    def _calculate_performance_metrics(self):
        """
        计算性能指标
        """
        print(f"\n=== 计算性能指标 ===")
        
        for portfolio_name, results in self.simulation_results.items():
            daily_df = results['daily_df']
            daily_returns = daily_df['daily_return']
            
            # 基本统计
            total_return = (daily_df['nav'].iloc[-1] / self.initial_capital - 1) * 100
            annualized_return = ((daily_df['nav'].iloc[-1] / self.initial_capital) ** (252 / len(daily_df)) - 1) * 100
            volatility = daily_returns.std() * np.sqrt(252) * 100
            
            # 夏普比率
            if volatility > 0:
                sharpe_ratio = annualized_return / volatility
            else:
                sharpe_ratio = 0
            
            # 最大回撤
            cumulative_nav = daily_df['nav']
            rolling_max = cumulative_nav.expanding().max()
            drawdown = (cumulative_nav - rolling_max) / rolling_max * 100
            max_drawdown = drawdown.min()
            
            # 信息比率 (IR)
            # 这里使用超额收益的标准差作为跟踪误差
            excess_returns = daily_returns - daily_returns.mean()  # 相对于自身均值的超额收益
            tracking_error = excess_returns.std() * np.sqrt(252) * 100
            
            if tracking_error > 0:
                information_ratio = annualized_return / tracking_error
            else:
                information_ratio = 0
            
            # 胜率
            win_rate = (daily_returns > 0).sum() / len(daily_returns) * 100
            
            # 存储指标
            self.performance_metrics[portfolio_name] = {
                'total_return': total_return,
                'annualized_return': annualized_return,
                'volatility': volatility,
                'sharpe_ratio': sharpe_ratio,
                'max_drawdown': max_drawdown,
                'information_ratio': information_ratio,
                'win_rate': win_rate,
                'total_trades': len(results['rebalance_dates'])
            }
            
            print(f"{portfolio_name}:")
            print(f"  总收益: {total_return:.2f}%")
            print(f"  年化收益: {annualized_return:.2f}%")
            print(f"  年化波动: {volatility:.2f}%")
            print(f"  夏普比率: {sharpe_ratio:.3f}")
            print(f"  信息比率: {information_ratio:.3f}")
            print(f"  最大回撤: {max_drawdown:.2f}%")
            print(f"  胜率: {win_rate:.1f}%")
            print(f"  调仓次数: {len(results['rebalance_dates'])}")
            print()
    
    def export_simulation_results(self, filename='simulation_results.xlsx'):
        """
        导出模拟结果
        
        Parameters:
        -----------
        filename : str
            文件名
        """
        filepath = f'/Users/mac/Downloads/auxiliary/{filename}'
        
        with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
            # 性能指标汇总
            metrics_df = pd.DataFrame(self.performance_metrics).T
            metrics_df.to_excel(writer, sheet_name='performance_metrics')
            
            # 每个策略的详细结果
            for portfolio_name, results in self.simulation_results.items():
                # 日度NAV和收益
                daily_df = results['daily_df']
                daily_df.to_excel(writer, sheet_name=f'{portfolio_name}_daily')
                
                # 调仓历史
                if results['rebalance_dates']:
                    rebalance_df = pd.DataFrame({
                        'rebalance_date': results['rebalance_dates']
                    })
                    rebalance_df.to_excel(writer, sheet_name=f'{portfolio_name}_rebalance', index=False)
            
            # 原始数据
            self.returns_data.to_excel(writer, sheet_name='raw_returns_data')
        
        print(f"模拟结果已导出到: {filepath}")
        return filepath
    
    def get_simulation_summary(self):
        """
        获取模拟汇总信息
        
        Returns:
        --------
        dict
            汇总信息
        """
        summary = {
            'simulation_period': f"{self.start_date.strftime('%Y-%m-%d')} 至 {self.end_date.strftime('%Y-%m-%d')}",
            'initial_capital': self.initial_capital,
            'rebalance_frequency': self.rebalance_frequency,
            'ranking_lookback_months': self.ranking_lookback_months,
            'total_trading_days': len(self.returns_data),
            'total_rebalances': len(self.rebalance_schedule),
            'strategies_count': len(self.simulation_results),
            'strategies': list(self.simulation_results.keys()),
            'performance_metrics': self.performance_metrics
        }
        
        return summary

# 主要模拟函数
def run_main_simulation():
    """
    运行主要的模拟回测
    
    构建以下策略：
    1. Long前5行业组合
    2. Long前5/Short后5行业组合
    3. 等权重基准组合
    """
    print("=" * 80)
    print("投资组合策略模拟回测")
    print("=" * 80)
    
    # 创建模拟器
    simulator = PortfolioSimulation(
        initial_capital=1000000,  # 100万初始资金
        rebalance_frequency='monthly'  # 月度调仓
    )
    
    # 设置模拟参数
    simulator.setup_simulation(
        start_date='2019-01-01',
        end_date='2024-01-01',
        ranking_lookback_months=3  # 基于过去3个月排名
    )
    
    # 创建策略
    strategies = []
    
    # 策略1: Long前5行业
    long_only_strategy = simulator.create_long_only_strategy('Long_Top5', top_n=5)
    strategies.append(long_only_strategy)
    
    # 策略2: Long前5/Short后5
    long_short_strategy = simulator.create_long_short_strategy(
        'LongShort_5_5', long_n=5, short_n=5
    )
    strategies.append(long_short_strategy)
    
    # 策略3: 等权重基准
    benchmark_strategy = simulator.create_benchmark_strategy('Equal_Weight_Benchmark')
    strategies.append(benchmark_strategy)
    
    # 运行模拟
    simulator.run_simulation(strategies)
    
    # 导出结果
    results_file = simulator.export_simulation_results('portfolio_simulation_results.xlsx')
    
    # 打印汇总
    summary = simulator.get_simulation_summary()
    print(f"\n=== 模拟汇总 ===")
    print(f"模拟期间: {summary['simulation_period']}")
    print(f"初始资金: {summary['initial_capital']:,.0f} 元")
    print(f"交易日数: {summary['total_trading_days']} 天")
    print(f"调仓次数: {summary['total_rebalances']} 次")
    print(f"策略数量: {summary['strategies_count']} 个")
    
    return simulator

if __name__ == "__main__":
    # 运行主要模拟
    simulator = run_main_simulation()