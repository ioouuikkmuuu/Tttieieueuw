import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import calendar
import warnings
warnings.filterwarnings('ignore')

class DateManager:
    """
    日期管理器
    生成调仓相关的关键日期：调仓基准日、调仓准备日、调仓生效日
    """
    
    def __init__(self, returns_data):
        """
        初始化日期管理器
        
        Parameters:
        -----------
        returns_data : pd.DataFrame
            收益率数据，用于获取可用的交易日
        """
        self.trading_days = returns_data.index.sort_values()
        self.returns_data = returns_data
        
    def get_month_end_trading_day(self, year, month):
        """
        获取指定年月的月末工作日
        
        Parameters:
        -----------
        year : int
            年份
        month : int
            月份
            
        Returns:
        --------
        pd.Timestamp or None
            月末工作日
        """
        # 获取该月的最后一天
        last_day = calendar.monthrange(year, month)[1]
        month_end = pd.Timestamp(year, month, last_day)
        
        # 找到最接近且不超过月末的交易日
        available_days = self.trading_days[self.trading_days <= month_end]
        
        if len(available_days) > 0:
            return available_days[-1]
        else:
            return None
    
    def get_month_start_trading_day(self, year, month, offset_days=0):
        """
        获取指定年月的月初工作日
        
        Parameters:
        -----------
        year : int
            年份
        month : int
            月份
        offset_days : int
            偏移天数（0=月初第一个交易日，1=月初第二个交易日）
            
        Returns:
        --------
        pd.Timestamp or None
            月初工作日
        """
        month_start = pd.Timestamp(year, month, 1)
        
        # 找到该月开始后的交易日
        available_days = self.trading_days[self.trading_days >= month_start]
        
        if len(available_days) > offset_days:
            return available_days[offset_days]
        else:
            return None
    
    def generate_rebalance_dates(self, start_date, end_date, frequency='M'):
        """
        生成调仓日期序列
        
        Parameters:
        -----------
        start_date : str or pd.Timestamp
            开始日期
        end_date : str or pd.Timestamp
            结束日期
        frequency : str
            调仓频率 ('M'=月度, 'Q'=季度, 'Y'=年度)
            
        Returns:
        --------
        pd.DataFrame
            包含所有调仓相关日期的DataFrame
        """
        start_date = pd.to_datetime(start_date)
        end_date = pd.to_datetime(end_date)
        
        # 生成调仓周期
        if frequency == 'M':
            periods = pd.date_range(start=start_date, end=end_date, freq='M')
        elif frequency == 'Q':
            periods = pd.date_range(start=start_date, end=end_date, freq='Q')
        elif frequency == 'Y':
            periods = pd.date_range(start=start_date, end=end_date, freq='Y')
        else:
            raise ValueError("frequency must be 'M', 'Q', or 'Y'")
        
        rebalance_dates = []
        
        for period_end in periods:
            year = period_end.year
            month = period_end.month
            
            # 调仓基准日：月末工作日
            rebalance_base_date = self.get_month_end_trading_day(year, month)
            
            # 调仓准备日：月初第一个工作日
            next_month = month + 1 if month < 12 else 1
            next_year = year if month < 12 else year + 1
            rebalance_prep_date = self.get_month_start_trading_day(next_year, next_month, 0)
            
            # 调仓生效日：月初第二个工作日
            rebalance_effective_date = self.get_month_start_trading_day(next_year, next_month, 1)
            
            if all([rebalance_base_date, rebalance_prep_date, rebalance_effective_date]):
                rebalance_dates.append({
                    'period': f"{year}-{month:02d}",
                    'rebalance_base_date': rebalance_base_date,      # 调仓基准日（排名计算日）
                    'rebalance_prep_date': rebalance_prep_date,      # 调仓准备日（执行调仓）
                    'rebalance_effective_date': rebalance_effective_date,  # 调仓生效日（新持仓开始）
                    'year': year,
                    'month': month
                })
        
        rebalance_df = pd.DataFrame(rebalance_dates)
        
        # 添加一些有用的标识
        if len(rebalance_df) > 0:
            rebalance_df['is_year_end'] = rebalance_df['month'] == 12
            rebalance_df['is_quarter_end'] = rebalance_df['month'].isin([3, 6, 9, 12])
            rebalance_df['days_between_prep_effective'] = (
                rebalance_df['rebalance_effective_date'] - rebalance_df['rebalance_prep_date']
            ).dt.days
        
        return rebalance_df
    
    def get_trading_days_between(self, start_date, end_date, inclusive='both'):
        """
        获取两个日期之间的交易日
        
        Parameters:
        -----------
        start_date : str or pd.Timestamp
            开始日期
        end_date : str or pd.Timestamp
            结束日期
        inclusive : str
            包含方式 ('both', 'left', 'right', 'neither')
            
        Returns:
        --------
        pd.DatetimeIndex
            交易日序列
        """
        start_date = pd.to_datetime(start_date)
        end_date = pd.to_datetime(end_date)
        
        if inclusive == 'both':
            mask = (self.trading_days >= start_date) & (self.trading_days <= end_date)
        elif inclusive == 'left':
            mask = (self.trading_days >= start_date) & (self.trading_days < end_date)
        elif inclusive == 'right':
            mask = (self.trading_days > start_date) & (self.trading_days <= end_date)
        else:  # neither
            mask = (self.trading_days > start_date) & (self.trading_days < end_date)
            
        return self.trading_days[mask]
    
    def get_next_trading_day(self, date, offset=1):
        """
        获取指定日期后的第N个交易日
        
        Parameters:
        -----------
        date : str or pd.Timestamp
            基准日期
        offset : int
            偏移量（1=下一个交易日，-1=上一个交易日）
            
        Returns:
        --------
        pd.Timestamp or None
            目标交易日
        """
        date = pd.to_datetime(date)
        
        if offset > 0:
            future_days = self.trading_days[self.trading_days > date]
            if len(future_days) >= offset:
                return future_days[offset - 1]
        elif offset < 0:
            past_days = self.trading_days[self.trading_days < date]
            if len(past_days) >= abs(offset):
                return past_days[offset]
        else:
            # offset == 0, 返回最接近的交易日
            if date in self.trading_days:
                return date
            else:
                # 找到最接近的交易日
                past_days = self.trading_days[self.trading_days < date]
                future_days = self.trading_days[self.trading_days > date]
                
                if len(past_days) > 0 and len(future_days) > 0:
                    past_diff = (date - past_days[-1]).days
                    future_diff = (future_days[0] - date).days
                    return past_days[-1] if past_diff <= future_diff else future_days[0]
                elif len(past_days) > 0:
                    return past_days[-1]
                elif len(future_days) > 0:
                    return future_days[0]
                    
        return None
    
    def validate_rebalance_dates(self, rebalance_df):
        """
        验证调仓日期的合理性
        
        Parameters:
        -----------
        rebalance_df : pd.DataFrame
            调仓日期DataFrame
            
        Returns:
        --------
        dict
            验证结果
        """
        validation_results = {
            'valid_periods': 0,
            'invalid_periods': 0,
            'issues': []
        }
        
        for idx, row in rebalance_df.iterrows():
            period = row['period']
            base_date = row['rebalance_base_date']
            prep_date = row['rebalance_prep_date']
            effective_date = row['rebalance_effective_date']
            
            # 检查日期顺序
            if not (base_date < prep_date < effective_date):
                validation_results['invalid_periods'] += 1
                validation_results['issues'].append(
                    f"{period}: 日期顺序错误 - {base_date} -> {prep_date} -> {effective_date}"
                )
                continue
                
            # 检查是否都是交易日
            if not all(date in self.trading_days for date in [base_date, prep_date, effective_date]):
                validation_results['invalid_periods'] += 1
                validation_results['issues'].append(
                    f"{period}: 包含非交易日"
                )
                continue
                
            validation_results['valid_periods'] += 1
            
        return validation_results
    
    def export_rebalance_schedule(self, rebalance_df, filename='rebalance_schedule.xlsx'):
        """
        导出调仓时间表
        
        Parameters:
        -----------
        rebalance_df : pd.DataFrame
            调仓日期DataFrame
        filename : str
            文件名
        """
        filepath = f'/Users/mac/Downloads/auxiliary/{filename}'
        
        with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
            # 主要调仓时间表
            rebalance_df.to_excel(writer, sheet_name='rebalance_schedule', index=False)
            
            # 验证结果
            validation = self.validate_rebalance_dates(rebalance_df)
            validation_df = pd.DataFrame([
                {'metric': 'valid_periods', 'value': validation['valid_periods']},
                {'metric': 'invalid_periods', 'value': validation['invalid_periods']}
            ])
            validation_df.to_excel(writer, sheet_name='validation', index=False)
            
            # 问题列表
            if validation['issues']:
                issues_df = pd.DataFrame({'issues': validation['issues']})
                issues_df.to_excel(writer, sheet_name='issues', index=False)
                
        print(f"调仓时间表已导出到: {filepath}")
        return filepath

# 使用示例函数
def generate_rebalance_schedule(returns_data, start_date, end_date, frequency='M'):
    """
    生成调仓时间表的接口函数
    
    Parameters:
    -----------
    returns_data : pd.DataFrame
        收益率数据
    start_date : str
        开始日期
    end_date : str
        结束日期
    frequency : str
        调仓频率
        
    Returns:
    --------
    pd.DataFrame
        调仓时间表
    """
    date_manager = DateManager(returns_data)
    rebalance_df = date_manager.generate_rebalance_dates(start_date, end_date, frequency)
    
    if len(rebalance_df) > 0:
        print(f"\n生成了 {len(rebalance_df)} 个调仓周期的时间表")
        print("\n调仓时间表预览:")
        print(rebalance_df[['period', 'rebalance_base_date', 'rebalance_prep_date', 'rebalance_effective_date']].head())
        
        # 验证
        validation = date_manager.validate_rebalance_dates(rebalance_df)
        print(f"\n验证结果: {validation['valid_periods']} 个有效周期, {validation['invalid_periods']} 个无效周期")
        
        if validation['issues']:
            print("\n发现的问题:")
            for issue in validation['issues'][:5]:  # 只显示前5个问题
                print(f"  - {issue}")
                
    return rebalance_df

if __name__ == "__main__":
    # 示例用法
    from data_generator import load_mock_data
    
    # 加载数据
    returns_data = load_mock_data()
    
    if returns_data is not None:
        # 生成调仓时间表
        start_date = returns_data.index[0]
        end_date = returns_data.index[-1]
        
        rebalance_schedule = generate_rebalance_schedule(
            returns_data, start_date, end_date, frequency='M'
        )
        
        # 导出时间表
        if len(rebalance_schedule) > 0:
            date_manager = DateManager(returns_data)
            date_manager.export_rebalance_schedule(rebalance_schedule)