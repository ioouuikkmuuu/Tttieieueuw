import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

class RebalanceLogic:
    """
    调仓逻辑处理器
    专门处理调仓后NAV重置的复杂逻辑
    
    关键逻辑说明：
    1. 调仓准备日：使用原持仓计算当日收益，但在收盘时执行调仓
    2. 调仓生效日：使用新持仓开始计算收益
    3. NAV重置：调仓后损益兑现，清仓成现金，再按新权重投资
    """
    
    def __init__(self):
        self.rebalance_records = []
        
    def execute_rebalance_with_nav_reset(self, portfolio, target_positions, 
                                       rebalance_prep_date, rebalance_effective_date,
                                       industry_returns_prep, industry_returns_effective=None):
        """
        执行带NAV重置的调仓逻辑
        
        Parameters:
        -----------
        portfolio : Portfolio
            投资组合对象
        target_positions : dict
            目标持仓权重 {industry: weight}
        rebalance_prep_date : pd.Timestamp
            调仓准备日（执行调仓的日期）
        rebalance_effective_date : pd.Timestamp
            调仓生效日（新持仓开始生效的日期）
        industry_returns_prep : pd.Series
            调仓准备日的行业收益率
        industry_returns_effective : pd.Series, optional
            调仓生效日的行业收益率（如果提供，会同时处理生效日）
            
        Returns:
        --------
        dict
            调仓详细记录
        """
        
        # ==================== 第一步：调仓准备日逻辑 ====================
        print(f"\n=== 调仓准备日 ({rebalance_prep_date.strftime('%Y-%m-%d')}) 逻辑处理 ===")
        
        # 记录调仓前状态
        nav_before_prep = portfolio.nav
        cash_before_prep = portfolio.cash
        positions_before_prep = portfolio.positions.copy()
        
        print(f"调仓前状态:")
        print(f"  NAV: {nav_before_prep:,.2f}")
        print(f"  现金: {cash_before_prep:,.2f}")
        print(f"  持仓: {positions_before_prep}")
        
        # 使用原持仓计算调仓准备日的收益
        prep_day_return = self._calculate_portfolio_return(positions_before_prep, industry_returns_prep)
        nav_after_prep_return = nav_before_prep * (1 + prep_day_return)
        
        print(f"\n调仓准备日收益计算:")
        print(f"  使用原持仓计算收益率: {prep_day_return:.4f} ({prep_day_return*100:.2f}%)")
        print(f"  收益后NAV: {nav_after_prep_return:,.2f}")
        
        # ==================== 第二步：NAV重置逻辑 ====================
        print(f"\n=== NAV重置逻辑（损益兑现） ===")
        
        # 损益兑现：将所有持仓清算为现金
        realized_pnl = nav_after_prep_return - nav_before_prep
        cash_after_realization = nav_after_prep_return  # 全部转为现金
        
        print(f"损益兑现:")
        print(f"  实现损益: {realized_pnl:,.2f}")
        print(f"  清算后现金: {cash_after_realization:,.2f}")
        print(f"  清算后持仓: {{}} (空仓)")
        
        # 更新组合状态（清空持仓，现金为NAV）
        portfolio.nav = nav_after_prep_return
        portfolio.cash = cash_after_realization
        portfolio.positions = {}  # 清空持仓
        
        # ==================== 第三步：新持仓建立 ====================
        print(f"\n=== 新持仓建立 ===")
        
        # 按新权重分配资金
        total_weight = sum(abs(weight) for weight in target_positions.values())
        if total_weight > 0:
            # 标准化权重（确保总权重为1）
            normalized_positions = {}
            for industry, weight in target_positions.items():
                normalized_weight = weight / total_weight if total_weight != 1.0 else weight
                normalized_positions[industry] = normalized_weight
                
            print(f"目标持仓权重:")
            for industry, weight in normalized_positions.items():
                print(f"  {industry}: {weight:.4f} ({weight*100:.2f}%)")
                
            # 更新持仓
            portfolio.positions = normalized_positions.copy()
            
            # 计算实际投资金额
            long_weight = sum(max(0, weight) for weight in normalized_positions.values())
            short_weight = sum(abs(min(0, weight)) for weight in normalized_positions.values())
            
            print(f"\n权重分配:")
            print(f"  多头权重: {long_weight:.4f} ({long_weight*100:.2f}%)")
            print(f"  空头权重: {short_weight:.4f} ({short_weight*100:.2f}%)")
            print(f"  净权重: {long_weight - short_weight:.4f}")
            
        else:
            normalized_positions = {}
            portfolio.positions = {}
            print(f"目标持仓为空，保持空仓状态")
        
        # ==================== 第四步：记录调仓信息 ====================
        rebalance_record = {
            'rebalance_prep_date': rebalance_prep_date,
            'rebalance_effective_date': rebalance_effective_date,
            
            # 调仓前状态
            'nav_before_prep': nav_before_prep,
            'cash_before_prep': cash_before_prep,
            'positions_before_prep': positions_before_prep,
            
            # 调仓准备日收益
            'prep_day_return': prep_day_return,
            'nav_after_prep_return': nav_after_prep_return,
            'realized_pnl': realized_pnl,
            
            # NAV重置后状态
            'cash_after_realization': cash_after_realization,
            'positions_after_rebalance': normalized_positions,
            
            # 权重信息
            'target_positions_raw': target_positions,
            'target_positions_normalized': normalized_positions,
            'total_weight_raw': sum(abs(weight) for weight in target_positions.values()),
            'total_weight_normalized': sum(abs(weight) for weight in normalized_positions.values()),
        }
        
        # 更新组合的调仓历史
        portfolio.rebalance_history.append(rebalance_record)
        self.rebalance_records.append(rebalance_record)
        
        print(f"\n=== 调仓完成 ===")
        print(f"最终状态:")
        print(f"  NAV: {portfolio.nav:,.2f}")
        print(f"  现金: {portfolio.cash:,.2f}")
        print(f"  新持仓: {portfolio.positions}")
        
        # ==================== 第五步：处理调仓生效日（如果提供） ====================
        if industry_returns_effective is not None:
            print(f"\n=== 调仓生效日 ({rebalance_effective_date.strftime('%Y-%m-%d')}) 逻辑处理 ===")
            
            # 使用新持仓计算生效日收益
            effective_day_return = self._calculate_portfolio_return(
                portfolio.positions, industry_returns_effective
            )
            nav_after_effective = portfolio.nav * (1 + effective_day_return)
            
            print(f"调仓生效日收益计算:")
            print(f"  使用新持仓计算收益率: {effective_day_return:.4f} ({effective_day_return*100:.2f}%)")
            print(f"  生效日后NAV: {nav_after_effective:,.2f}")
            
            # 更新NAV
            portfolio.nav = nav_after_effective
            
            # 更新记录
            rebalance_record['effective_day_return'] = effective_day_return
            rebalance_record['nav_after_effective'] = nav_after_effective
        
        return rebalance_record
    
    def _calculate_portfolio_return(self, positions, industry_returns):
        """
        计算组合收益率
        
        Parameters:
        -----------
        positions : dict
            持仓权重 {industry: weight}
        industry_returns : pd.Series
            行业收益率
            
        Returns:
        --------
        float
            组合收益率
        """
        if not positions:
            return 0.0
            
        portfolio_return = 0.0
        
        for industry, weight in positions.items():
            if industry in industry_returns.index:
                contribution = weight * industry_returns[industry]
                portfolio_return += contribution
                print(f"    {industry}: {weight:.4f} × {industry_returns[industry]:.4f} = {contribution:.6f}")
            else:
                print(f"    {industry}: 权重 {weight:.4f}, 但无收益率数据")
                
        return portfolio_return
    
    def validate_rebalance_logic(self, portfolio, rebalance_record):
        """
        验证调仓逻辑的正确性
        
        Parameters:
        -----------
        portfolio : Portfolio
            投资组合对象
        rebalance_record : dict
            调仓记录
            
        Returns:
        --------
        dict
            验证结果
        """
        validation_results = {
            'is_valid': True,
            'issues': [],
            'checks': {}
        }
        
        # 检查1：NAV连续性
        nav_before = rebalance_record['nav_before_prep']
        nav_after_return = rebalance_record['nav_after_prep_return']
        prep_return = rebalance_record['prep_day_return']
        
        expected_nav = nav_before * (1 + prep_return)
        nav_diff = abs(nav_after_return - expected_nav)
        
        validation_results['checks']['nav_continuity'] = {
            'expected': expected_nav,
            'actual': nav_after_return,
            'difference': nav_diff,
            'is_valid': nav_diff < 1e-6
        }
        
        if nav_diff >= 1e-6:
            validation_results['is_valid'] = False
            validation_results['issues'].append(f"NAV连续性检查失败: 差异 {nav_diff:.8f}")
        
        # 检查2：现金等于NAV（调仓后）
        cash_after = rebalance_record['cash_after_realization']
        nav_after = nav_after_return
        
        cash_nav_diff = abs(cash_after - nav_after)
        validation_results['checks']['cash_nav_equality'] = {
            'cash': cash_after,
            'nav': nav_after,
            'difference': cash_nav_diff,
            'is_valid': cash_nav_diff < 1e-6
        }
        
        if cash_nav_diff >= 1e-6:
            validation_results['is_valid'] = False
            validation_results['issues'].append(f"现金NAV一致性检查失败: 差异 {cash_nav_diff:.8f}")
        
        # 检查3：权重标准化
        target_raw = rebalance_record['target_positions_raw']
        target_normalized = rebalance_record['target_positions_normalized']
        
        if target_raw and target_normalized:
            raw_total = sum(abs(weight) for weight in target_raw.values())
            normalized_total = sum(abs(weight) for weight in target_normalized.values())
            
            validation_results['checks']['weight_normalization'] = {
                'raw_total': raw_total,
                'normalized_total': normalized_total,
                'is_valid': abs(normalized_total - 1.0) < 1e-6 or raw_total == 0
            }
            
            if raw_total > 0 and abs(normalized_total - 1.0) >= 1e-6:
                validation_results['is_valid'] = False
                validation_results['issues'].append(f"权重标准化检查失败: 标准化后总权重 {normalized_total:.6f}")
        
        return validation_results
    
    def generate_rebalance_report(self, rebalance_record):
        """
        生成调仓报告
        
        Parameters:
        -----------
        rebalance_record : dict
            调仓记录
            
        Returns:
        --------
        str
            调仓报告文本
        """
        report = []
        report.append("=" * 60)
        report.append("调仓详细报告")
        report.append("=" * 60)
        
        # 基本信息
        prep_date = rebalance_record['rebalance_prep_date'].strftime('%Y-%m-%d')
        effective_date = rebalance_record['rebalance_effective_date'].strftime('%Y-%m-%d')
        
        report.append(f"调仓准备日: {prep_date}")
        report.append(f"调仓生效日: {effective_date}")
        report.append("")
        
        # 调仓前状态
        report.append("调仓前状态:")
        report.append(f"  NAV: {rebalance_record['nav_before_prep']:,.2f}")
        report.append(f"  现金: {rebalance_record['cash_before_prep']:,.2f}")
        report.append(f"  持仓:")
        for industry, weight in rebalance_record['positions_before_prep'].items():
            report.append(f"    {industry}: {weight:.4f} ({weight*100:.2f}%)")
        report.append("")
        
        # 调仓准备日收益
        report.append("调仓准备日收益:")
        prep_return = rebalance_record['prep_day_return']
        report.append(f"  收益率: {prep_return:.4f} ({prep_return*100:.2f}%)")
        report.append(f"  收益后NAV: {rebalance_record['nav_after_prep_return']:,.2f}")
        report.append(f"  实现损益: {rebalance_record['realized_pnl']:,.2f}")
        report.append("")
        
        # NAV重置
        report.append("NAV重置（损益兑现）:")
        report.append(f"  清算后现金: {rebalance_record['cash_after_realization']:,.2f}")
        report.append(f"  持仓清空: 是")
        report.append("")
        
        # 新持仓
        report.append("新持仓建立:")
        if rebalance_record['positions_after_rebalance']:
            for industry, weight in rebalance_record['positions_after_rebalance'].items():
                report.append(f"  {industry}: {weight:.4f} ({weight*100:.2f}%)")
                
            long_weight = sum(max(0, w) for w in rebalance_record['positions_after_rebalance'].values())
            short_weight = sum(abs(min(0, w)) for w in rebalance_record['positions_after_rebalance'].values())
            report.append(f"  多头总权重: {long_weight:.4f} ({long_weight*100:.2f}%)")
            report.append(f"  空头总权重: {short_weight:.4f} ({short_weight*100:.2f}%)")
            report.append(f"  净权重: {long_weight - short_weight:.4f}")
        else:
            report.append("  空仓")
        
        # 调仓生效日收益（如果有）
        if 'effective_day_return' in rebalance_record:
            report.append("")
            report.append("调仓生效日收益:")
            effective_return = rebalance_record['effective_day_return']
            report.append(f"  收益率: {effective_return:.4f} ({effective_return*100:.2f}%)")
            report.append(f"  生效日后NAV: {rebalance_record['nav_after_effective']:,.2f}")
        
        report.append("=" * 60)
        
        return "\n".join(report)
    
    def export_rebalance_records(self, filename='rebalance_logic_records.xlsx'):
        """
        导出调仓逻辑记录
        
        Parameters:
        -----------
        filename : str
            文件名
        """
        if not self.rebalance_records:
            print("没有调仓记录可导出")
            return None
            
        filepath = f'/Users/mac/Downloads/auxiliary/{filename}'
        
        # 准备导出数据
        export_data = []
        for record in self.rebalance_records:
            flat_record = {
                'rebalance_prep_date': record['rebalance_prep_date'],
                'rebalance_effective_date': record['rebalance_effective_date'],
                'nav_before_prep': record['nav_before_prep'],
                'prep_day_return': record['prep_day_return'],
                'nav_after_prep_return': record['nav_after_prep_return'],
                'realized_pnl': record['realized_pnl'],
                'cash_after_realization': record['cash_after_realization'],
                'total_weight_raw': record['total_weight_raw'],
                'total_weight_normalized': record['total_weight_normalized']
            }
            
            # 添加生效日收益（如果有）
            if 'effective_day_return' in record:
                flat_record['effective_day_return'] = record['effective_day_return']
                flat_record['nav_after_effective'] = record['nav_after_effective']
            
            export_data.append(flat_record)
        
        with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
            # 主要记录
            main_df = pd.DataFrame(export_data)
            main_df.to_excel(writer, sheet_name='rebalance_summary', index=False)
            
            # 详细持仓变化
            for i, record in enumerate(self.rebalance_records):
                sheet_name = f'rebalance_{i+1}'
                
                # 持仓变化详情
                positions_data = []
                
                # 调仓前持仓
                for industry, weight in record['positions_before_prep'].items():
                    positions_data.append({
                        'industry': industry,
                        'position_type': 'before',
                        'weight': weight
                    })
                
                # 调仓后持仓
                for industry, weight in record['positions_after_rebalance'].items():
                    positions_data.append({
                        'industry': industry,
                        'position_type': 'after',
                        'weight': weight
                    })
                
                if positions_data:
                    positions_df = pd.DataFrame(positions_data)
                    positions_df.to_excel(writer, sheet_name=sheet_name, index=False)
        
        print(f"调仓逻辑记录已导出到: {filepath}")
        return filepath

# 使用示例函数
def test_rebalance_logic():
    """
    测试调仓逻辑的示例函数
    """
    from portfolio_manager import Portfolio
    
    # 创建测试组合
    portfolio = Portfolio('Test_Portfolio', 'long_only', 1000000)
    
    # 设置初始持仓
    initial_positions = {
        '食品饮料': 0.3,
        '医药生物': 0.3,
        '电子': 0.4
    }
    portfolio.positions = initial_positions
    portfolio.cash = 0  # 全仓
    
    # 创建调仓逻辑处理器
    rebalance_logic = RebalanceLogic()
    
    # 模拟调仓准备日收益率
    prep_day_returns = pd.Series({
        '食品饮料': 0.02,   # 2%
        '医药生物': -0.01,  # -1%
        '电子': 0.03,      # 3%
        '银行': 0.01,      # 1%
        '房地产': -0.02    # -2%
    })
    
    # 目标持仓（调仓到银行和房地产）
    target_positions = {
        '银行': 0.6,
        '房地产': 0.4
    }
    
    # 执行调仓
    prep_date = pd.Timestamp('2024-01-31')
    effective_date = pd.Timestamp('2024-02-02')
    
    print("=== 调仓逻辑测试 ===")
    print(f"初始NAV: {portfolio.nav:,.2f}")
    print(f"初始持仓: {portfolio.positions}")
    
    rebalance_record = rebalance_logic.execute_rebalance_with_nav_reset(
        portfolio, target_positions, prep_date, effective_date, prep_day_returns
    )
    
    # 验证逻辑
    validation = rebalance_logic.validate_rebalance_logic(portfolio, rebalance_record)
    print(f"\n=== 验证结果 ===")
    print(f"验证通过: {validation['is_valid']}")
    if validation['issues']:
        print("发现问题:")
        for issue in validation['issues']:
            print(f"  - {issue}")
    
    # 生成报告
    report = rebalance_logic.generate_rebalance_report(rebalance_record)
    print(f"\n{report}")
    
    return rebalance_logic, rebalance_record

if __name__ == "__main__":
    # 运行测试
    test_rebalance_logic()