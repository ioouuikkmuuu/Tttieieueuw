"""
增强版主程序：支持详细日志、plotly可视化和自定义图表
"""
import argparse
import sys
import logging
import os
import pandas as pd
from datetime import datetime

# 配置详细日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('enhanced_simulation.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# 添加模块路径
sys.path.append('.')

try:
    from simulator import Simulator
    from visualizer_enhanced import run_enhanced_visualization
except ImportError as e:
    logger.error(f"导入模块失败: {e}")
    sys.exit(1)

def setup_logging(verbose=False):
    """设置日志级别"""
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    else:
        logging.getLogger().setLevel(logging.INFO)

def validate_data(data_path='sw_industry_returns.csv'):
    """验证数据文件"""
    logger.info(f"开始验证数据文件: {data_path}")
    
    try:
        df = pd.read_csv(data_path)
        logger.info(f"✓ 数据文件验证成功")
        logger.info(f"  - 数据形状: {df.shape}")
        logger.info(f"  - 时间范围: {df['date'].min()} 到 {df['date'].max()}")
        logger.info(f"  - 行业数量: {len(df.columns) - 1}")
        return True
    except Exception as e:
        logger.error(f"✗ 数据文件验证失败: {e}")
        return False

def run_full_enhanced_simulation(start_date='2019-01-01', end_date='2024-01-01', 
                               lookback_months=3, use_plotly=False):
    """
    运行完整增强版模拟
    
    Args:
        start_date: 开始日期
        end_date: 结束日期
        lookback_months: 回看月份数
        use_plotly: 是否使用plotly进行可视化
    """
    logger.info("=" * 60)
    logger.info("申万行业投资组合回测系统 - 增强版")
    logger.info("=" * 60)
    
    try:
        # 1. 数据验证
        logger.info("1. 数据验证阶段...")
        if not validate_data():
            logger.error("数据验证失败，终止执行")
            return None
        
        # 2. 设置模拟环境
        logger.info("2. 设置模拟环境...")
        simulator = Simulator()
        logger.info(f"   设置模拟参数: start_date={start_date}, end_date={end_date}")
        simulator.setup_simulation(start_date, end_date)
        
        # 3. 创建投资组合
        logger.info("3. 创建投资组合...")
        portfolios = simulator.create_portfolios()
        logger.info(f"   成功创建 {len(portfolios)} 个投资组合")
        for name, portfolio in portfolios.items():
            if name == 'LongOnly':
                logger.info(f"   - {name}: 纯多头，做多排名前5行业")
            elif name == 'LongShort':
                logger.info(f"   - {name}: 多空策略，做多前5，做空后5")
        
        # 4. 运行模拟
        logger.info("4. 开始回测模拟...")
        logger.info(f"   参数: 回看月份={lookback_months}个月")
        results = simulator.run_simulation()
        
        # 5. 获取模拟结果
        logger.info("5. 获取模拟结果...")
        for name, result in results.items():
            if name == 'validation':
                continue
            logger.info(f"   {name}:")
            history = result['history']
            trades = result['trades']
            logger.info(f"     - 总交易日: {len(history)}")
            logger.info(f"     - 调仓次数: {len(trades)}")
            if len(history) > 0 and 'nav' in history.columns:
                final_nav = history['nav'].iloc[-1]
                logger.info(f"     - 最终NAV: {final_nav:,.2f}")
                logger.info(f"     - 总收益率: {(final_nav/1000000-1)*100:.2f}%")
            else:
                logger.info(f"     - 最终NAV: 1,000,000.00")
                logger.info(f"     - 总收益率: 0.00%")
        
        # 6. 保存结果
        logger.info("6. 保存模拟结果...")
        results_dir = simulator.save_results()
        logger.info(f"   结果已保存到: {results_dir}")
        
        # 7. 增强可视化
        logger.info("7. 生成增强可视化...")
        report = run_enhanced_visualization(results, use_plotly=use_plotly)
        
        # 8. 生成总结
        logger.info("8. 生成执行总结...")
        summary = generate_execution_summary(results, results_dir)
        logger.info("\n" + summary)
        
        logger.info("=" * 60)
        logger.info("模拟完成！")
        logger.info("=" * 60)
        
        return results, report
        
    except Exception as e:
        logger.error(f"模拟执行失败: {e}", exc_info=True)
        return None

def generate_execution_summary(results, results_dir):
    """生成执行总结"""
    summary_lines = []
    summary_lines.append("执行总结")
    summary_lines.append("-" * 30)
    
    for name in ['LongOnly', 'LongShort']:
        if name in results:
            history = results[name]['history']
            trades = results[name]['trades']
            
            total_return = (history['nav'].iloc[-1] / 1000000 - 1) * 100
            annual_return = ((1 + total_return/100) ** (252/len(history)) - 1) * 100
            
            summary_lines.append(f"{name}组合:")
            summary_lines.append(f"  总收益率: {total_return:.2f}%")
            summary_lines.append(f"  年化收益(估算): {annual_return:.2f}%")
            summary_lines.append(f"  调仓次数: {len(trades)}")
            summary_lines.append("")
    
    summary_lines.append(f"结果目录: {results_dir}")
    summary_lines.append("包含文件:")
    for file in os.listdir(results_dir):
        summary_lines.append(f"  - {file}")
    
    return "\n".join(summary_lines)

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='申万行业投资组合回测系统 - 增强版')
    parser.add_argument('--start-date', default='2019-01-01', 
                       help='回测开始日期 (YYYY-MM-DD)')
    parser.add_argument('--end-date', default='2024-01-01',
                       help='回测结束日期 (YYYY-MM-DD)')
    parser.add_argument('--lookback-months', type=int, default=3,
                       help='行业排名回看月份数')
    parser.add_argument('--use-plotly', action='store_true',
                       help='使用plotly进行可视化')
    parser.add_argument('--verbose', '-v', action='store_true',
                       help='显示详细日志')
    
    args = parser.parse_args()
    
    # 设置日志级别
    setup_logging(args.verbose)
    
    # 运行模拟
    results = run_full_enhanced_simulation(
        start_date=args.start_date,
        end_date=args.end_date,
        lookback_months=args.lookback_months,
        use_plotly=args.use_plotly
    )
    
    return results

if __name__ == "__main__":
    main()