"""
调仓引擎：实现基于排名的调仓逻辑
"""
import pandas as pd
import numpy as np
from datetime import datetime

class RebalanceEngine:
    def __init__(self, returns_data, performance_calculator, date_manager):
        """
        初始化调仓引擎
        
        Args:
            returns_data: 收益率数据
            performance_calculator: 性能计算器
            date_manager: 日期管理器
        """
        self.returns_data = returns_data
        self.calculator = performance_calculator
        self.date_manager = date_manager
        
    def generate_rebalance_signals(self, rebalance_dates_df, months_back=1):
        """
        生成调仓信号
        
        Args:
            rebalance_dates_df: 调仓日期DataFrame
            months_back: 排名回看月份数
            
        Returns:
            dict: 调仓信号记录
        """
        signals = {}
        
        for _, row in rebalance_dates_df.iterrows():
            base_date = row['rebalance_base_date']
            prepare_date = row['prepare_date']
            effective_date = row['effective_date']
            
            # 在调仓基准日计算排名
            ranking = self.calculator.get_ranking_on_date(base_date, months_back)
            
            signals[base_date] = {
                'base_date': base_date,
                'prepare_date': prepare_date,
                'effective_date': effective_date,
                'ranking': ranking,
                'calculation_details': {
                    'base_date': base_date,
                    'lookback_months': months_back,
                    'num_industries': len(ranking)
                }
            }
            
        return signals
    
    def execute_rebalance(self, portfolio, signals, strategy_params):
        """
        执行调仓操作
        
        Args:
            portfolio: 投资组合对象
            signals: 调仓信号
            strategy_params: 策略参数 {'long_count': 5, 'short_count': 5, 'equal_weight': True}
        """
        long_count = strategy_params.get('long_count', 5)
        short_count = strategy_params.get('short_count', 0)
        equal_weight = strategy_params.get('equal_weight', True)
        
        rebalance_records = []
        
        for base_date, signal in signals.items():
            prepare_date = signal['prepare_date']
            effective_date = signal['effective_date']
            ranking = signal['ranking']
            
            # 标记特殊日期
            portfolio.is_prepare_date = True
            portfolio.current_date = prepare_date
            
            # 计算目标持仓
            target_positions = self._calculate_target_positions(
                ranking, portfolio, long_count, short_count, equal_weight
            )
            
            # 记录调仓前状态
            pre_rebalance_state = {
                'date': prepare_date,
                'portfolio_name': portfolio.name,
                'nav_before': portfolio.current_nav,
                'cash_before': portfolio.current_cash,
                'positions_before': portfolio.positions.copy(),
                'position_values_before': portfolio.position_values.copy()
            }
            
            # 执行调仓（在准备日收盘时）
            portfolio.rebalance(target_positions, rebalance_type='full')
            
            # 记录调仓后状态
            post_rebalance_state = {
                'date': prepare_date,
                'nav_after': portfolio.current_nav,
                'cash_after': portfolio.current_cash,
                'positions_after': portfolio.positions.copy(),
                'position_values_after': portfolio.position_values.copy(),
                'target_positions': target_positions,
                'ranking_used': ranking[['return', 'rank']].to_dict(),
                'strategy_params': strategy_params
            }
            
            # 重置NAV - 这是关键逻辑
            # 调仓后，将当前NAV重置为现金，损益已兑现
            portfolio.current_cash = portfolio.current_nav
            portfolio.positions = {}
            portfolio.position_values = {}
            
            # 重新配置到目标持仓
            actual_positions = {}
            total_allocated = 0
            for industry, value in target_positions.items():
                if abs(value) > 0.01:  # 忽略微小持仓
                    actual_positions[industry] = value
                    portfolio.positions[industry] = value
                    portfolio.position_values[industry] = value
                    total_allocated += value
            
            # 确保现金等于NAV减去总配置
            portfolio.current_cash = portfolio.current_nav - total_allocated
            
            # 记录重置后的状态
            reset_state = {
                'date': effective_date,
                'nav_reset': portfolio.current_nav,
                'cash_reset': portfolio.current_cash,
                'positions_reset': portfolio.positions.copy(),
                'position_values_reset': portfolio.position_values.copy()
            }
            
            rebalance_record = {
                'base_date': base_date,
                'prepare_date': prepare_date,
                'effective_date': effective_date,
                'pre_rebalance': pre_rebalance_state,
                'post_rebalance': post_rebalance_state,
                'after_reset': reset_state,
                'target_allocation': target_positions,
                'actual_allocation': actual_positions
            }
            
            rebalance_records.append(rebalance_record)
            
            # 重置日期标记
            portfolio.is_prepare_date = False
            portfolio.is_effective_date = True
            
        return rebalance_records
    
    def _calculate_target_positions(self, ranking, portfolio, long_count, short_count, equal_weight):
        """
        计算目标持仓
        
        Args:
            ranking: 排名DataFrame
            portfolio: 投资组合
            long_count: 做多行业数量
            short_count: 做空行业数量
            equal_weight: 是否等权重
            
        Returns:
            dict: 目标持仓 {industry: target_value}
        """
        total_nav = portfolio.current_nav
        target_positions = {}
        
        # 获取排名靠前的行业
        top_industries = ranking.head(long_count)
        
        if portfolio.type == 'long_only':
            # 纯多头策略
            if equal_weight:
                weight_per_industry = 1.0 / long_count
                for industry in top_industries.index:
                    target_positions[industry] = total_nav * weight_per_industry
                    
        elif portfolio.type == 'long_short':
            # 多空策略
            # 多头部分
            long_weight = 0.5  # 50%资金做多
            long_value_per = (total_nav * long_weight) / long_count
            
            # 空头部分
            short_industries = ranking.tail(short_count)
            short_weight = -0.5  # 50%资金做空（负值表示）
            short_value_per = (total_nav * abs(short_weight)) / short_count
            
            # 设置目标持仓
            for industry in top_industries.index:
                target_positions[industry] = long_value_per
                
            for industry in short_industries.index:
                target_positions[industry] = -short_value_per
                
        return target_positions
    
    def validate_rebalance_logic(self, rebalance_records):
        """
        验证调仓逻辑的正确性
        
        Args:
            rebalance_records: 调仓记录
            
        Returns:
            dict: 验证结果
        """
        validation_results = {
            'total_rebalances': len(rebalance_records),
            'errors': [],
            'warnings': []
        }
        
        for i, record in enumerate(rebalance_records):
            # 验证调仓前后NAV一致性（允许小误差）
            pre_nav = record['pre_rebalance']['nav_before']
            post_nav = record['post_rebalance']['nav_after']
            
            if abs(pre_nav - post_nav) > 1.0:  # 允许1元误差
                validation_results['errors'].append(
                    f"调仓 {i+1}: NAV不一致，调仓前{pre_nav:.2f}，调仓后{post_nav:.2f}"
                )
            
            # 验证现金重置逻辑（允许小误差）
            reset_nav = record['after_reset']['nav_reset']
            reset_cash = record['after_reset']['cash_reset']
            
            # 计算总持仓
            total_positions = sum(record['after_reset']['positions_reset'].values())
            expected_cash = reset_nav - total_positions
            
            if abs(reset_cash - expected_cash) > 1.0:  # 允许1元误差
                validation_results['warnings'].append(
                    f"调仓 {i+1}: 现金计算可能有误差，现金{reset_cash:.2f}，期望{expected_cash:.2f}"
                )
            
            # 验证持仓总和
            target_positions = record['target_allocation']
            total_target = sum(target_positions.values())
            
            if abs(total_target - reset_nav) > 1.0:
                validation_results['warnings'].append(
                    f"调仓 {i+1}: 目标持仓总和{total_target:.2f}与NAV{reset_nav:.2f}不完全匹配"
                )
        
        return validation_results

# 测试函数
def test_rebalance_engine():
    from data_generator import get_returns_data
    from performance_calculator import PerformanceCalculator
    from date_manager import DateManager
    from portfolio import Portfolio
    
    # 获取数据
    returns_data = get_returns_data()
    
    # 创建相关对象
    calculator = PerformanceCalculator(returns_data)
    date_manager = DateManager(returns_data)
    engine = RebalanceEngine(returns_data, calculator, date_manager)
    
    # 生成调仓日期
    start_date = returns_data.index[100]
    end_date = returns_data.index[200]
    rebalance_dates = date_manager.get_rebalance_dates(start_date, end_date)
    
    # 生成调仓信号
    signals = engine.generate_rebalance_signals(rebalance_dates, months_back=1)
    
    # 创建测试组合
    portfolio = Portfolio('Test', 'long_only', 1000000)
    
    # 执行调仓
    strategy_params = {'long_count': 5, 'short_count': 0, 'equal_weight': True}
    records = engine.execute_rebalance(portfolio, signals, strategy_params)
    
    # 验证
    validation = engine.validate_rebalance_logic(records)
    
    print("调仓引擎测试完成")
    print(f"共执行调仓: {len(records)} 次")
    print(f"验证结果: {validation}")
    
    return engine, records

if __name__ == "__main__":
    engine, records = test_rebalance_engine()