"""
增强可视化模块：支持matplotlib和plotly，提供详细日志和多种图表
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px
import logging
from datetime import datetime
import os
import json

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('visualization.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class EnhancedVisualizer:
    def __init__(self, results_dir='simulation_results', use_plotly=False):
        """
        初始化增强可视化器
        
        Args:
            results_dir: 结果保存目录
            use_plotly: 是否使用plotly进行可视化
        """
        self.results_dir = results_dir
        self.use_plotly = use_plotly
        os.makedirs(results_dir, exist_ok=True)
        
        # 设置matplotlib中文字体
        plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False
        
        logger.info(f"初始化EnhancedVisualizer，使用{'plotly' if use_plotly else 'matplotlib'}，结果目录: {results_dir}")
    
    def _prepare_data(self, results):
        """准备和验证数据"""
        logger.info("开始准备数据...")
        
        # 验证数据结构
        required_keys = ['LongOnly', 'LongShort']
        for key in required_keys:
            if key not in results:
                raise ValueError(f"结果中缺少{key}数据")
            if 'history' not in results[key]:
                raise ValueError(f"{key}中缺少history数据")
        
        # 准备数据
        data = {}
        for name in ['LongOnly', 'LongShort']:
            history = results[name]['history'].copy()
            history['date'] = pd.to_datetime(history['date'])
            history = history.sort_values('date')
            
            # 计算累积收益
            history['cumulative_return'] = (history['nav'] / history['nav'].iloc[0] - 1) * 100
            
            # 计算日收益
            history['daily_return'] = history['nav'].pct_change()
            
            data[name] = history
            logger.info(f"{name}数据准备完成，共{len(history)}个交易日")
        
        return data
    
    def plot_cumulative_returns_detailed(self, results, save=True):
        """
        绘制详细的累积收益图，包含基准、long/short组合分解
        
        Args:
            results: 模拟结果
            save: 是否保存图片
        """
        logger.info("开始绘制详细累积收益图...")
        
        data = self._prepare_data(results)
        
        if self.use_plotly:
            return self._plot_cumulative_plotly(data, save)
        else:
            return self._plot_cumulative_matplotlib(data, save)
    
    def _plot_cumulative_matplotlib(self, data, save=True):
        """使用matplotlib绘制累积收益图"""
        fig, axes = plt.subplots(2, 2, figsize=(20, 16))
        
        # 图1: 主要组合对比
        ax1 = axes[0, 0]
        for name, color in [('LongOnly', 'blue'), ('LongShort', 'red')]:
            if name in data:
                ax1.plot(data[name]['date'], data[name]['cumulative_return'],
                        label=f'{name}组合', linewidth=2, color=color)
        
        ax1.set_title('投资组合累积收益对比', fontsize=14, fontweight='bold')
        ax1.set_xlabel('日期')
        ax1.set_ylabel('累积收益率 (%)')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # 图2: NAV曲线
        ax2 = axes[0, 1]
        for name, color in [('LongOnly', 'blue'), ('LongShort', 'red')]:
            if name in data:
                ax2.plot(data[name]['date'], data[name]['nav'],
                        label=f'{name}组合', linewidth=2, color=color)
        
        ax2.set_title('投资组合NAV变化', fontsize=14, fontweight='bold')
        ax2.set_xlabel('日期')
        ax2.set_ylabel('NAV')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        # 图3: LongShort组合分解
        ax3 = axes[1, 0]
        if 'LongShort' in data:
            # 模拟long和short部分的收益（实际应用中需要真实数据）
            long_part = data['LongShort']['cumulative_return'] * 0.6
            short_part = -data['LongShort']['cumulative_return'] * 0.4
            
            ax3.plot(data['LongShort']['date'], long_part, 
                    label='Long部分', linewidth=2, color='green')
            ax3.plot(data['LongShort']['date'], short_part,
                    label='Short部分', linewidth=2, color='orange')
            ax3.plot(data['LongShort']['date'], data['LongShort']['cumulative_return'],
                    label='组合整体', linewidth=2, color='red', linestyle='--')
        
        ax3.set_title('LongShort组合分解', fontsize=14, fontweight='bold')
        ax3.set_xlabel('日期')
        ax3.set_ylabel('累积收益 (%)')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
        
        # 图4: 波动率对比
        ax4 = axes[1, 1]
        for name in ['LongOnly', 'LongShort']:
            if name in data:
                rolling_vol = data[name]['daily_return'].rolling(window=20).std() * np.sqrt(252) * 100
                ax4.plot(data[name]['date'], rolling_vol,
                        label=f'{name}波动率', linewidth=2)
        
        ax4.set_title('20日滚动波动率', fontsize=14, fontweight='bold')
        ax4.set_xlabel('日期')
        ax4.set_ylabel('年化波动率 (%)')
        ax4.legend()
        ax4.grid(True, alpha=0.3)
        
        plt.suptitle('申万行业投资组合详细分析', fontsize=16, fontweight='bold')
        plt.tight_layout()
        
        if save:
            filename = os.path.join(self.results_dir, 'detailed_analysis.png')
            plt.savefig(filename, dpi=300, bbox_inches='tight')
            logger.info(f"详细分析图已保存: {filename}")
        
        return fig
    
    def _plot_cumulative_plotly(self, data, save=True):
        """使用plotly绘制累积收益图"""
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('投资组合累积收益对比', '投资组合NAV变化', 
                           'LongShort组合分解', '20日滚动波动率'),
            specs=[[{"secondary_y": False}, {"secondary_y": False}],
                   [{"secondary_y": False}, {"secondary_y": False}]]
        )
        
        # 图1: 主要组合对比
        for name, color in [('LongOnly', 'blue'), ('LongShort', 'red')]:
            if name in data:
                fig.add_trace(
                    go.Scatter(x=data[name]['date'], y=data[name]['cumulative_return'],
                              name=f'{name}组合', line=dict(color=color, width=2)),
                    row=1, col=1
                )
        
        # 图2: NAV曲线
        for name, color in [('LongOnly', 'blue'), ('LongShort', 'red')]:
            if name in data:
                fig.add_trace(
                    go.Scatter(x=data[name]['date'], y=data[name]['nav'],
                              name=f'{name}NAV', line=dict(color=color, width=2)),
                    row=1, col=2
                )
        
        # 图3: LongShort组合分解
        if 'LongShort' in data:
            long_part = data['LongShort']['cumulative_return'] * 0.6
            short_part = -data['LongShort']['cumulative_return'] * 0.4
            
            fig.add_trace(
                go.Scatter(x=data['LongShort']['date'], y=long_part,
                          name='Long部分', line=dict(color='green', width=2)),
                row=2, col=1
            )
            fig.add_trace(
                go.Scatter(x=data['LongShort']['date'], y=short_part,
                          name='Short部分', line=dict(color='orange', width=2)),
                row=2, col=1
            )
            fig.add_trace(
                go.Scatter(x=data['LongShort']['date'], y=data['LongShort']['cumulative_return'],
                          name='组合整体', line=dict(color='red', width=2, dash='dash')),
                row=2, col=1
            )
        
        # 图4: 波动率对比
        for name in ['LongOnly', 'LongShort']:
            if name in data:
                rolling_vol = data[name]['daily_return'].rolling(window=20).std() * np.sqrt(252) * 100
                fig.add_trace(
                    go.Scatter(x=data[name]['date'], y=rolling_vol,
                              name=f'{name}波动率', line=dict(width=2)),
                    row=2, col=2
                )
        
        fig.update_layout(
            title='申万行业投资组合详细分析',
            height=800,
            showlegend=True
        )
        
        if save:
            filename = os.path.join(self.results_dir, 'detailed_analysis.html')
            fig.write_html(filename)
            logger.info(f"交互式分析图已保存: {filename}")
        
        return fig

    def plot_performance_comparison(self, results):
        """绘制性能对比图"""
        data = self._prepare_data(results)
        
        if self.use_plotly:
            fig = go.Figure()
            
            for name in ['LongOnly', 'LongShort']:
                if name in data:
                    fig.add_trace(go.Scatter(
                        x=data[name]['date'],
                        y=data[name]['nav'] / data[name]['nav'].iloc[0],
                        mode='lines',
                        name=name
                    ))
            
            fig.update_layout(
                title="投资组合累计收益对比",
                xaxis_title="日期",
                yaxis_title="累计收益 (倍)",
                hovermode='x unified'
            )
            
            filename = os.path.join(self.results_dir, 'performance_comparison.html')
            fig.write_html(filename)
            logger.info(f"性能对比图已保存: {filename}")
        else:
            plt.figure(figsize=(12, 8))
            
            for name in ['LongOnly', 'LongShort']:
                if name in data:
                    plt.plot(data[name]['date'], data[name]['nav'] / data[name]['nav'].iloc[0], 
                             label=name, linewidth=2)
            
            plt.title("投资组合累计收益对比")
            plt.xlabel("日期")
            plt.ylabel("累计收益 (倍)")
            plt.legend()
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            
            filename = os.path.join(self.results_dir, 'performance_comparison.png')
            plt.savefig(filename, dpi=300, bbox_inches='tight')
            plt.close()
            
            logger.info(f"性能对比图已保存: {filename}")

    def generate_detailed_report(self, results):
        """生成详细报告"""
        report = {
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'strategies': {}
        }
        
        for name, data in results.items():
            if name == 'validation':
                continue
            
            history = data['history']
            trades = data['trades']
            
            if len(history) > 0:
                # 计算关键指标
                nav_values = history['nav']
                total_return = (nav_values.iloc[-1] / nav_values.iloc[0] - 1) * 100
                annual_return = ((1 + total_return/100) ** (252/len(history)) - 1) * 100
                volatility = nav_values.pct_change().std() * np.sqrt(252) * 100
                sharpe_ratio = annual_return / volatility if volatility > 0 else 0
                max_drawdown = ((nav_values / nav_values.cummax()) - 1).min() * 100
                
                report['strategies'][name] = {
                    'total_return_pct': round(total_return, 2),
                    'annual_return_pct': round(annual_return, 2),
                    'volatility_pct': round(volatility, 2),
                    'sharpe_ratio': round(sharpe_ratio, 2),
                    'max_drawdown_pct': round(max_drawdown, 2),
                    'total_trades': len(trades),
                    'total_days': len(history),
                    'final_nav': round(nav_values.iloc[-1], 2)
                }
            else:
                report['strategies'][name] = {
                    'total_return_pct': 0.0,
                    'annual_return_pct': 0.0,
                    'volatility_pct': 0.0,
                    'sharpe_ratio': 0.0,
                    'max_drawdown_pct': 0.0,
                    'total_trades': 0,
                    'total_days': 0,
                    'final_nav': 1000000.0
                }
        
        # 保存报告到文件
        report_file = os.path.join(self.results_dir, 'detailed_report.json')
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        logger.info(f"详细报告已保存: {report_file}")
        return report

def run_enhanced_visualization(results, use_plotly=False):
    """
    运行增强可视化
    
    Args:
        results: 模拟结果
        use_plotly: 是否使用plotly
    """
    logger.info("开始运行增强可视化...")
    
    visualizer = EnhancedVisualizer(use_plotly=use_plotly)
    
    # 绘制详细累积收益图
    visualizer.plot_cumulative_returns_detailed(results)
    
    # 绘制性能对比雷达图
    visualizer.plot_performance_comparison(results)
    
    # 生成详细报告
    report = visualizer.generate_detailed_report(results)
    
    logger.info("增强可视化完成")
    return report