"""
投资组合模块：管理不同类型的投资组合
"""
import pandas as pd
import numpy as np
from datetime import datetime

class Portfolio:
    def __init__(self, name, portfolio_type, initial_cash=1000000):
        """
        初始化投资组合
        
        Args:
            name: 组合名称
            portfolio_type: 组合类型 ('long_only', 'long_short', 'benchmark')
            initial_cash: 初始资金
        """
        self.name = name
        self.type = portfolio_type
        self.initial_cash = initial_cash
        self.current_cash = initial_cash
        
        # 持仓信息
        self.positions = {}  # {industry: shares}
        self.position_values = {}  # {industry: value}
        
        # 历史记录
        self.history = []
        self.trades = []
        
        # 当前状态
        self.current_nav = initial_cash
        self.current_date = None
        self.ir = 0.0
        self.return_rate = 0.0
        
        # 特殊日期标记
        self.is_rebalance_date = False
        self.is_prepare_date = False
        self.is_effective_date = False
        
    def update_market_data(self, date, returns_data, industry_prices=None):
        """
        更新市场数据
        
        Args:
            date: 当前日期
            returns_data: 当日收益率数据
            industry_prices: 行业价格数据（用于计算持仓价值）
        """
        self.current_date = date
        
        # 计算持仓价值
        if industry_prices is not None:
            self.position_values = {}
            for industry, shares in self.positions.items():
                if industry in industry_prices:
                    self.position_values[industry] = shares * industry_prices[industry]
        
        # 计算当日收益
        daily_return = 0.0
        if self.positions and date in returns_data.index:
            daily_return = sum(
                self.position_values.get(ind, 0) * returns_data.loc[date, ind]
                for ind in self.positions.keys()
                if ind in returns_data.columns
            )
            
        # 更新NAV
        old_nav = self.current_nav
        self.current_nav += daily_return
        self.return_rate = (self.current_nav - self.initial_cash) / self.initial_cash
        
        # 记录历史
        record = {
            'date': date,
            'nav': self.current_nav,
            'cash': self.current_cash,
            'positions': self.positions.copy(),
            'position_values': self.position_values.copy(),
            'daily_return': daily_return,
            'cumulative_return': self.return_rate,
            'is_rebalance_date': self.is_rebalance_date,
            'is_prepare_date': self.is_prepare_date,
            'is_effective_date': self.is_effective_date
        }
        self.history.append(record)
        
    def rebalance(self, target_positions, rebalance_type='full'):
        """
        执行调仓操作
        
        Args:
            target_positions: 目标持仓 {industry: target_weight} 或 {industry: target_value}
            rebalance_type: 'full'表示完全清仓后重新配置，'partial'表示部分调整
        """
        # 记录调仓前状态
        old_positions = self.positions.copy()
        old_cash = self.current_cash
        old_nav = self.current_nav
        
        if rebalance_type == 'full':
            # 完全清仓 - 关键：重置为现金
            self.current_cash = self.current_nav  # 将持仓全部变现
            self.positions = {}
            self.position_values = {}
            
            # 重新配置
            for industry, target_value in target_positions.items():
                if abs(target_value) > 0.01:  # 忽略微小持仓
                    self.positions[industry] = target_value
                    self.position_values[industry] = target_value
                    self.current_cash -= target_value
                    
        elif rebalance_type == 'partial':
            # 部分调整（保持现有持仓，只调整权重差异）
            total_value = self.current_nav
            
            # 计算需要买卖的金额
            for industry, target_weight in target_positions.items():
                target_value = total_value * target_weight
                current_value = self.position_values.get(industry, 0)
                
                # 计算需要调整的数量
                delta_value = target_value - current_value
                
                if abs(delta_value) > 0.01:  # 忽略微小调整
                    if delta_value > 0:
                        # 买入
                        if self.current_cash >= delta_value:
                            self.positions[industry] = self.positions.get(industry, 0) + delta_value
                            self.position_values[industry] = target_value
                            self.current_cash -= delta_value
                    else:
                        # 卖出
                        sell_value = min(abs(delta_value), current_value)
                        self.positions[industry] = max(0, self.positions.get(industry, 0) - sell_value)
                        self.position_values[industry] = max(0, current_value - sell_value)
                        self.current_cash += sell_value
        
        # 记录交易
        trade_record = {
            'date': self.current_date,
            'type': rebalance_type,
            'old_positions': old_positions,
            'new_positions': self.positions.copy(),
            'old_cash': old_cash,
            'new_cash': self.current_cash,
            'old_nav': old_nav,
            'new_nav': self.current_nav
        }
        self.trades.append(trade_record)
        
    def get_summary(self):
        """获取组合摘要信息"""
        return {
            'name': self.name,
            'type': self.type,
            'initial_cash': self.initial_cash,
            'current_nav': self.current_nav,
            'total_return': self.return_rate,
            'current_positions': self.positions,
            'position_values': self.position_values,
            'cash_ratio': self.current_cash / self.current_nav if self.current_nav > 0 else 0,
            'num_trades': len(self.trades)
        }
    
    def get_history_df(self):
        """获取历史记录DataFrame"""
        return pd.DataFrame(self.history)
    
    def get_trades_df(self):
        """获取交易记录DataFrame"""
        return pd.DataFrame(self.trades)

class PortfolioManager:
    def __init__(self):
        self.portfolios = {}
        
    def create_portfolio(self, name, portfolio_type, initial_cash=1000000):
        """创建新的投资组合"""
        portfolio = Portfolio(name, portfolio_type, initial_cash)
        self.portfolios[name] = portfolio
        return portfolio
    
    def get_portfolio(self, name):
        """获取指定组合"""
        return self.portfolios.get(name)
    
    def get_all_portfolios(self):
        """获取所有组合"""
        return self.portfolios
    
    def update_all_market_data(self, date, returns_data, industry_prices=None):
        """更新所有组合的市场数据"""
        for portfolio in self.portfolios.values():
            portfolio.update_market_data(date, returns_data, industry_prices)

# 测试函数
def test_portfolio():
    from data_generator import get_returns_data
    
    # 获取数据
    returns_data = get_returns_data()
    
    # 创建组合管理器
    manager = PortfolioManager()
    
    # 创建测试组合
    long_only = manager.create_portfolio('LongOnly', 'long_only', 1000000)
    long_short = manager.create_portfolio('LongShort', 'long_short', 1000000)
    benchmark = manager.create_portfolio('Benchmark', 'benchmark', 1000000)
    
    # 测试更新数据
    test_date = returns_data.index[100]
    manager.update_all_market_data(test_date, returns_data)
    
    print("组合测试完成")
    for name, portfolio in manager.portfolios.items():
        print(f"{name}: NAV = {portfolio.current_nav}")
    
    return manager

if __name__ == "__main__":
    manager = test_portfolio()