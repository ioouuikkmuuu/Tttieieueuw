"""
可视化模块：绘制累积收益图和计算IR指标
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import os

class Visualizer:
    def __init__(self, results_dir='simulation_results'):
        """
        初始化可视化器
        
        Args:
            results_dir: 结果保存目录
        """
        self.results_dir = results_dir
        os.makedirs(results_dir, exist_ok=True)
        
        # 设置中文字体
        plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False
        
    def plot_cumulative_returns(self, results, save=True):
        """
        绘制累积收益图
        
        Args:
            results: 模拟结果
            save: 是否保存图片
        """
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(15, 12))
        
        # 获取历史数据
        long_only_history = results['LongOnly']['history']
        long_short_history = results['LongShort']['history']
        
        # 确保日期格式正确
        long_only_history['date'] = pd.to_datetime(long_only_history['date'])
        long_short_history['date'] = pd.to_datetime(long_short_history['date'])
        
        # 绘制累积收益
        ax1.plot(long_only_history['date'], 
                (long_only_history['nav'] / 1000000 - 1) * 100,
                label='LongOnly_Top5', linewidth=2, color='blue')
        
        ax1.plot(long_short_history['date'], 
                (long_short_history['nav'] / 1000000 - 1) * 100,
                label='LongShort_Top5_Bottom5', linewidth=2, color='red')
        
        # 标记调仓日期
        long_only_trades = results['LongOnly']['trades']
        if isinstance(long_only_trades, pd.DataFrame):
            rebalance_dates = long_only_trades['date'].tolist()
        else:
            rebalance_dates = [trade['date'] for trade in long_only_trades]
        
        for date in rebalance_dates:
            if pd.notna(date):
                ax1.axvline(x=pd.to_datetime(date), color='gray', linestyle='--', alpha=0.3)
        
        ax1.set_xlabel('日期')
        ax1.set_ylabel('累积收益率 (%)')
        ax1.set_title('投资组合累积收益对比')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # 绘制NAV曲线
        ax2.plot(long_only_history['date'], 
                long_only_history['nav'],
                label='LongOnly_Top5', linewidth=2, color='blue')
        
        ax2.plot(long_short_history['date'], 
                long_short_history['nav'],
                label='LongShort_Top5_Bottom5', linewidth=2, color='red')
        
        ax2.set_xlabel('日期')
        ax2.set_ylabel('NAV')
        ax2.set_title('投资组合NAV变化')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save:
            filename = os.path.join(self.results_dir, 'cumulative_returns.png')
            plt.savefig(filename, dpi=300, bbox_inches='tight')
            print(f"累积收益图已保存: {filename}")
        
        return fig
    
    def plot_monthly_returns(self, results, save=True):
        """
        绘制月度收益图
        
        Args:
            results: 模拟结果
            save: 是否保存图片
        """
        fig, axes = plt.subplots(2, 1, figsize=(15, 10))
        
        for i, (name, color) in enumerate([('LongOnly', 'blue'), ('LongShort', 'red')]):
            history = results[name]['history']
            
            # 计算月度收益
            history['date'] = pd.to_datetime(history['date'])
            history.set_index('date', inplace=True)
            
            monthly_nav = history['nav'].resample('M').last()
            monthly_returns = monthly_nav.pct_change() * 100
            
            # 绘制柱状图
            monthly_returns.dropna().plot(kind='bar', ax=axes[i], color=color, alpha=0.7)
            axes[i].set_title(f'{name} 月度收益')
            axes[i].set_ylabel('月度收益 (%)')
            axes[i].set_xlabel('月份')
            axes[i].axhline(y=0, color='black', linestyle='-', linewidth=0.5)
            axes[i].grid(True, alpha=0.3)
            
            # 旋转x轴标签
            axes[i].tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        
        if save:
            filename = os.path.join(self.results_dir, 'monthly_returns.png')
            plt.savefig(filename, dpi=300, bbox_inches='tight')
            print(f"月度收益图已保存: {filename}")
        
        return fig
    
    def calculate_ir(self, results):
        """
        计算信息比率(IR)
        
        Args:
            results: 模拟结果
            
        Returns:
            dict: IR计算结果
        """
        ir_results = {}
        
        for name in ['LongOnly', 'LongShort']:
            history = results[name]['history']
            
            # 计算日收益率
            history['daily_return'] = history['nav'].pct_change()
            
            # 计算年化收益率
            annual_return = (1 + history['daily_return'].mean()) ** 252 - 1
            
            # 计算年化波动率
            annual_volatility = history['daily_return'].std() * np.sqrt(252)
            
            # 计算IR（这里使用夏普比率作为近似）
            risk_free_rate = 0.02  # 假设无风险利率2%
            # 避免除零错误
            if annual_volatility > 0:
                ir = (annual_return - risk_free_rate) / annual_volatility
            else:
                ir = np.nan
            
            # 计算最大回撤
            cumulative = (1 + history['daily_return']).cumprod()
            running_max = cumulative.expanding().max()
            drawdown = (cumulative - running_max) / running_max
            max_drawdown = drawdown.min()
            
            ir_results[name] = {
                'annual_return': annual_return,
                'annual_volatility': annual_volatility,
                'ir': ir,
                'max_drawdown': max_drawdown,
                'total_return': (history['nav'].iloc[-1] / history['nav'].iloc[0] - 1),
                'num_trades': len(results[name]['trades'])
            }
        
        return ir_results
    
    def save_ir_results(self, ir_results):
        """
        保存IR计算结果
        
        Args:
            ir_results: IR计算结果
        """
        filename = os.path.join(self.results_dir, 'ir_results.txt')
        
        with open(filename, 'w') as f:
            f.write("投资组合表现分析\n")
            f.write("=" * 50 + "\n\n")
            
            for name, metrics in ir_results.items():
                f.write(f"{name}:\n")
                f.write(f"  总收益率: {metrics['total_return']:.2%}\n")
                f.write(f"  年化收益率: {metrics['annual_return']:.2%}\n")
                f.write(f"  年化波动率: {metrics['annual_volatility']:.2%}\n")
                f.write(f"  信息比率: {metrics['ir']:.3f}\n")
                f.write(f"  最大回撤: {metrics['max_drawdown']:.2%}\n")
                f.write(f"  调仓次数: {metrics['num_trades']}\n")
                f.write("\n")
        
        print(f"IR结果已保存: {filename}")
    
    def generate_summary_report(self, results):
        """
        生成综合报告
        
        Args:
            results: 模拟结果
        """
        # 计算IR
        ir_results = self.calculate_ir(results)
        
        # 保存IR结果
        self.save_ir_results(ir_results)
        
        # 绘制图表
        self.plot_cumulative_returns(results)
        self.plot_monthly_returns(results)
        
        # 创建汇总表
        summary_data = []
        for name in ['LongOnly', 'LongShort']:
            summary = results[name]['summary']
            ir_data = ir_results[name]
            
            summary_data.append({
                '组合名称': name,
                '初始资金': f"{summary['initial_cash']:,.0f}",
                '最终NAV': f"{summary['current_nav']:,.0f}",
                '总收益率': f"{ir_data['total_return']:.2%}",
                '年化收益率': f"{ir_data['annual_return']:.2%}",
                '年化波动率': f"{ir_data['annual_volatility']:.2%}",
                '信息比率': f"{ir_data['ir']:.3f}",
                '最大回撤': f"{ir_data['max_drawdown']:.2%}",
                '调仓次数': summary['num_trades']
            })
        
        summary_df = pd.DataFrame(summary_data)
        
        # 保存汇总表
        summary_file = os.path.join(self.results_dir, 'summary_report.csv')
        summary_df.to_csv(summary_file, index=False, encoding='utf-8-sig')
        
        print("综合报告已生成完成")
        print("\n投资组合表现对比:")
        print(summary_df.to_string(index=False))
        
        return summary_df, ir_results

# 运行可视化的函数
def run_visualization(results=None):
    """
    运行可视化
    
    Args:
        results: 模拟结果，如果为None则加载已保存的结果
    """
    from simulator import run_full_simulation
    
    # 如果未提供结果，运行完整模拟
    if results is None:
        simulator = run_full_simulation()
        results = simulator.get_results()
    
    # 创建可视化器
    visualizer = Visualizer()
    
    # 生成综合报告
    summary_df, ir_results = visualizer.generate_summary_report(results)
    
    return visualizer, summary_df, ir_results

if __name__ == "__main__":
    # 运行可视化
    visualizer, summary, ir = run_visualization()
    print("可视化完成")