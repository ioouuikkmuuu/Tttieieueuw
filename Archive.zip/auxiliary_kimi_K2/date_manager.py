"""
日期管理模块：生成调仓相关的关键日期序列
"""
import pandas as pd
from datetime import datetime, timedelta

class DateManager:
    def __init__(self, returns_data):
        """
        初始化日期管理器
        
        Args:
            returns_data: DataFrame，用于获取交易日历
        """
        self.trading_dates = returns_data.index
        
    def get_rebalance_dates(self, start_date, end_date):
        """
        生成调仓日期序列
        
        Args:
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            DataFrame: 包含调仓基准日、准备日、生效日的完整日期序列
        """
        # 确保日期在交易日内
        start_date = max(start_date, self.trading_dates[0])
        end_date = min(end_date, self.trading_dates[-1])
        
        # 生成月末工作日作为调仓基准日
        monthly_end_dates = []
        current_date = start_date.replace(day=1)
        
        while current_date <= end_date:
            # 找到当月的最后一个交易日
            month_end = current_date + pd.offsets.MonthEnd(0)
            while month_end not in self.trading_dates and month_end >= current_date:
                month_end -= timedelta(days=1)
            
            if month_end >= start_date and month_end <= end_date:
                monthly_end_dates.append(month_end)
            
            current_date = current_date + pd.offsets.MonthBegin(1)
        
        # 构建完整的调仓日期信息
        rebalance_df = pd.DataFrame()
        
        for base_date in monthly_end_dates:
            # 调仓基准日（月末）
            rebalance_base = base_date
            
            # 调仓准备日（月初第一个交易日）
            next_month_start = base_date + pd.offsets.MonthBegin(1)
            prepare_date = next_month_start
            if prepare_date not in self.trading_dates:
                # 如果不是交易日，找到下一个交易日
                idx = self.trading_dates.searchsorted(prepare_date)
                if idx < len(self.trading_dates):
                    prepare_date = self.trading_dates[idx]
            
            # 调仓生效日（月初第二个交易日）
            idx = self.trading_dates.searchsorted(prepare_date) + 1
            if idx < len(self.trading_dates):
                effective_date = self.trading_dates[idx]
            else:
                effective_date = prepare_date
                
            rebalance_df = pd.concat([rebalance_df, pd.DataFrame({
                'rebalance_base_date': [rebalance_base],
                'prepare_date': [prepare_date],
                'effective_date': [effective_date]
            })], ignore_index=True)
        
        return rebalance_df
    
    def get_date_sequence(self, start_date, end_date):
        """
        获取完整的交易日序列
        
        Args:
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            Series: 交易日序列
        """
        mask = (self.trading_dates >= start_date) & (self.trading_dates <= end_date)
        return self.trading_dates[mask]

# 测试函数
def test_date_manager():
    from data_generator import get_returns_data
    
    # 获取数据
    returns_data = get_returns_data()
    
    # 创建日期管理器
    date_manager = DateManager(returns_data)
    
    # 测试生成调仓日期
    start_date = returns_data.index[0]
    end_date = returns_data.index[-1]
    
    rebalance_dates = date_manager.get_rebalance_dates(start_date, end_date)
    
    print("调仓日期序列:")
    print(rebalance_dates.head())
    print(f"\n共生成 {len(rebalance_dates)} 个调仓周期")
    
    return date_manager

if __name__ == "__main__":
    date_manager = test_date_manager()