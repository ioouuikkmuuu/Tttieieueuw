# 申万行业投资组合回测系统

这是一个完整的申万行业投资组合回测框架，支持LongOnly和LongShort策略的模拟交易。

## 项目结构

```
auxiliary_kimi_K2/
├── data_generator.py      # 数据生成模块
├── performance_calculator.py  # 性能计算模块
├── date_manager.py        # 日期管理模块
├── portfolio.py          # 投资组合管理
├── rebalance_engine.py   # 调仓引擎
├── simulator.py          # 模拟器
├── visualizer.py         # 可视化模块
├── main.py              # 主程序入口
├── README.md            # 使用说明
└── requirements.txt     # 依赖包
```

## 功能特性

### 1. 数据生成
- 自动生成申万一级行业过去5年的模拟交易数据
- 包含28个申万一级行业
- 不同行业具有不同的波动率和趋势特征
- 支持数据缓存和重新生成

### 2. 投资组合策略
- **LongOnly策略**: 做多排名前5的行业
- **LongShort策略**: 做多前5行业，做空后5行业
- 初始资金各100万元
- 无交易成本

### 3. 调仓逻辑
- **调仓基准日**: 月末最后一个交易日，计算行业排名
- **调仓准备日**: 月初第一个交易日，执行调仓决策
- **调仓生效日**: 月初第二个交易日，新持仓开始生效
- **NAV重置**: 每次调仓后将损益兑现，重置为现金再投资

### 4. 详细记录
- 完整的持仓历史记录
- 每笔调仓的详细记录
- 排名计算过程记录
- 调仓前后状态对比
- 验证逻辑正确性

## 安装依赖

```bash
pip install -r requirements.txt
```

## 快速开始

### 1. 运行完整模拟
```bash
python main.py
```

### 2. 运行自定义模拟
```bash
# 指定时间范围和排名回看月份
python main.py 2020-01-01 2023-12-31 3
```

### 3. 分步运行
```python
from simulator import Simulator
from visualizer import run_visualization

# 创建模拟器
simulator = Simulator()
simulator.setup_simulation()
simulator.create_portfolios()
simulator.run_simulation(months_back=1)

# 获取结果
results = simulator.get_results()

# 生成可视化
visualizer, summary, ir = run_visualization(results)
```

## 输出文件

运行后会在`simulation_results_YYYYMMDD_HHMMSS/`目录下生成以下文件：

### 数据文件
- `LongOnly_history.csv`: LongOnly组合历史记录
- `LongShort_history.csv`: LongShort组合历史记录
- `LongOnly_trades.csv`: LongOnly组合交易记录
- `LongShort_trades.csv`: LongShort组合交易记录

### 分析文件
- `summary_report.csv`: 投资组合表现汇总
- `ir_results.txt`: IR计算结果
- `validation_results.txt`: 验证结果

### 图表文件
- `cumulative_returns.png`: 累积收益对比图
- `monthly_returns.png`: 月度收益图

## 数据格式说明

### 历史记录格式
- `date`: 日期
- `nav`: 当日NAV
- `cash`: 当日现金
- `positions`: 持仓详情
- `daily_return`: 当日收益
- `cumulative_return`: 累积收益
- `is_rebalance_date`: 是否为调仓日

### 交易记录格式
- `date`: 交易日期
- `type`: 交易类型
- `old_positions`: 调仓前持仓
- `new_positions`: 调仓后持仓
- `old_cash`: 调仓前现金
- `new_cash`: 调仓后现金

## 验证逻辑

系统包含完整的验证机制：

1. **NAV一致性验证**: 确保调仓前后NAV保持一致
2. **现金重置验证**: 确保调仓后现金等于NAV
3. **持仓总和验证**: 确保持仓总和等于总资金
4. **日期逻辑验证**: 确保调仓日期序列正确

## 自定义策略

可以通过继承相关类来实现自定义策略：

```python
from rebalance_engine import RebalanceEngine

class CustomRebalanceEngine(RebalanceEngine):
    def _calculate_target_positions(self, ranking, portfolio, long_count, short_count, equal_weight):
        # 实现自定义的持仓计算逻辑
        pass
```

## 性能指标

系统计算以下性能指标：

- **总收益率**: 整个期间的绝对收益
- **年化收益率**: 年化后的收益率
- **年化波动率**: 年化后的波动率
- **信息比率(IR)**: (年化收益率 - 无风险利率) / 年化波动率
- **最大回撤**: 期间最大回撤幅度

## 注意事项

1. 所有收益计算基于日频数据
2. 调仓频率为月度
3. 无考虑交易成本
4. 假设可以完美执行交易
5. 做空时假设可以完美做空

## 技术支持

如有问题，请检查：
1. 数据文件是否完整
2. 日期范围是否在数据范围内
3. 依赖包是否正确安装
4. 验证结果是否有错误