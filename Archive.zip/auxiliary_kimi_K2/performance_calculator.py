"""
性能计算模块：计算绝对涨跌幅和排名
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

class PerformanceCalculator:
    def __init__(self, returns_data):
        """
        初始化性能计算器
        
        Args:
            returns_data: DataFrame，index为交易日，columns为行业，值为日收益率
        """
        self.returns_data = returns_data
        
    def calculate_absolute_returns(self, start_date, end_date, months_back=None):
        """
        计算指定时间段的绝对涨跌幅
        
        Args:
            start_date: 开始日期
            end_date: 结束日期  
            months_back: 如果提供，则从end_date往前推N个月
        
        Returns:
            Series: 各行业绝对涨跌幅，index为行业名称
        """
        if months_back is not None:
            # 计算从end_date往前推N个月的日期
            start_date = end_date - pd.DateOffset(months=months_back)
            
        # 确保日期在数据范围内
        available_dates = self.returns_data.index
        start_date = max(start_date, available_dates[0])
        end_date = min(end_date, available_dates[-1])
        
        # 计算累计收益
        period_returns = self.returns_data.loc[start_date:end_date]
        cumulative_returns = (1 + period_returns).prod() - 1
        
        return cumulative_returns
    
    def calculate_ranking(self, returns, ascending=False):
        """
        计算排名分数
        
        Args:
            returns: Series，各行业收益率
            ascending: 是否升序排列（False表示降序，即高收益排名高）
        
        Returns:
            DataFrame: 包含收益率和排名的DataFrame
        """
        # 创建排名DataFrame
        ranking_df = pd.DataFrame({
            'return': returns,
            'rank': returns.rank(ascending=ascending, method='min')
        })
        
        # 添加排名百分比
        ranking_df['rank_pct'] = ranking_df['rank'] / len(returns)
        
        return ranking_df.sort_values('rank')
    
    def get_ranking_on_date(self, date, months_back=1):
        """
        获取指定日期的排名信息
        
        Args:
            date: 计算排名的日期
            months_back: 往前看多少个月
            
        Returns:
            DataFrame: 包含收益率、排名、排名百分比等信息
        """
        returns = self.calculate_absolute_returns(None, date, months_back)
        ranking = self.calculate_ranking(returns)
        
        # 添加计算日期
        ranking['calculation_date'] = date
        ranking['lookback_months'] = months_back
        
        return ranking

# 测试函数
def test_performance_calculator():
    from data_generator import get_returns_data
    
    # 获取数据
    returns_data = get_returns_data()
    
    # 创建计算器
    calculator = PerformanceCalculator(returns_data)
    
    # 测试计算
    test_date = returns_data.index[-100]  # 取倒数第100天
    ranking = calculator.get_ranking_on_date(test_date, months_back=3)
    
    print("\n排名结果示例:")
    print(ranking.head(10))
    
    return calculator

if __name__ == "__main__":
    calculator = test_performance_calculator()