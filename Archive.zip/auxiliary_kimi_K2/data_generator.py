"""
数据生成模块：生成申万行业过去5年的模拟交易数据
"""
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os

class DataGenerator:
    def __init__(self):
        # 申万一级行业分类
        self.industries = [
            '农林牧渔', '采掘', '化工', '钢铁', '有色金属', '电子', '家用电器', 
            '食品饮料', '纺织服装', '轻工制造', '医药生物', '公用事业', '交通运输',
            '房地产', '商业贸易', '休闲服务', '综合', '建筑材料', '建筑装饰', 
            '电气设备', '国防军工', '计算机', '传媒', '通信', '银行', '非银金融',
            '汽车', '机械设备'
        ]
        
    def generate_returns_data(self, start_date='2019-01-01', end_date='2024-01-01'):
        """
        生成模拟收益率数据
        返回DataFrame格式：index为交易日，columns为行业，值为日收益率
        """
        # 生成交易日历（排除周末）
        date_range = pd.bdate_range(start=start_date, end=end_date)
        
        # 生成模拟收益率数据
        np.random.seed(42)  # 保证结果可重现
        
        # 为每个行业生成收益率，加入行业特性
        returns_data = {}
        for industry in self.industries:
            # 不同行业有不同的波动率和趋势
            if industry in ['银行', '非银金融']:
                volatility = 0.015  # 金融类波动较小
                trend = 0.0001
            elif industry in ['计算机', '传媒', '电子']:
                volatility = 0.035  # 科技类波动较大
                trend = 0.0005
            else:
                volatility = 0.025
                trend = 0.0002
                
            # 生成收益率序列
            returns = np.random.normal(trend, volatility, len(date_range))
            returns_data[industry] = returns
            
        df = pd.DataFrame(returns_data, index=date_range)
        df.index.name = 'date'
        
        return df
    
    def save_data(self, df, filepath='sw_industry_returns.csv'):
        """保存数据到CSV文件"""
        df.to_csv(filepath)
        print(f"数据已保存到: {filepath}")
        
    def load_data(self, filepath='sw_industry_returns.csv'):
        """从CSV文件加载数据"""
        if os.path.exists(filepath):
            df = pd.read_csv(filepath, index_col=0, parse_dates=True)
            print(f"已从 {filepath} 加载数据")
            return df
        else:
            print(f"文件 {filepath} 不存在，将生成新数据")
            return None

# 接口函数，直接获取数据
def get_returns_data(filepath='sw_industry_returns.csv'):
    """
    直接获取收益率数据的接口函数
    如果文件存在则直接读取，否则生成新数据
    """
    generator = DataGenerator()
    data = generator.load_data(filepath)
    if data is None:
        data = generator.generate_returns_data()
        generator.save_data(data, filepath)
    return data

if __name__ == "__main__":
    # 测试数据生成
    generator = DataGenerator()
    data = generator.generate_returns_data()
    print(f"生成了 {len(data)} 天的数据，包含 {len(data.columns)} 个行业")
    print(data.head())
    generator.save_data(data)