"""
系统测试脚本：验证整个回测系统的正确性
"""
import os
import sys
import pandas as pd
import numpy as np
from datetime import datetime

# 添加当前目录到路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def test_data_generation():
    """测试数据生成模块"""
    print("测试数据生成模块...")
    
    from data_generator import DataGenerator, get_returns_data
    
    # 测试数据生成
    generator = DataGenerator()
    data = generator.generate_returns_data()
    
    # 验证数据格式
    assert isinstance(data, pd.DataFrame), "数据应为DataFrame格式"
    assert len(data.columns) == 28, f"应有28个行业，实际有{len(data.columns)}个"
    assert data.index.name == 'date', "索引应为date"
    assert len(data) > 1000, "数据量应大于1000天"
    
    # 验证数据范围
    assert data.min().min() > -0.2, "单日跌幅不应超过20%"
    assert data.max().max() < 0.2, "单日涨幅不应超过20%"
    
    # 测试数据保存和加载
    test_file = 'test_data.csv'
    generator.save_data(data, test_file)
    loaded_data = generator.load_data(test_file)
    
    assert loaded_data is not None, "应能成功加载数据"
    assert len(loaded_data) == len(data), "加载的数据长度应一致"
    
    # 清理测试文件
    if os.path.exists(test_file):
        os.remove(test_file)
    
    print("✓ 数据生成模块测试通过")
    return True

def test_performance_calculation():
    """测试性能计算模块"""
    print("测试性能计算模块...")
    
    from data_generator import get_returns_data
    from performance_calculator import PerformanceCalculator
    
    # 获取测试数据
    returns_data = get_returns_data()
    calculator = PerformanceCalculator(returns_data)
    
    # 测试排名计算
    test_date = returns_data.index[-100]
    ranking = calculator.get_ranking_on_date(test_date, months_back=3)
    
    assert isinstance(ranking, pd.DataFrame), "排名应为DataFrame格式"
    assert 'return' in ranking.columns, "应包含return列"
    assert 'rank' in ranking.columns, "应包含rank列"
    assert len(ranking) == 28, "应包含28个行业"
    
    # 验证排名正确性
    assert ranking['rank'].is_monotonic_increasing, "排名应递增"
    assert ranking['rank'].min() == 1, "排名应从1开始"
    assert ranking['rank'].max() == 28, "排名应到28"
    
    print("✓ 性能计算模块测试通过")
    return True

def test_date_management():
    """测试日期管理模块"""
    print("测试日期管理模块...")
    
    from data_generator import get_returns_data
    from date_manager import DateManager
    
    returns_data = get_returns_data()
    date_manager = DateManager(returns_data)
    
    # 测试调仓日期生成
    start_date = returns_data.index[100]
    end_date = returns_data.index[200]
    rebalance_dates = date_manager.get_rebalance_dates(start_date, end_date)
    
    assert isinstance(rebalance_dates, pd.DataFrame), "应为DataFrame格式"
    assert len(rebalance_dates) > 0, "应生成调仓日期"
    assert 'rebalance_base_date' in rebalance_dates.columns
    assert 'prepare_date' in rebalance_dates.columns
    assert 'effective_date' in rebalance_dates.columns
    
    # 验证日期逻辑
    for _, row in rebalance_dates.iterrows():
        assert row['prepare_date'] > row['rebalance_base_date'], "准备日应在基准日之后"
        assert row['effective_date'] >= row['prepare_date'], "生效日应在准备日或之后"
    
    print("✓ 日期管理模块测试通过")
    return True

def test_portfolio_management():
    """测试投资组合管理"""
    print("测试投资组合管理...")
    
    from portfolio import Portfolio, PortfolioManager
    
    # 测试组合创建
    portfolio = Portfolio('Test', 'long_only', 1000000)
    
    assert portfolio.name == 'Test'
    assert portfolio.type == 'long_only'
    assert portfolio.initial_cash == 1000000
    assert portfolio.current_nav == 1000000
    
    # 测试调仓
    target_positions = {'银行': 500000, '计算机': 500000}
    portfolio.current_date = '2023-01-01'  # 设置当前日期
    portfolio.rebalance(target_positions, 'full')
    
    assert len(portfolio.positions) == 2
    assert abs(portfolio.current_cash) < 100  # 允许小的舍入误差
    assert abs(portfolio.current_nav - 1000000) < 100  # NAV应保持不变
    
    # 测试历史记录
    assert len(portfolio.trades) > 0
    
    print("✓ 投资组合管理测试通过")
    return True

def test_rebalance_logic():
    """测试调仓逻辑"""
    print("测试调仓逻辑...")
    
    from data_generator import get_returns_data
    from performance_calculator import PerformanceCalculator
    from date_manager import DateManager
    from rebalance_engine import RebalanceEngine
    from portfolio import Portfolio
    
    # 设置测试环境
    returns_data = get_returns_data()
    calculator = PerformanceCalculator(returns_data)
    date_manager = DateManager(returns_data)
    engine = RebalanceEngine(returns_data, calculator, date_manager)
    
    # 生成测试信号
    start_date = returns_data.index[100]
    end_date = returns_data.index[150]
    rebalance_dates = date_manager.get_rebalance_dates(start_date, end_date)
    signals = engine.generate_rebalance_signals(rebalance_dates, months_back=1)
    
    # 创建测试组合
    portfolio = Portfolio('Test', 'long_only', 1000000)
    
    # 执行调仓
    strategy_params = {'long_count': 5, 'short_count': 0, 'equal_weight': True}
    records = engine.execute_rebalance(portfolio, signals, strategy_params)
    
    # 验证调仓记录
    assert len(records) > 0, "应生成调仓记录"
    
    # 验证调仓逻辑
    validation = engine.validate_rebalance_logic(records)
    assert len(validation['errors']) == 0, f"存在验证错误: {validation['errors']}"
    
    print("✓ 调仓逻辑测试通过")
    return True

def test_full_simulation():
    """测试完整模拟"""
    print("测试完整模拟...")
    
    from simulator import Simulator
    import pandas as pd
    
    # 创建模拟器
    simulator = Simulator()
    simulator.setup_simulation(pd.to_datetime('2020-01-01'), pd.to_datetime('2021-01-01'))
    simulator.create_portfolios()
    simulator.run_simulation(months_back=1)
    
    # 获取结果
    results = simulator.get_results()
    
    # 验证结果
    assert 'LongOnly' in results
    assert 'LongShort' in results
    assert 'validation' in results
    
    for name, data in results.items():
        if name != 'validation':
            history = data['history']
            assert len(history) > 0, f"{name} 应有历史记录"
            
            summary = data['summary']
            assert summary['initial_cash'] == 1000000
            assert summary['current_nav'] > 0
    
    # 验证调仓逻辑
    for name, validation in results['validation'].items():
        print(f"{name} 验证结果:")
        print(f"  调仓次数: {validation['total_rebalances']}")
        if validation['errors']:
            print(f"  错误: {len(validation['errors'])}")
        if validation['warnings']:
            print(f"  警告: {len(validation['warnings'])}")
    
    print("✓ 完整模拟测试通过")
    return True

def run_all_tests():
    """运行所有测试"""
    print("=" * 60)
    print("系统测试开始")
    print("=" * 60)
    
    tests = [
        test_data_generation,
        test_performance_calculation,
        test_date_management,
        test_portfolio_management,
        test_rebalance_logic,
        test_full_simulation
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f"✗ {test.__name__} 测试失败: {str(e)}")
            failed += 1
    
    print("\n" + "=" * 60)
    print("测试完成")
    print(f"通过: {passed} 个测试")
    print(f"失败: {failed} 个测试")
    print("=" * 60)
    
    return failed == 0

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)