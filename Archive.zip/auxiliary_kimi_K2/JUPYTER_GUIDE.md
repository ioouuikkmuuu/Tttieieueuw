# Jupyter Notebook 使用指南

## 快速开始

### 1. 启动Jupyter Notebook

```bash
# 在项目目录下启动
jupyter notebook Quantitative_Backtesting_Demo.ipynb
```

或者使用VS Code直接打开 `.ipynb` 文件。

### 2. 环境要求

确保已安装以下Python包：

```bash
pip install jupyter pandas numpy matplotlib seaborn plotly
```

### 3. Notebook内容概览

Notebook包含以下主要部分：

#### 📊 第1-2节：环境准备
- 自动安装必要依赖
- 导入系统模块和配置

#### 📈 第3-4节：数据准备和基础回测
- 加载真实市场数据或生成模拟数据
- 运行基础回测演示

#### 🎨 第5-6节：可视化分析
- 生成增强可视化报告
- 展示生成的图表和报告

#### 📋 第7-9节：深入分析
- 交易记录详细分析
- 自定义参数回测
- 结果文件说明

### 4. 运行顺序

建议按以下顺序运行：

1. **环境准备** (第1-2节) - 必须运行
2. **数据加载** (第3节) - 必须运行
3. **基础回测** (第4节) - 必须运行
4. **可视化** (第5-6节) - 推荐运行
5. **分析** (第7-9节) - 可选运行

### 5. 自定义参数

#### 修改回测参数
```python
# 在单元格8中修改参数
custom_simulator = Simulator(
    start_date='2020-01-01',    # 开始日期
    end_date='2021-12-31',      # 结束日期
    rebalance_freq='weekly',    # 再平衡频率: daily, weekly, monthly
    initial_nav=1000000.0,    # 初始资金
)
```

#### 使用Plotly交互式图表
```python
# 在可视化调用中设置use_plotly=True
report = run_enhanced_visualization(results, use_plotly=True)
```

### 6. 输出文件说明

运行完成后，会在 `simulation_results/` 目录生成：

| 文件 | 说明 |
|------|------|
| `*_history.csv` | 历史净值数据 |
| `*_trades.csv` | 交易记录 |
| `detailed_report.json` | 详细绩效报告 |
| `performance_comparison.png` | 策略对比图 |
| `cumulative_returns.png` | 累计收益图 |
| `monthly_returns.png` | 月度收益图 |

### 7. 常见问题

#### 数据文件不存在
- 系统会自动生成模拟数据
- 或手动放置真实数据到 `sw_industry_returns.csv`

#### 图表显示问题
- 确保已安装中文字体包
- 在macOS上可能需要安装Arial Unicode MS字体

#### 内存使用
- 建议每次只运行一个策略对比
- 大数据集可以分段处理

### 8. 扩展功能

#### 添加新策略
在 `portfolio.py` 中实现新的策略类，然后在Notebook中调用。

#### 自定义指标
在 `performance_calculator.py` 中添加新的绩效指标。

#### 数据格式
数据应为CSV格式，包含：
- `date` 列：日期
- 其他列：各行业/股票的收益率

### 9. 性能优化

- 使用 `use_plotly=False` 提高渲染速度
- 减少回测时间范围加快测试
- 使用较小的数据集进行调试

### 10. 示例运行

```bash
# 完整运行示例
python main_enhanced.py --start-date 2019-01-01 --end-date 2020-01-01 --verbose

# 使用Jupyter交互式运行
jupyter notebook Quantitative_Backtesting_Demo.ipynb
```

## 技术支持

如有问题，请检查：
1. Python版本 ≥ 3.8
2. 所有依赖包已安装
3. 数据文件格式正确
4. 有足够的磁盘空间存储结果