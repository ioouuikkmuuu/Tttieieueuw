"""
模拟器：运行完整的回测模拟
"""
import pandas as pd
import numpy as np
from datetime import datetime
import os

from data_generator import get_returns_data
from performance_calculator import PerformanceCalculator
from date_manager import DateManager
from portfolio import PortfolioManager
from rebalance_engine import RebalanceEngine

class Simulator:
    def __init__(self):
        self.returns_data = None
        self.calculator = None
        self.date_manager = None
        self.portfolio_manager = None
        self.rebalance_engine = None
        
    def setup_simulation(self, start_date=None, end_date=None):
        """
        设置模拟环境
        
        Args:
            start_date: 开始日期
            end_date: 结束日期
        """
        # 获取数据
        self.returns_data = get_returns_data()
        
        # 设置日期范围
        if start_date is None:
            start_date = self.returns_data.index[0]
        elif isinstance(start_date, str):
            start_date = pd.to_datetime(start_date)
            
        if end_date is None:
            end_date = self.returns_data.index[-1]
        elif isinstance(end_date, str):
            end_date = pd.to_datetime(end_date)
            
        self.start_date = start_date
        self.end_date = end_date
        
        # 初始化各模块
        self.calculator = PerformanceCalculator(self.returns_data)
        self.date_manager = DateManager(self.returns_data)
        self.portfolio_manager = PortfolioManager()
        self.rebalance_engine = RebalanceEngine(
            self.returns_data, self.calculator, self.date_manager
        )
        
        print(f"模拟环境设置完成，日期范围: {start_date} 到 {end_date}")
        
    def create_portfolios(self):
        """创建投资组合"""
        # 创建LongOnly组合
        self.long_only_portfolio = self.portfolio_manager.create_portfolio(
            'LongOnly_Top5', 'long_only', 1000000
        )
        
        # 创建LongShort组合
        self.long_short_portfolio = self.portfolio_manager.create_portfolio(
            'LongShort_Top5_Bottom5', 'long_short', 1000000
        )
        
        print("已创建投资组合:")
        print("- LongOnly_Top5: 纯多头，做多排名前5行业")
        print("- LongShort_Top5_Bottom5: 多空策略，做多前5，做空后5")
        
        # 返回投资组合字典
        return {
            'LongOnly': self.long_only_portfolio,
            'LongShort': self.long_short_portfolio
        }
        
    def run_simulation(self, months_back=1):
        """
        运行完整模拟
        
        Args:
            months_back: 排名回看月份数
            
        Returns:
            dict: 模拟结果
        """
        # 生成调仓日期
        rebalance_dates = self.date_manager.get_rebalance_dates(
            self.start_date, self.end_date
        )
        
        # 生成调仓信号
        signals = self.rebalance_engine.generate_rebalance_signals(
            rebalance_dates, months_back
        )
        
        # 获取完整的交易日序列
        trading_dates = self.date_manager.get_date_sequence(
            self.start_date, self.end_date
        )
        
        # 初始化调仓记录
        self.long_only_records = []
        self.long_short_records = []
        
        # 执行调仓
        long_only_params = {'long_count': 5, 'short_count': 0, 'equal_weight': True}
        long_short_params = {'long_count': 5, 'short_count': 5, 'equal_weight': True}
        
        self.long_only_records = self.rebalance_engine.execute_rebalance(
            self.long_only_portfolio, signals, long_only_params
        )
        
        self.long_short_records = self.rebalance_engine.execute_rebalance(
            self.long_short_portfolio, signals, long_short_params
        )
        
        # 运行日常更新
        self._run_daily_updates(trading_dates)
        
        # 验证调仓逻辑
        self.validation_results = {
            'LongOnly': self.rebalance_engine.validate_rebalance_logic(self.long_only_records),
            'LongShort': self.rebalance_engine.validate_rebalance_logic(self.long_short_records)
        }
        
        print("模拟运行完成")
        
        # 返回结果
        return self.get_results()
        
    def _run_daily_updates(self, trading_dates):
        """运行日常更新"""
        for date in trading_dates:
            # 更新所有组合的市场数据
            self.portfolio_manager.update_all_market_data(
                date, self.returns_data.loc[date]
            )
            
    def get_results(self):
        """获取模拟结果"""
        results = {
            'LongOnly': {
                'portfolio': self.long_only_portfolio,
                'records': self.long_only_records,
                'history': self.long_only_portfolio.get_history_df(),
                'trades': self.long_only_portfolio.get_trades_df(),
                'summary': self.long_only_portfolio.get_summary()
            },
            'LongShort': {
                'portfolio': self.long_short_portfolio,
                'records': self.long_short_records,
                'history': self.long_short_portfolio.get_history_df(),
                'trades': self.long_short_portfolio.get_trades_df(),
                'summary': self.long_short_portfolio.get_summary()
            },
            'validation': self.validation_results
        }
        
        return results
    
    def save_results(self, output_dir='simulation_results'):
        """保存模拟结果"""
        os.makedirs(output_dir, exist_ok=True)
        
        results = self.get_results()
        
        # 保存历史数据
        for name, data in results.items():
            if name != 'validation':
                # 保存历史记录
                history_df = data['history']
                history_file = os.path.join(output_dir, f'{name}_history.csv')
                history_df.to_csv(history_file, index=False)
                
                # 保存交易记录
                trades_df = data['trades']
                trades_file = os.path.join(output_dir, f'{name}_trades.csv')
                trades_df.to_csv(trades_file, index=False)
        
        # 保存验证结果
        validation_file = os.path.join(output_dir, 'validation_results.txt')
        with open(validation_file, 'w') as f:
            for name, validation in results['validation'].items():
                f.write(f"\n{name} 验证结果:\n")
                f.write(f"总调仓次数: {validation['total_rebalances']}\n")
                if validation['errors']:
                    f.write("错误:\n")
                    for error in validation['errors']:
                        f.write(f"  - {error}\n")
                if validation['warnings']:
                    f.write("警告:\n")
                    for warning in validation['warnings']:
                        f.write(f"  - {warning}\n")
        
        print(f"结果已保存到 {output_dir} 目录")
        return output_dir

# 运行完整模拟的函数
def run_full_simulation():
    """运行完整模拟并返回结果"""
    simulator = Simulator()
    
    # 设置模拟环境
    simulator.setup_simulation()
    
    # 创建组合
    simulator.create_portfolios()
    
    # 运行模拟
    simulator.run_simulation(months_back=1)
    
    # 保存结果
    simulator.save_results()
    
    return simulator

if __name__ == "__main__":
    # 运行完整模拟
    simulator = run_full_simulation()
    
    # 打印结果摘要
    results = simulator.get_results()
    
    print("\n=== 模拟结果摘要 ===")
    for name, data in results.items():
        if name != 'validation':
            summary = data['summary']
            print(f"\n{name}:")
            print(f"  初始资金: {summary['initial_cash']:,.0f}")
            print(f"  最终NAV: {summary['current_nav']:,.0f}")
            print(f"  总收益率: {summary['total_return']:.2%}")
            print(f"  调仓次数: {summary['num_trades']}")
    
    # 打印验证结果
    print("\n=== 验证结果 ===")
    for name, validation in results['validation'].items():
        print(f"\n{name}:")
        print(f"  总调仓次数: {validation['total_rebalances']}")
        if validation['errors']:
            print(f"  错误: {len(validation['errors'])} 个")
        if validation['warnings']:
            print(f"  警告: {len(validation['warnings'])} 个")