"""
主程序入口：整合所有模块，提供完整的回测框架
"""
import os
import sys
from datetime import datetime

# 添加当前目录到路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from data_generator import get_returns_data
from simulator import Simulator
from visualizer import run_visualization

def main():
    """
    主程序入口
    """
    print("=" * 60)
    print("申万行业投资组合回测系统")
    print("=" * 60)
    
    # 创建结果目录
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results_dir = f"simulation_results_{timestamp}"
    
    # 步骤1: 检查数据
    print("\n1. 检查数据...")
    try:
        returns_data = get_returns_data()
        print(f"   ✓ 数据加载成功，包含 {len(returns_data)} 个交易日，{len(returns_data.columns)} 个行业")
        print(f"   ✓ 数据时间范围: {returns_data.index[0]} 到 {returns_data.index[-1]}")
    except Exception as e:
        print(f"   ✗ 数据加载失败: {str(e)}")
        return
    
    # 步骤2: 设置模拟
    print("\n2. 设置模拟环境...")
    simulator = Simulator()
    simulator.setup_simulation()
    
    # 步骤3: 创建组合
    print("\n3. 创建投资组合...")
    simulator.create_portfolios()
    
    # 步骤4: 运行模拟
    print("\n4. 运行回测模拟...")
    simulator.run_simulation(months_back=1)
    
    # 步骤5: 获取结果
    print("\n5. 获取模拟结果...")
    results = simulator.get_results()
    
    # 步骤6: 保存结果
    print("\n6. 保存结果...")
    simulator.save_results(results_dir)
    
    # 步骤7: 可视化
    print("\n7. 生成可视化图表...")
    visualizer, summary_df, ir_results = run_visualization(results)
    
    # 步骤8: 输出总结
    print("\n" + "=" * 60)
    print("模拟结果总结")
    print("=" * 60)
    
    print("\n投资组合表现:")
    print("-" * 60)
    print(f"{'组合名称':<20} {'初始资金':<12} {'最终NAV':<12} {'总收益率':<10} {'调仓次数':<8}")
    print("-" * 60)
    
    for name, data in results.items():
        if name != 'validation':
            summary = data['summary']
            print(f"{summary['name']:<20} {summary['initial_cash']:<12,.0f} "
                  f"{summary['current_nav']:<12,.0f} {summary['total_return']:<10.2%} "
                  f"{summary['num_trades']:<8}")
    
    print("\n验证结果:")
    print("-" * 60)
    for name, validation in results['validation'].items():
        print(f"{name}:")
        print(f"  总调仓次数: {validation['total_rebalances']}")
        if validation['errors']:
            print(f"  错误: {len(validation['errors'])} 个")
            for error in validation['errors']:
                print(f"    - {error}")
        if validation['warnings']:
            print(f"  警告: {len(validation['warnings'])} 个")
            for warning in validation['warnings']:
                print(f"    - {warning}")
    
    print(f"\n所有结果已保存到: {results_dir}/")
    print("\n文件说明:")
    print("  - LongOnly_history.csv: LongOnly组合历史记录")
    print("  - LongShort_history.csv: LongShort组合历史记录")
    print("  - LongOnly_trades.csv: LongOnly组合交易记录")
    print("  - LongShort_trades.csv: LongShort组合交易记录")
    print("  - cumulative_returns.png: 累积收益图")
    print("  - monthly_returns.png: 月度收益图")
    print("  - summary_report.csv: 汇总报告")
    print("  - ir_results.txt: IR计算结果")
    print("  - validation_results.txt: 验证结果")

def run_custom_simulation(start_date='2020-01-01', end_date='2023-12-31', months_back=3):
    """
    运行自定义参数模拟
    
    Args:
        start_date: 开始日期
        end_date: 结束日期
        months_back: 排名回看月份数
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results_dir = f"custom_simulation_{timestamp}"
    
    print(f"\n运行自定义模拟...")
    print(f"开始日期: {start_date}")
    print(f"结束日期: {end_date}")
    print(f"排名回看: {months_back} 个月")
    
    simulator = Simulator()
    simulator.setup_simulation(start_date, end_date)
    simulator.create_portfolios()
    simulator.run_simulation(months_back)
    simulator.save_results(results_dir)
    
    results = simulator.get_results()
    visualizer, summary_df, ir_results = run_visualization(results)
    
    return simulator, results

if __name__ == "__main__":
    if len(sys.argv) > 1:
        # 如果有命令行参数，运行自定义模拟
        start_date = sys.argv[1] if len(sys.argv) > 1 else '2020-01-01'
        end_date = sys.argv[2] if len(sys.argv) > 2 else '2023-12-31'
        months_back = int(sys.argv[3]) if len(sys.argv) > 3 else 1
        
        run_custom_simulation(start_date, end_date, months_back)
    else:
        # 默认运行完整模拟
        main()