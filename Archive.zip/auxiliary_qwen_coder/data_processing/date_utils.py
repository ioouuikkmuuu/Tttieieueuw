import pandas as pd
from datetime import datetime, timedelta
import logging
import os

# 创建logs目录
logs_dir = 'logs'
if not os.path.exists(logs_dir):
    os.makedirs(logs_dir)

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(logs_dir, 'date_utils.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def generate_rebalancing_dates(returns_df, start_date=None):
    """
    生成调仓相关的日期列表
    
    参数:
    returns_df: 收益率数据DataFrame
    start_date: 起始日期
    
    返回:
    dates_dict: 包含各种调仓日期的字典
    """
    logger.info("开始生成调仓日期列表...")
    
    # 确定起始日期
    if start_date is None:
        start_date = returns_df.index[0]
    else:
        # 确保起始日期在数据范围内
        if start_date < returns_df.index[0]:
            start_date = returns_df.index[0]
    
    logger.info(f"起始日期: {start_date}")
    
    # 获取数据范围内的所有日期
    all_dates = returns_df.index[returns_df.index >= start_date]
    logger.info(f"数据范围内的交易日总数: {len(all_dates)}")
    
    # 生成月末工作日作为调仓基准日
    # 首先生成所有月末日期
    month_ends = pd.date_range(start=start_date, end=returns_df.index[-1], freq='M')
    logger.info(f"生成月末日期，共 {len(month_ends)} 个")
    
    # 然后找到最接近的交易日
    rebalancing_base_dates = []
    for month_end in month_ends:
        # 找到该月末之前的最后一个交易日
        closest_date = all_dates[all_dates <= month_end][-1]
        rebalancing_base_dates.append(closest_date)
    
    # 去除重复日期并排序
    rebalancing_base_dates = sorted(list(set(rebalancing_base_dates)))
    logger.info(f"调仓基准日数量: {len(rebalancing_base_dates)}")
    
    # 生成调仓准备日（月初）
    # 首先生成所有月初日期
    month_starts = pd.date_range(start=start_date, end=returns_df.index[-1], freq='MS')
    logger.info(f"生成月初日期，共 {len(month_starts)} 个")
    
    # 然后找到最接近的交易日
    rebalancing_prep_dates = []
    for month_start in month_starts:
        # 确保月初日期在数据范围内
        if month_start <= returns_df.index[-1]:
            # 找到该月初之后的第一个交易日
            if month_start in all_dates:
                closest_date = month_start
            else:
                try:
                    closest_date = all_dates[all_dates >= month_start][0]
                except IndexError:
                    # 如果没有找到，跳过这个日期
                    continue
            rebalancing_prep_dates.append(closest_date)
    
    logger.info(f"调仓准备日数量: {len(rebalancing_prep_dates)}")
    
    # 生成调仓生效日（调仓准备日的第二天）
    rebalancing_effective_dates = []
    for prep_date in rebalancing_prep_dates:
        # 找到准备日之后的第一个交易日
        try:
            next_dates = all_dates[all_dates > prep_date]
            if len(next_dates) > 0:
                rebalancing_effective_dates.append(next_dates[0])
        except IndexError:
            # 如果没有找到，跳过这个日期
            continue
    
    logger.info(f"调仓生效日数量: {len(rebalancing_effective_dates)}")
    
    # 确保三个日期列表长度一致，以最短的为准
    min_length = min(len(rebalancing_base_dates), len(rebalancing_prep_dates), len(rebalancing_effective_dates))
    rebalancing_base_dates = rebalancing_base_dates[:min_length]
    rebalancing_prep_dates = rebalancing_prep_dates[:min_length]
    rebalancing_effective_dates = rebalancing_effective_dates[:min_length]
    
    logger.info(f"调整后，调仓基准日、准备日、生效日数量均为: {min_length}")
    
    # 构建返回字典
    dates_dict = {
        'base_dates': rebalancing_base_dates,      # 调仓基准日（月末工作日）
        'prep_dates': rebalancing_prep_dates,      # 调仓准备日（月初第一个交易日）
        'effective_dates': rebalancing_effective_dates  # 调仓生效日（准备日后的第一个交易日）
    }
    
    logger.info("调仓日期列表生成完成")
    return dates_dict

def is_special_date(date, dates_dict):
    """
    检查日期是否为特殊调仓日期
    """
    date_type = None
    if date in dates_dict['base_dates']:
        date_type = '调仓基准日'
    elif date in dates_dict['prep_dates']:
        date_type = '调仓准备日'
    elif date in dates_dict['effective_dates']:
        date_type = '调仓生效日'
    
    return date_type