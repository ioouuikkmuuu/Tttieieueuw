import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
import logging
import os
import warnings

warnings.filterwarnings('ignore')

# 创建logs目录
logs_dir = 'logs'
if not os.path.exists(logs_dir):
    os.makedirs(logs_dir)

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(logs_dir, 'data_generator.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

warnings.filterwarnings('ignore')

def generate_simulated_data():
    """
    生成模拟交易数据
    index: 交易日
    col: 申万行业
    val: returns
    时间范围: 过去5年
    """
    logger.info("开始生成模拟交易数据...")
    
    # 生成交易日 (过去5年)
    end_date = datetime.today()
    start_date = end_date - timedelta(days=5*365)
    
    # 生成交易日序列 (工作日)
    dates = pd.bdate_range(start=start_date, end=end_date)
    logger.info(f"生成交易日序列，从 {start_date.date()} 到 {end_date.date()}，共 {len(dates)} 个交易日")
    
    # 申万行业列表 (示例)
    industries = [
        '农林牧渔', '采掘', '化工', '钢铁', '有色金属',
        '电子', '家用电器', '食品饮料', '纺织服装', '轻工制造',
        '医药生物', '公用事业', '交通运输', '房地产', '商业贸易',
        '休闲服务', '综合', '建筑材料', '建筑装饰', '电气设备',
        '国防军工', '计算机', '传媒', '通信', '银行',
        '非银金融', '汽车', '机械设备'
    ]
    logger.info(f"行业列表: {', '.join(industries)}")
    
    # 生成模拟收益率数据
    np.random.seed(42)  # 为了结果可重现
    data = {}
    for industry in industries:
        # 生成具有一定趋势和波动性的收益率
        trend = np.random.normal(0.0002, 0.0001, len(dates))  # 微弱趋势
        noise = np.random.normal(0, 0.02, len(dates))  # 随机噪声
        returns = trend + noise
        data[industry] = returns
    
    # 创建DataFrame
    df = pd.DataFrame(data, index=dates)
    df.index.name = 'date'
    
    logger.info(f"模拟数据生成完成，数据形状: {df.shape}")
    return df

def calculate_rank_scores(returns_df, n_months=12):
    """
    计算过去N个月的绝对涨跌幅，并排名
    """
    logger.info(f"开始计算过去{n_months}个月的排名分数...")
    
    # 计算过去N个月的累计收益率
    period_returns = returns_df.rolling(window=n_months*21).sum()  # 假设每月约21个交易日
    logger.info(f"累计收益率计算完成，数据形状: {period_returns.shape}")
    
    # 计算排名 (按累计收益率降序排列)
    rank_scores = period_returns.rank(axis=1, ascending=False)
    logger.info(f"排名分数计算完成，数据形状: {rank_scores.shape}")
    
    return period_returns, rank_scores

def save_data_to_file(data_df, filename='simulated_data.csv'):
    """
    将数据保存到文件
    """
    logger.info(f"开始保存数据到文件: {filename}")
    
    # 确保data目录存在
    data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)
    
    filepath = os.path.join(data_dir, filename)
    data_df.to_csv(filepath)
    logger.info(f"数据已保存到 {filepath}")
    return filepath

def load_data_from_file(filename='simulated_data.csv'):
    """
    从文件加载数据
    """
    logger.info(f"开始从文件加载数据: {filename}")
    
    data_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')
    filepath = os.path.join(data_dir, filename)
    try:
        data_df = pd.read_csv(filepath, index_col=0, parse_dates=True)
        logger.info(f"数据已从 {filepath} 加载，数据形状: {data_df.shape}")
        return data_df
    except FileNotFoundError:
        logger.error(f"文件 {filepath} 不存在，请先生成数据")
        return None