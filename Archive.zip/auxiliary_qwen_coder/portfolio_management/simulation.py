import pandas as pd
import numpy as np
import sys
import pandas as pd
import logging
import os
from datetime import datetime, timedelta
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from data_processing.data_generator import load_data_from_file, calculate_rank_scores
from data_processing.date_utils import generate_rebalancing_dates
from portfolio_management.portfolio import Portfolio

# 创建logs目录
logs_dir = 'logs'
if not os.path.exists(logs_dir):
    os.makedirs(logs_dir)

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(logs_dir, 'simulation.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


def run_simulation():
    """
    运行模拟交易
    """
    logger.info("开始模拟交易")
    
    # 加载数据
    logger.info("正在加载数据...")
    returns_df = load_data_from_file('simulated_data.csv')
    if returns_df is None:
        logger.error("数据加载失败，退出模拟")
        return
    
    logger.info(f"数据加载成功，时间范围: {returns_df.index[0]} 到 {returns_df.index[-1]}")
    
    # 计算排名分数 (过去12个月)
    logger.info("正在计算排名分数...")
    period_returns, rank_scores = calculate_rank_scores(returns_df, n_months=12)
    
    # 生成调仓日期
    logger.info("正在生成调仓日期...")
    dates_dict = generate_rebalancing_dates(returns_df)
    logger.info(f"调仓基准日数量: {len(dates_dict['base_dates'])}")
    logger.info(f"调仓准备日数量: {len(dates_dict['prep_dates'])}")
    logger.info(f"调仓生效日数量: {len(dates_dict['effective_dates'])}")
    
    # 创建投资组合
    logger.info("正在创建投资组合...")
    # 1. 多头策略：买入排名前5的行业
    long_only_portfolio = Portfolio("Long Only", initial_cash=1000000, portfolio_type='long_only')
    
    # 2. 多空策略：买入排名前5，卖出排名后5
    long_short_portfolio = Portfolio("Long/Short", initial_cash=1000000, portfolio_type='long_short')
    
    # 3. 基准策略：等权重持有所有行业
    benchmark_portfolio = Portfolio("Benchmark", initial_cash=1000000, portfolio_type='benchmark')
    
    # 获取所有交易日
    all_dates = returns_df.index.tolist()
    
    # 检查调仓日期是否在数据范围内
    base_dates_in_range = [d for d in dates_dict['base_dates'] if d in returns_df.index]
    prep_dates_in_range = [d for d in dates_dict['prep_dates'] if d in returns_df.index]
    effective_dates_in_range = [d for d in dates_dict['effective_dates'] if d in returns_df.index]
    
    logger.info(f"有效调仓基准日数量: {len(base_dates_in_range)}")
    logger.info(f"有效调仓准备日数量: {len(prep_dates_in_range)}")
    logger.info(f"有效调仓生效日数量: {len(effective_dates_in_range)}")
    
    # 开始模拟交易
    logger.info("开始模拟交易...")
    for i, date in enumerate(all_dates):
        if i % 50 == 0:  # 每50个交易日打印一次进度
            logger.info(f"处理日期: {date}, 进度: {i+1}/{len(all_dates)}")
        
        # 检查是否为调仓准备日
        is_rebalance = date in prep_dates_in_range
        
        # 更新各投资组合
        long_only_portfolio.update_position(date, returns_df, rank_scores, rebalance=is_rebalance, m=5, n=5)
        long_short_portfolio.update_position(date, returns_df, rank_scores, rebalance=is_rebalance, m=5, n=5)
        benchmark_portfolio.update_position(date, returns_df, rebalance=False)  # 基准组合不调仓
    
    # 打印最终结果
    logger.info("\n模拟交易完成，最终结果:")
    logger.info(f"多头组合最终NAV: {long_only_portfolio.NAV:,.2f}")
    logger.info(f"多空组合最终NAV: {long_short_portfolio.NAV:,.2f}")
    logger.info(f"基准组合最终NAV: {benchmark_portfolio.NAV:,.2f}")
    
    # 保存结果
    save_results(long_only_portfolio, long_short_portfolio, benchmark_portfolio)
    
    return long_only_portfolio, long_short_portfolio, benchmark_portfolio

def save_results(long_only, long_short, benchmark):
    """
    保存结果到文件
    """
    # 创建结果目录
    results_dir = os.path.join(os.path.dirname(__file__), '..', 'results')
    if not os.path.exists(results_dir):
        os.makedirs(results_dir)
    
    # 保存投资组合历史
    portfolios = [long_only, long_short, benchmark]
    
    for portfolio in portfolios:
        # 获取历史数据
        history_df = portfolio.get_history_dataframe()
        
        # 保存到CSV
        filename = f"{portfolio.name.replace('/', '_')}_history.csv"
        filepath = os.path.join(results_dir, filename)
        history_df.to_csv(filepath)
        print(f"{portfolio.name} 历史数据已保存到 {filepath}")
        
        # 保存调仓历史
        if portfolio.rebalancing_history:
            rebalancing_df = pd.DataFrame(portfolio.rebalancing_history)
            rebalancing_filename = f"{portfolio.name.replace('/', '_')}_rebalancing.csv"
            rebalancing_filepath = os.path.join(results_dir, rebalancing_filename)
            rebalancing_df.to_csv(rebalancing_filepath, index=False)
            print(f"{portfolio.name} 调仓历史已保存到 {rebalancing_filepath}")

if __name__ == "__main__":
    run_simulation()