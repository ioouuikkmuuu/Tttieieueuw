import sys
import os
import logging
import os

# 创建logs目录
logs_dir = 'logs'
if not os.path.exists(logs_dir):
    os.makedirs(logs_dir)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(logs_dir, 'system.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

sys.path.append(os.path.dirname(__file__))

from data_processing.data_generator import generate_simulated_data, save_data_to_file, load_data_from_file
from data_processing.date_utils import generate_rebalancing_dates
from portfolio_management.simulation import run_simulation
from visualization.plotting import plot_cumulative_returns


def main():
    """
    主函数，整合所有功能
    """
    logger.info("开始执行主程序")
    print("=== 模拟数据生成与投资组合管理系统 ===")
    
    # 步骤1: 生成模拟数据
    logger.info("步骤1: 生成模拟数据")
    print("\n步骤1: 生成模拟数据")
    simulated_data = generate_simulated_data()
    print(f"生成了 {len(simulated_data)} 天的数据，包含 {len(simulated_data.columns)} 个行业")
    filepath = save_data_to_file(simulated_data)
    print(f"数据已保存到 {filepath}")
    
    # 步骤2: 运行模拟交易
    logger.info("步骤2: 运行模拟交易")
    print("\n步骤2: 运行模拟交易")
    portfolios = run_simulation()
    
    # 步骤3: 可视化结果
    logger.info("步骤3: 可视化结果")
    print("\n步骤3: 可视化结果")
    plot_cumulative_returns()
    
    logger.info("主程序执行完成")
    print("\n所有步骤已完成！")

if __name__ == "__main__":
    main()