#!/bin/bash

# Start the Streamlit application

# Check if .env file exists
if [ ! -f .env ]; then
    echo "Warning: .env file not found. Please create one with your Tushare API token."
    echo "You can copy .env.example to .env and update the token."
fi

streamlit run main.py --server.headless true --server.port 8501 --browser.gatherUsageStats false