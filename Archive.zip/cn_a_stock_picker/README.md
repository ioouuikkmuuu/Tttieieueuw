# Chinese A-Stock Picker

This application helps you pick Chinese A-shares based on various technical signals and indicators.

## Features

1. **Stock Universe Selection**: Select from popular Chinese stock indexes (A50, HS300, CSI500, CSI800)
2. **Signal Calculation**: Calculate various technical signals including:
   - Moving averages (5, 20, 60 days)
   - Volume spikes
   - Price-volume divergence (top and bottom)
3. **Signal Annotation**: Annotate stocks with signals and save relevant information including industry and market cap ranking
4. **Visualization**: Interactive candlestick charts with signal markers using Plotly
5. **Future Returns Calculation**: Calculate future returns for selected stocks
6. **Web Validation**: Automatically open stock pages on Eastmoney for verification

## Installation

1. Install the required packages:
   ```
   pip install -r requirements.txt
   ```

2. Get a Tushare API token:
   - Register at https://tushare.pro/
   - Copy the `.env.example` file to `.env` and replace `your-actual-token-here` with your actual token
   - Alternatively, you can run the setup script:
     ```
     python setup_token.py
     ```

## Usage

### 通过Streamlit界面使用

Run the application:
```
streamlit run main.py
```

### 通过命令行脚本使用

1. 获取特定日期的沪深300股票信号：
```
python get_hs300_signals.py
```

2. 生成详细报告：
```
python generate_report.py
```

## Modules

- `data/stock_data.py`: Retrieve stock data from Tushare
- `signals/calculator.py`: Calculate technical signals
- `signals/annotator.py`: Annotate signals with additional information
- `signals/returns.py`: Calculate future returns
- `visualization/chart.py`: Create interactive charts
- `utils/validator.py`: Open web pages for validation

## Notes

- The application uses Tushare API to retrieve stock data
- Industry information and market cap rankings are included in the annotated signals
- Charts are generated using Plotly with Dash/Streamlit
- Future returns are calculated based on historical data
- Web validation opens stock pages on Eastmoney