"""
脚本功能：获取2025年8月26日沪深300指数中符合特定信号的股票及其相关信息

此脚本将：
1. 获取2025年8月26日沪深300成分股数据
2. 计算每只股票的技术指标
3. 检测交易信号
4. 筛选出具有RSI背离信号的股票
5. 生成CSV报告
"""

import pandas as pd
from datetime import datetime
import os
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# 检查Tushare token是否已设置
if not os.getenv('TUSHARE_TOKEN') or os.getenv('TUSHARE_TOKEN') == 'your-actual-token-here':
    print("错误：Tushare token未设置或无效。")
    print("请在.env文件中设置您的Tushare token，或运行 'python setup_token.py' 进行配置。")
    exit(1)

# 在检查token后导入模块
try:
    from data.stock_data import get_stock_universe, get_stock_industry_info
    from signals.calculator import calculate_all_signals
    from signals.annotator import annotate_signals
except ImportError as e:
    print(f"导入模块时出错: {e}")
    exit(1)


def get_hs300_signals(target_date='2025-08-26'):
    """
    获取目标日期沪深300股票的信号数据
    
    参数:
    target_date (str): 目标日期，格式为 YYYY-MM-DD
    
    返回:
    pd.DataFrame: 包含沪深300股票信号的DataFrame
    """
    print(f"正在获取 {target_date} 的沪深300股票数据...")
    
    # 获取沪深300股票数据
    stock_data = get_stock_universe(['HS300'], target_date)
    
    # 检查是否获取到数据
    if not stock_data or 'HS300' not in stock_data or not stock_data['HS300']:
        print("未获取到股票数据。请检查您的Tushare token和网络连接。")
        return pd.DataFrame()
    
    print(f"已获取 {len(stock_data['HS300'])} 只股票的数据。")
    
    # 为每只股票计算信号
    all_signals = {}
    
    if 'HS300' in stock_data:
        universe_signals = {}
        
        for stock, data in stock_data['HS300'].items():
            if not data.empty:
                print(f"正在计算 {stock} 的信号...")
                signals = calculate_all_signals(data)
                universe_signals[stock] = signals
        
        all_signals['HS300'] = universe_signals
    
    # 注释信号
    if 'HS300' in all_signals:
        print("正在注释信号...")
        annotated_df = annotate_signals(all_signals['HS300'], stock_data, 'HS300')
        return annotated_df
    
    return pd.DataFrame()


def filter_signals(df):
    """
    根据特定信号条件筛选股票
    
    参数:
    df (pd.DataFrame): 包含注释信号的DataFrame
    
    返回:
    pd.DataFrame: 筛选后的DataFrame
    """
    # 检查是否有数据可筛选
    if df.empty:
        return df
    
    # RSI背离信号筛选条件
    def has_rsi_bullish_divergence(signal_dict):
        """检查是否存在RSI看涨背离信号"""
        if isinstance(signal_dict, dict) and 'rsi_divergence' in signal_dict:
            div = signal_dict['rsi_divergence']
            if isinstance(div, dict) and 'rsi_bullish_divergence' in div:
                series = div['rsi_bullish_divergence']
                if isinstance(series, pd.Series) and len(series) > 0:
                    return series.iloc[-1]
        return False
    
    def has_rsi_bearish_divergence(signal_dict):
        """检查是否存在RSI看跌背离信号"""
        if isinstance(signal_dict, dict) and 'rsi_divergence' in signal_dict:
            div = signal_dict['rsi_divergence']
            if isinstance(div, dict) and 'rsi_bearish_divergence' in div:
                series = div['rsi_bearish_divergence']
                if isinstance(series, pd.Series) and len(series) > 0:
                    return series.iloc[-1]
        return False
    
    # 应用筛选条件
    filtered_df = df[
        df.apply(lambda row: has_rsi_bullish_divergence(row), axis=1) |
        df.apply(lambda row: has_rsi_bearish_divergence(row), axis=1)
    ]
    
    return filtered_df


def main():
    print("中国A股选股器 - 沪深300信号分析")
    print("=============================================")
    
    # 获取目标日期沪深300股票的注释信号
    annotated_df = get_hs300_signals('2025-08-26')
    
    if not annotated_df.empty:
        print(f"\n在2025-08-26找到 {len(annotated_df)} 只沪深300股票具有信号")
        
        # 首先显示所有股票
        print("\n所有沪深300股票信号:")
        print(annotated_df[['stock_code', 'industry', 'market_cap_rank', 'close_price', 'volume']].head(10))
        
        # 筛选特定信号
        filtered_df = filter_signals(annotated_df)
        
        if not filtered_df.empty:
            print(f"\n找到 {len(filtered_df)} 只符合RSI背离信号条件的沪深300股票:")
            result_df = filtered_df[['stock_code', 'industry', 'market_cap_rank', 'close_price', 'volume']]
            print(result_df)
            
            # 保存到CSV
            filename = f"hs300_signals_20250826.csv"
            filtered_df.to_csv(filename, index=False)
            print(f"\n结果已保存到 {filename}")
        else:
            print("\n没有沪深300股票符合RSI背离信号条件。")
            
            # 显示所有股票作为替代
            print("\n显示所有沪深300股票信号:")
            result_df = annotated_df[['stock_code', 'industry', 'market_cap_rank', 'close_price', 'volume']]
            print(result_df)
            
            # 保存到CSV
            filename = f"hs300_all_signals_20250826.csv"
            annotated_df.to_csv(filename, index=False)
            print(f"\n结果已保存到 {filename}")
    else:
        print("\n在2025-08-26未找到沪深300股票信号")


if __name__ == "__main__":
    main()