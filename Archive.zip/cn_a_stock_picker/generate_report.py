"""
脚本功能：生成2025年8月26日沪深300指数中符合特定信号的股票详细分析报告

此脚本将：
1. 获取2025年8月26日沪深300成分股数据
2. 计算每只股票的技术指标
3. 检测交易信号
4. 筛选出具有RSI背离信号的股票
5. 计算未来收益预测
6. 生成包含完整信息的详细报告
"""

import pandas as pd
import os
from datetime import datetime
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# 检查Tushare token是否已设置
if not os.getenv('TUSHARE_TOKEN') or os.getenv('TUSHARE_TOKEN') == 'your-actual-token-here':
    print("错误：Tushare token未设置或无效。")
    print("请在.env文件中设置您的Tushare token，或运行 'python setup_token.py' 进行配置。")
    exit(1)

# 在检查token后导入模块
try:
    from data.stock_data import get_stock_universe, get_stock_industry_info
    from signals.calculator import calculate_all_signals
    from signals.annotator import annotate_signals
    from signals.returns import calculate_future_returns
except ImportError as e:
    print(f"导入模块时出错: {e}")
    exit(1)


def generate_detailed_report(target_date='2025-08-26'):
    """
    生成目标日期沪深300股票的详细报告
    
    参数:
    target_date (str): 目标日期，格式为 YYYY-MM-DD
    
    返回:
    None
    """
    print(f"正在生成 {target_date} 沪深300股票的详细报告...")
    
    # 获取沪深300股票数据
    stock_data = get_stock_universe(['HS300'], target_date)
    
    # 检查是否获取到数据
    if not stock_data or 'HS300' not in stock_data or not stock_data['HS300']:
        print("未获取到股票数据。请检查您的Tushare token和网络连接。")
        return
    
    print(f"已获取 {len(stock_data['HS300'])} 只股票的数据。")
    
    # 为每只股票计算信号
    all_signals = {}
    
    if 'HS300' in stock_data:
        universe_signals = {}
        
        for stock, data in stock_data['HS300'].items():
            if not data.empty:
                print(f"正在计算 {stock} 的信号...")
                signals = calculate_all_signals(data)
                universe_signals[stock] = signals
        
        all_signals['HS300'] = universe_signals
    
    # 注释信号
    if 'HS300' in all_signals:
        print("正在注释信号...")
        annotated_df = annotate_signals(all_signals['HS300'], stock_data, 'HS300')
        
        # 筛选具有RSI背离信号的股票
        filtered_df = filter_rsi_divergence_signals(annotated_df)
        
        # 生成报告
        if not filtered_df.empty:
            print(f"\n找到 {len(filtered_df)} 只具有RSI背离信号的沪深300股票:")
            
            # 添加未来收益数据
            print("正在计算未来收益...")
            stock_list = filtered_df['stock_code'].tolist()
            returns_data = calculate_future_returns(stock_list)
            
            # 合并收益数据与筛选后的DataFrame
            returns_df = pd.DataFrame.from_dict(returns_data, orient='index')
            returns_df.index.name = 'stock_code'
            returns_df.reset_index(inplace=True)
            
            # 合并数据
            final_report = pd.merge(filtered_df, returns_df, on='stock_code', how='left')
            
            # 保存到CSV
            filename = f"hs300_detailed_report_{target_date.replace('-', '')}.csv"
            final_report.to_csv(filename, index=False)
            print(f"详细报告已保存到 {filename}")
            
            # 打印摘要
            print("\n详细报告摘要:")
            print(final_report[['stock_code', 'industry', 'market_cap_rank', 'close_price', 'volume', 'return_pct']])
        else:
            print("\n未找到具有RSI背离信号的沪深300股票。")
            
            # 保存所有股票到CSV
            filename = f"hs300_all_signals_{target_date.replace('-', '')}.csv"
            annotated_df.to_csv(filename, index=False)
            print(f"所有信号已保存到 {filename}")


def filter_rsi_divergence_signals(df):
    """
    根据RSI背离信号条件筛选股票
    
    参数:
    df (pd.DataFrame): 包含注释信号的DataFrame
    
    返回:
    pd.DataFrame: 筛选后的DataFrame
    """
    # 检查是否有数据可筛选
    if df.empty:
        return df
    
    # RSI背离信号筛选条件
    def has_rsi_bullish_divergence(signal_dict):
        """检查是否存在RSI看涨背离信号"""
        if isinstance(signal_dict, dict) and 'rsi_divergence' in signal_dict:
            div = signal_dict['rsi_divergence']
            if isinstance(div, dict) and 'rsi_bullish_divergence' in div:
                series = div['rsi_bullish_divergence']
                if isinstance(series, pd.Series) and len(series) > 0:
                    return series.iloc[-1]
        return False
    
    def has_rsi_bearish_divergence(signal_dict):
        """检查是否存在RSI看跌背离信号"""
        if isinstance(signal_dict, dict) and 'rsi_divergence' in signal_dict:
            div = signal_dict['rsi_divergence']
            if isinstance(div, dict) and 'rsi_bearish_divergence' in div:
                series = div['rsi_bearish_divergence']
                if isinstance(series, pd.Series) and len(series) > 0:
                    return series.iloc[-1]
        return False
    
    # 应用筛选条件
    filtered_df = df[
        df.apply(lambda row: has_rsi_bullish_divergence(row), axis=1) |
        df.apply(lambda row: has_rsi_bearish_divergence(row), axis=1)
    ]
    
    return filtered_df


def main():
    print("中国A股选股器 - 沪深300详细报告生成器")
    print("=====================================================")
    
    # 生成目标日期沪深300股票的详细报告
    generate_detailed_report('2025-08-26')


if __name__ == "__main__":
    main()