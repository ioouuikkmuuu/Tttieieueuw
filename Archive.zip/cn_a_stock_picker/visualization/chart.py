"""
Module for visualizing stock data and signals
"""

import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd


def create_candlestick_chart(data, signals=None):
    """
    Create a candlestick chart with optional signal markers
    
    Parameters:
    data (pd.DataFrame): Stock data with OHLCV columns
    signals (dict): Dictionary with signal information
    
    Returns:
    go.Figure: Plotly figure object
    """
    # Create subplots (candlestick + volume + RSI)
    fig = make_subplots(
        rows=3, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.05,
        row_heights=[0.6, 0.2, 0.2],
        specs=[[{"secondary_y": False}], [{"secondary_y": False}], [{"secondary_y": False}]]
    )
    
    # Add candlestick chart
    fig.add_trace(
        go.Candlestick(
            x=data.index,
            open=data['open'],
            high=data['high'],
            low=data['low'],
            close=data['close'],
            name="Price"
        ),
        row=1, col=1
    )
    
    # Add volume bars
    fig.add_trace(
        go.Bar(
            x=data.index,
            y=data['vol'],
            name="Volume",
            marker_color='lightblue'
        ),
        row=2, col=1
    )
    
    # Add RSI if provided
    if signals and 'rsi' in signals:
        fig.add_trace(
            go.Scatter(
                x=data.index,
                y=signals['rsi'],
                mode='lines',
                name='RSI',
                line=dict(color='purple')
            ),
            row=3, col=1
        )
        
        # Add RSI overbought/oversold lines
        fig.add_hline(y=70, line_dash="dash", line_color="red", row=3, col=1)
        fig.add_hline(y=30, line_dash="dash", line_color="green", row=3, col=1)
        
        # Update y-axis for RSI
        fig.update_yaxes(title_text="RSI", row=3, col=1)
        fig.update_yaxes(range=[0, 100], row=3, col=1)
    
    # Add signal markers if provided
    if signals:
        for signal_type, signal_data in signals.items():
            if signal_type == 'moving_averages':
                # Add moving average lines
                for ma_name, ma_values in signal_data.items():
                    fig.add_trace(
                        go.Scatter(
                            x=data.index,
                            y=ma_values,
                            mode='lines',
                            name=ma_name
                        ),
                        row=1, col=1
                    )
            elif signal_type == 'volume_spikes':
                # Add volume spike markers
                spike_indices = data[signal_data].index
                fig.add_trace(
                    go.Scatter(
                        x=spike_indices,
                        y=data.loc[spike_indices, 'high'],
                        mode='markers',
                        marker=dict(color='blue', size=8),
                        name='Volume Spike'
                    ),
                    row=1, col=1
                )
            elif signal_type == 'divergence':
                # Add divergence markers
                for div_type, div_signal in signal_data.items():
                    div_indices = data[div_signal].index
                    if div_type == 'bullish_divergence':
                        fig.add_trace(
                            go.Scatter(
                                x=div_indices,
                                y=data.loc[div_indices, 'low'] * 0.98,  # Slightly below low
                                mode='markers',
                                marker=dict(color='green', size=10, symbol='triangle-up'),
                                name='Bullish Divergence'
                            ),
                            row=1, col=1
                        )
                    elif div_type == 'bearish_divergence':
                        fig.add_trace(
                            go.Scatter(
                                x=div_indices,
                                y=data.loc[div_indices, 'high'] * 1.02,  # Slightly above high
                                mode='markers',
                                marker=dict(color='red', size=10, symbol='triangle-down'),
                                name='Bearish Divergence'
                            ),
                            row=1, col=1
                        )
            elif signal_type == 'rsi_divergence':
                # Add RSI divergence markers
                for div_type, div_signal in signal_data.items():
                    div_indices = data[div_signal].index
                    if div_type == 'rsi_bullish_divergence':
                        fig.add_trace(
                            go.Scatter(
                                x=div_indices,
                                y=data.loc[div_indices, 'low'] * 0.96,  # Slightly below low
                                mode='markers',
                                marker=dict(color='orange', size=10, symbol='triangle-up'),
                                name='RSI Bullish Divergence'
                            ),
                            row=1, col=1
                        )
                    elif div_type == 'rsi_bearish_divergence':
                        fig.add_trace(
                            go.Scatter(
                                x=div_indices,
                                y=data.loc[div_indices, 'high'] * 1.04,  # Slightly above high
                                mode='markers',
                                marker=dict(color='orange', size=10, symbol='triangle-down'),
                                name='RSI Bearish Divergence'
                            ),
                            row=1, col=1
                        )
            elif signal_type == 'bollinger_bands':
                # Add Bollinger Bands
                fig.add_trace(
                    go.Scatter(
                        x=data.index,
                        y=signal_data['upper_band'],
                        mode='lines',
                        name='Upper Band',
                        line=dict(color='rgba(0,0,0,0.2)')
                    ),
                    row=1, col=1
                )
                fig.add_trace(
                    go.Scatter(
                        x=data.index,
                        y=signal_data['middle_band'],
                        mode='lines',
                        name='Middle Band',
                        line=dict(color='rgba(0,0,0,0.5)')
                    ),
                    row=1, col=1
                )
                fig.add_trace(
                    go.Scatter(
                        x=data.index,
                        y=signal_data['lower_band'],
                        mode='lines',
                        name='Lower Band',
                        line=dict(color='rgba(0,0,0,0.2)'),
                        fill='tonexty'
                    ),
                    row=1, col=1
                )
            elif signal_type == 'macd':
                # Add MACD
                fig.add_trace(
                    go.Scatter(
                        x=data.index,
                        y=signal_data['macd_line'],
                        mode='lines',
                        name='MACD Line',
                        line=dict(color='blue')
                    ),
                    row=2, col=1
                )
                fig.add_trace(
                    go.Scatter(
                        x=data.index,
                        y=signal_data['signal_line'],
                        mode='lines',
                        name='Signal Line',
                        line=dict(color='red')
                    ),
                    row=2, col=1
                )
                fig.add_trace(
                    go.Bar(
                        x=data.index,
                        y=signal_data['histogram'],
                        name='MACD Histogram',
                        marker_color='gray'
                    ),
                    row=2, col=1
                )
    
    # Update layout
    fig.update_layout(
        title="Stock Price and Signals",
        yaxis_title="Price",
        yaxis2_title="Volume",
        yaxis3_title="RSI",
        xaxis_rangeslider_visible=False,
        height=1000
    )
    
    return fig