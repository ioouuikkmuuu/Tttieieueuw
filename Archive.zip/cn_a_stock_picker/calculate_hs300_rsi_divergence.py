"""
脚本用于计算沪深300成分股的RSI价格底背离信号
"""

import pandas as pd
import tushare as ts
import os
from dotenv import load_dotenv
from datetime import datetime, timedelta

# 导入项目模块
from signals.calculator import calculate_all_signals
from data.stock_data import get_stock_universe

# 加载环境变量
load_dotenv()

# 设置Tushare API令牌
ts.set_token(os.getenv('TUSHARE_TOKEN'))
pro = ts.pro_api()


def calculate_hs300_rsi_divergence():
    """
    计算沪深300成分股的RSI底背离信号
    """
    print("正在获取沪深300成分股数据...")
    
    # 获取沪深300成分股
    stock_data = get_stock_universe(['HS300'])
    hs300_data = stock_data.get('HS300', {})
    
    if not hs300_data:
        print("未能获取到沪深300成分股数据")
        return
    
    print(f"成功获取到 {len(hs300_data)} 只沪深300成分股数据")
    
    # 存储所有股票的RSI底背离信号
    all_divergence_signals = []
    
    # 遍历每只股票
    for stock_code, df in hs300_data.items():
        try:
            print(f"正在分析 {stock_code}...")
            
            # 确保数据按日期排序
            df = df.sort_index()
            
            # 检查是否有足够的数据进行RSI计算
            if len(df) < 30:  # 至少需要30天数据
                print(f"  {stock_code} 数据量不足，跳过分析")
                continue
            
            # 计算所有信号
            signals = calculate_all_signals(df)
            
            # 提取RSI底背离信号
            if 'rsi_divergence' in signals:
                rsi_divergence = signals['rsi_divergence']
                # 提取牛市背离信号（底背离）
                bullish_divergence = rsi_divergence['rsi_bullish_divergence']
                
                # 查找出现底背离的日期
                divergence_dates = bullish_divergence[bullish_divergence].index.tolist()
                
                if divergence_dates:
                    print(f"  发现 {len(divergence_dates)} 次RSI底背离信号")
                    for date in divergence_dates:
                        # 获取该日期的价格和RSI值
                        price = df.loc[date, 'close']
                        rsi_value = signals['rsi'].loc[date]
                        
                        # 添加到结果列表
                        all_divergence_signals.append({
                            'stock_code': stock_code,
                            'date': date.strftime('%Y-%m-%d'),
                            'close_price': price,
                            'rsi_value': rsi_value
                        })
                else:
                    print(f"  未发现RSI底背离信号")
            else:
                print(f"  未找到RSI背离信号")
        except Exception as e:
            print(f"  分析 {stock_code} 时出错: {e}")
    
    if all_divergence_signals:
        # 保存结果到CSV文件
        result_df = pd.DataFrame(all_divergence_signals)
        filename = f"hs300_rsi_bullish_divergence_{datetime.now().strftime('%Y%m%d')}.csv"
        result_df.to_csv(filename, index=False)
        print(f"\n总共发现 {len(all_divergence_signals)} 次RSI底背离信号")
        print(f"结果已保存到 {filename}")
        
        # 显示前几行结果
        print("\n前5行结果:")
        print(result_df.head())
    else:
        print("\n未发现任何RSI底背离信号")


def main():
    calculate_hs300_rsi_divergence()


if __name__ == "__main__":
    main()