"""
Module for validating stocks by opening web pages
"""

import webbrowser
import pandas as pd


def open_stock_page(stock_code, platform='eastmoney'):
    """
    Open a web page for stock validation
    
    Parameters:
    stock_code (str): Stock ticker code
    platform (str): Platform to open (eastmoney, sina, tencent, etc.)
    """
    # Convert stock code format if needed
    # Tushare uses format like 000001.SZ, but websites may use different formats
    if '.' in stock_code:
        parts = stock_code.split('.')
        base_code = parts[0]
        market = parts[1]
        
        # Convert to format used by Chinese websites
        if market == 'SZ':
            # Shenzhen stock
            url_code = f"sz{base_code}"
        elif market == 'SH':
            # Shanghai stock
            url_code = f"sh{base_code}"
        else:
            url_code = stock_code
    else:
        url_code = stock_code
    
    # Open appropriate web page based on platform
    if platform == 'eastmoney':
        url = f"https://quote.eastmoney.com/{url_code}.html"
    elif platform == 'sina':
        url = f"https://finance.sina.com.cn/realstock/company/{url_code}/nc.shtml"
    elif platform == 'tencent':
        url = f"https://gu.qq.com/{url_code}"
    else:
        # Default to Eastmoney
        url = f"https://quote.eastmoney.com/{url_code}.html"
    
    # Open web browser
    webbrowser.open(url)
    print(f"Opened {platform} page for {stock_code}")


def batch_open_stock_pages(stock_list, platform='eastmoney'):
    """
    Open web pages for a list of stocks
    
    Parameters:
    stock_list (list): List of stock ticker codes
    platform (str): Platform to open (eastmoney, sina, tencent, etc.)
    """
    for stock in stock_list:
        open_stock_page(stock, platform)