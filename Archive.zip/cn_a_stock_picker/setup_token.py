"""
Script to help users set up their Tushare token
"""

import os
from dotenv import load_dotenv, set_key


def setup_token():
    """
    Help user set up their Tushare token
    """
    print("Tushare Token Setup")
    print("==================")
    print("\nTo use this application, you need a Tushare API token.")
    print("1. Register at https://tushare.pro/")
    print("2. Get your free token from the website")
    print("3. Enter your token below\n")
    
    token = input("Enter your Tushare token: ").strip()
    
    if token:
        # Update .env file
        dotenv_path = os.path.join(os.path.dirname(__file__), '.env')
        set_key(dotenv_path, 'TUSHARE_TOKEN', token)
        print("\nToken has been saved to .env file successfully!")
        print("You can now run the application.")
    else:
        print("\nNo token entered. Please run this script again with a valid token.")


def main():
    setup_token()


if __name__ == "__main__":
    main()