"""
Module for annotating stock signals
"""

import pandas as pd
from datetime import datetime
from data.stock_data import get_stock_industry_info


def annotate_signals(signals, stock_data, universe_name):
    """
    Annotate stocks with signals and save relevant information
    
    Parameters:
    signals (dict): Dictionary with stock codes as keys and signal information as values
    stock_data (dict): Dictionary with stock data
    universe_name (str): Name of the stock universe
    
    Returns:
    pd.DataFrame: DataFrame with annotated signals and relevant information
    """
    # Get list of stocks with signals
    stocks_with_signals = list(signals.keys())
    
    # Get industry information for stocks with signals
    industry_info = get_stock_industry_info(stocks_with_signals)
    
    # Create DataFrame for annotated signals
    annotated_data = []
    
    for stock in stocks_with_signals:
        # Get signal information
        stock_signals = signals[stock]
        
        # Get industry information
        stock_industry = industry_info.get(stock, {})
        
        # Get latest stock data
        if stock in stock_data.get(universe_name, {}):
            latest_data = stock_data[universe_name][stock].iloc[-1] if not stock_data[universe_name][stock].empty else {}
        else:
            latest_data = {}
        
        # Create annotated record
        record = {
            'stock_code': stock,
            'universe': universe_name,
            'date': datetime.now().strftime('%Y-%m-%d'),
            'industry': stock_industry.get('industry', 'Unknown'),
            'market_cap_rank': stock_industry.get('market_cap_rank', 'Unknown'),
            'list_date': stock_industry.get('list_date', 'Unknown')
        }
        
        # Add signal information
        record.update(stock_signals)
        
        # Add latest stock data
        if isinstance(latest_data, pd.Series):
            record['close_price'] = latest_data.get('close', 'Unknown')
            record['volume'] = latest_data.get('vol', 'Unknown')
        
        annotated_data.append(record)
    
    # Convert to DataFrame
    annotated_df = pd.DataFrame(annotated_data)
    
    # Save to CSV file
    filename = f"annotated_signals_{universe_name}_{datetime.now().strftime('%Y%m%d')}.csv"
    annotated_df.to_csv(filename, index=False)
    print(f"Annotated signals saved to {filename}")
    
    return annotated_df