"""
Module for calculating future returns
"""

import tushare as ts
from datetime import datetime, timedelta
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Set your Tushare API token here
# You can get a free token by registering at https://tushare.pro/
ts.set_token(os.getenv('TUSHARE_TOKEN'))
pro = ts.pro_api()


def calculate_future_returns(stock_list, days=5):
    """
    Calculate future returns for a list of stocks
    
    Parameters:
    stock_list (list): List of stock tickers
    days (int): Number of days to calculate returns for
    
    Returns:
    dict: Dictionary with stock codes as keys and return information as values
    """
    returns_data = {}
    
    # Calculate future date
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    
    # Format dates for tushare
    end_date_str = end_date.strftime('%Y%m%d')
    start_date_str = start_date.strftime('%Y%m%d')
    
    for stock in stock_list:
        try:
            # Get historical data for the stock
            df = ts.pro_bar(ts_code=stock, adj='qfq', start_date=start_date_str, end_date=end_date_str)
            
            if df is not None and len(df) >= 2:
                # Calculate return
                initial_price = df.iloc[-1]['close']  # First row is most recent
                final_price = df.iloc[0]['close']     # Last row is oldest
                return_pct = (final_price - initial_price) / initial_price * 100
                
                returns_data[stock] = {
                    'initial_price': initial_price,
                    'final_price': final_price,
                    'return_pct': return_pct,
                    'period_days': days
                }
            else:
                returns_data[stock] = {
                    'error': 'Insufficient data'
                }
        except Exception as e:
            returns_data[stock] = {
                'error': str(e)
            }
    
    return returns_data