"""
Module for calculating trading signals
"""

import pandas as pd
import numpy as np


def calculate_rsi(data, window=14):
    """
    Calculate Relative Strength Index (RSI)
    
    Parameters:
    data (pd.DataFrame): Stock price data with 'close' column
    window (int): RSI window period
    
    Returns:
    pd.Series: RSI values
    """


def calculate_moving_averages(data, windows=[5, 20, 60]):
    """
    Calculate moving averages for stock data
    
    Parameters:
    data (pd.DataFrame): Stock price data
    windows (list): List of window sizes for moving averages
    
    Returns:
    dict: Dictionary with moving average data
    """
    ma_data = {}
    for window in windows:
        ma_data[f'MA_{window}'] = data['close'].rolling(window=window).mean()
    
    return ma_data


def calculate_rsi(data, window=14):
    """
    Calculate Relative Strength Index (RSI)
    
    Parameters:
    data (pd.DataFrame): Stock price data with 'close' column
    window (int): RSI window period
    
    Returns:
    pd.Series: RSI values
    """
    delta = data['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    
    return rsi


def calculate_macd(data, fast=12, slow=26, signal=9):
    """
    Calculate Moving Average Convergence Divergence (MACD)
    
    Parameters:
    data (pd.DataFrame): Stock price data with 'close' column
    fast (int): Fast EMA period
    slow (int): Slow EMA period
    signal (int): Signal line EMA period
    
    Returns:
    dict: Dictionary with MACD line, signal line, and histogram
    """
    exp1 = data['close'].ewm(span=fast).mean()
    exp2 = data['close'].ewm(span=slow).mean()
    macd = exp1 - exp2
    macd_signal = macd.ewm(span=signal).mean()
    macd_histogram = macd - macd_signal
    
    return {
        'macd_line': macd,
        'signal_line': macd_signal,
        'histogram': macd_histogram
    }


def calculate_bollinger_bands(data, window=20, num_std=2):
    """
    Calculate Bollinger Bands
    
    Parameters:
    data (pd.DataFrame): Stock price data with 'close' column
    window (int): Moving average window
    num_std (int): Number of standard deviations for bands
    
    Returns:
    dict: Dictionary with upper band, middle band, and lower band
    """
    middle_band = data['close'].rolling(window=window).mean()
    std_dev = data['close'].rolling(window=window).std()
    upper_band = middle_band + (std_dev * num_std)
    lower_band = middle_band - (std_dev * num_std)
    
    return {
        'upper_band': upper_band,
        'middle_band': middle_band,
        'lower_band': lower_band
    }


def detect_rsi_divergence(data, rsi, period=30):
    """
    Detect RSI divergence (price and RSI moving in opposite directions)
    
    Parameters:
    data (pd.DataFrame): Stock price data with 'close' column
    rsi (pd.Series): RSI values
    period (int): Period to check for divergence
    
    Returns:
    dict: Dictionary with bullish and bearish RSI divergence signals
    """
    # Calculate price changes
    price_change = data['close'].pct_change(period)
    rsi_change = rsi.pct_change(period)
    
    # Detect bullish divergence (price down, RSI up)
    bullish_div = (price_change < 0) & (rsi_change > 0)
    
    # Detect bearish divergence (price up, RSI down)
    bearish_div = (price_change > 0) & (rsi_change < 0)
    
    return {
        'rsi_bullish_divergence': bullish_div,
        'rsi_bearish_divergence': bearish_div
    }


def calculate_volume_signals(data, volume_multiplier=2):
    """
    Calculate volume signals (e.g., volume spikes)
    
    Parameters:
    data (pd.DataFrame): Stock data with volume information
    volume_multiplier (float): Multiplier to determine significant volume increase
    
    Returns:
    pd.Series: Boolean series indicating volume spikes
    """
    avg_volume = data['vol'].rolling(window=20).mean()
    volume_spikes = data['vol'] > (avg_volume * volume_multiplier)
    
    return volume_spikes


def detect_divergence(data, period=30):
    """
    Detect price-volume divergence (top and bottom)
    
    Parameters:
    data (pd.DataFrame): Stock data with price and volume information
    period (int): Period to check for divergence
    
    Returns:
    dict: Dictionary with divergence signals
    """
    # Calculate price and volume changes
    price_change = data['close'].pct_change(period)
    volume_change = data['vol'].pct_change(period)
    
    # Detect bullish divergence (price down, volume up)
    bullish_div = (price_change < 0) & (volume_change > 0)
    
    # Detect bearish divergence (price up, volume down)
    bearish_div = (price_change > 0) & (volume_change < 0)
    
    return {
        'bullish_divergence': bullish_div,
        'bearish_divergence': bearish_div
    }


def calculate_all_signals(data):
    """
    Calculate all signals for a stock
    
    Parameters:
    data (pd.DataFrame): Stock data
    
    Returns:
    dict: Dictionary with all calculated signals
    """
    signals = {}
    
    # Calculate moving averages
    signals['moving_averages'] = calculate_moving_averages(data)
    
    # Calculate RSI
    signals['rsi'] = calculate_rsi(data)
    
    # Calculate MACD
    signals['macd'] = calculate_macd(data)
    
    # Calculate Bollinger Bands
    signals['bollinger_bands'] = calculate_bollinger_bands(data)
    
    # Calculate volume signals
    signals['volume_spikes'] = calculate_volume_signals(data)
    
    # Detect divergence
    signals['divergence'] = detect_divergence(data)
    
    # Detect RSI divergence
    signals['rsi_divergence'] = detect_rsi_divergence(data, signals['rsi'])
    
    return signals