"""
Main application for Chinese A-stock picker
"""

import streamlit as st
import pandas as pd
from datetime import datetime, timedelta

# Set page config
st.set_page_config(page_title="Chinese A-Stock Picker", layout="wide")

# Import modules
try:
    from data.stock_data import get_stock_universe, get_stock_industry_info
    from signals.calculator import calculate_all_signals
    from signals.annotator import annotate_signals
    from signals.returns import calculate_future_returns
    from visualization.chart import create_candlestick_chart
    from utils.validator import open_stock_page
    MODULES_AVAILABLE = True
except ImportError as e:
    st.error(f"Error importing modules: {e}")
    MODULES_AVAILABLE = False


def main():
    st.title("Chinese A-Stock Picker")
    st.write("Welcome to the Chinese A-Stock Picker application.")
    
    if not MODULES_AVAILABLE:
        st.warning("Some modules are not available. Please check your installation.")
        return
    
    # 1. Stock universe selection
    st.sidebar.header("Stock Universe Selection")
    universes = st.sidebar.multiselect(
        "Select stock universes:",
        ['A50', 'HS300', 'CSI500', 'CSI800'],
        default=['HS300']
    )
    
    # Date selection
    default_date = datetime.now()
    selected_date = st.sidebar.date_input("Select date:", default_date)
    
    # 2. Get stock data for selected universe and date
    if st.sidebar.button("Get Stock Data"):
        with st.spinner("Fetching stock data..."):
            try:
                stock_data = get_stock_universe(universes, selected_date.strftime('%Y-%m-%d'))
                
                # Store in session state
                st.session_state.stock_data = stock_data
                st.session_state.selected_date = selected_date
                
                st.success("Stock data retrieved successfully!")
            except Exception as e:
                st.error(f"Error fetching stock data: {e}")
    
    # Display stock data if available
    if 'stock_data' in st.session_state:
        stock_data = st.session_state.stock_data
        
        # 3. Calculate signals for each universe
        st.header("Signal Calculation")
        if st.button("Calculate Signals"):
            with st.spinner("Calculating signals..."):
                try:
                    all_signals = {}
                    
                    for universe, stocks in stock_data.items():
                        st.subheader(f"Signals for {universe}")
                        universe_signals = {}
                        
                        for stock, data in stocks.items():
                            if not data.empty:
                                signals = calculate_all_signals(data)
                                universe_signals[stock] = signals
                                
                                # Display some signal information
                                st.write(f"{stock}: MA Signals - {len(signals.get('moving_averages', {}))}, "
                                       f"Volume Spikes - {signals.get('volume_spikes', pd.Series()).sum()}")
                        
                        all_signals[universe] = universe_signals
                    
                    # Store signals in session state
                    st.session_state.signals = all_signals
                    st.success("Signals calculated successfully!")
                except Exception as e:
                    st.error(f"Error calculating signals: {e}")
        
        # 4. Annotate signals
        if 'signals' in st.session_state:
            signals = st.session_state.signals
            
            st.header("Signal Annotation")
            if st.button("Annotate Signals"):
                with st.spinner("Annotating signals..."):
                    try:
                        for universe, universe_signals in signals.items():
                            annotated_df = annotate_signals(universe_signals, stock_data, universe)
                            st.subheader(f"Annotated Signals for {universe}")
                            st.dataframe(annotated_df)
                    except Exception as e:
                        st.error(f"Error annotating signals: {e}")
                    
                    st.success("Signals annotated successfully!")
        
        # 5. Visualization
        st.header("Visualization")
        # Select a stock for visualization
        all_stocks = []
        for universe, stocks in stock_data.items():
            all_stocks.extend(list(stocks.keys()))
        
        selected_stock = st.selectbox("Select a stock for visualization:", all_stocks)
        
        # Find which universe the selected stock belongs to
        selected_universe = None
        for universe, stocks in stock_data.items():
            if selected_stock in stocks:
                selected_universe = universe
                break
        
        if selected_stock and selected_universe:
            stock_df = stock_data[selected_universe][selected_stock]
            stock_signals = st.session_state.signals[selected_universe][selected_stock] if 'signals' in st.session_state else None
            
            if st.button("Generate Chart"):
                with st.spinner("Generating chart..."):
                    try:
                        fig = create_candlestick_chart(stock_df, stock_signals)
                        st.plotly_chart(fig, use_container_width=True)
                    except Exception as e:
                        st.error(f"Error generating chart: {e}")
        
        # 6. Future returns calculation
        st.header("Future Returns Calculation")
        if st.button("Calculate Future Returns"):
            with st.spinner("Calculating future returns..."):
                try:
                    returns_data = calculate_future_returns(all_stocks)
                    returns_df = pd.DataFrame.from_dict(returns_data, orient='index')
                    st.dataframe(returns_df)
                    
                    # Store in session state
                    st.session_state.returns_data = returns_data
                    st.success("Future returns calculated successfully!")
                except Exception as e:
                    st.error(f"Error calculating future returns: {e}")
        
        # 7. Web validation
        st.header("Web Validation")
        if st.button("Open Stock Pages"):
            with st.spinner("Opening stock pages..."):
                try:
                    # Open pages for first 3 stocks as example
                    for i, stock in enumerate(all_stocks[:3]):
                        open_stock_page(stock)
                    st.success("Stock pages opened in browser!")
                except Exception as e:
                    st.error(f"Error opening stock pages: {e}")


if __name__ == "__main__":
    main()