"""
脚本用于计算指定股票的RSI价格底背离信号
"""

import pandas as pd
import tushare as ts
import os
from dotenv import load_dotenv
from datetime import datetime, timedelta

# 导入项目模块
from signals.calculator import calculate_rsi, detect_rsi_divergence

# 加载环境变量
load_dotenv()

# 设置Tushare API令牌
ts.set_token(os.getenv('TUSHARE_TOKEN'))
pro = ts.pro_api()


def get_historical_data(stock_code, start_date, end_date):
    """
    获取股票历史数据
    
    参数:
    stock_code (str): 股票代码
    start_date (str): 开始日期 (YYYY-MM-DD)
    end_date (str): 结束日期 (YYYY-MM-DD)
    
    返回:
    pd.DataFrame: 股票历史数据
    """
    try:
        # 获取股票数据
        df = ts.pro_bar(ts_code=stock_code, adj='qfq', start_date=start_date.replace('-', ''), end_date=end_date.replace('-', ''))
        
        if df is not None and not df.empty:
            # 设置日期为索引
            df['trade_date'] = pd.to_datetime(df['trade_date'])
            df.set_index('trade_date', inplace=True)
            df.sort_index(inplace=True)
            return df
        else:
            print(f"未能获取到 {stock_code} 的数据")
            return pd.DataFrame()
    except Exception as e:
        print(f"获取 {stock_code} 数据时出错: {e}")
        return pd.DataFrame()


def detect_historical_rsi_divergence(stock_code, start_date, end_date):
    """
    检测股票历史RSI底背离信号
    
    参数:
    stock_code (str): 股票代码
    start_date (str): 开始日期 (YYYY-MM-DD)
    end_date (str): 结束日期 (YYYY-MM-DD)
    """
    print(f"正在分析 {stock_code} 从 {start_date} 到 {end_date} 的RSI底背离信号...")
    
    # 获取历史数据
    df = get_historical_data(stock_code, start_date, end_date)
    
    if df.empty:
        print("未能获取到股票数据，无法进行分析")
        return
    
    print(f"成功获取到 {len(df)} 天的数据")
    
    # 检查是否有足够的数据进行RSI计算
    if len(df) < 30:  # 至少需要30天数据
        print("数据量不足，至少需要30天数据进行RSI背离分析")
        return
    
    # 计算RSI
    rsi = calculate_rsi(df)
    
    # 检测RSI背离
    divergence_signals = detect_rsi_divergence(df, rsi, period=30)
    
    # 提取牛市背离信号（底背离）
    bullish_divergence = divergence_signals['rsi_bullish_divergence']
    
    # 查找出现底背离的日期
    divergence_dates = bullish_divergence[bullish_divergence].index.tolist()
    
    if divergence_dates:
        print(f"\n发现 {len(divergence_dates)} 次RSI底背离信号:")
        for date in divergence_dates:
            # 获取该日期的价格和RSI值
            price = df.loc[date, 'close']
            rsi_value = rsi.loc[date]
            print(f"  - 日期: {date.strftime('%Y-%m-%d')}, 收盘价: {price:.2f}, RSI: {rsi_value:.2f}")
        
        # 保存结果到CSV文件
        result_df = pd.DataFrame({
            'stock_code': [stock_code] * len(divergence_dates),
            'date': [d.strftime('%Y-%m-%d') for d in divergence_dates],
            'close_price': [df.loc[d, 'close'] for d in divergence_dates],
            'rsi_value': [rsi.loc[d] for d in divergence_dates]
        })
        
        filename = f"{stock_code}_rsi_bullish_divergence_{start_date}_to_{end_date}.csv"
        result_df.to_csv(filename, index=False)
        print(f"\n结果已保存到 {filename}")
    else:
        print("\n未发现RSI底背离信号")


def main():
    # 寒武纪股票代码
    stock_code = "688256.SH"  # 寒武纪科创板代码
    
    # 设置分析时间范围（最近2年）
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=730)).strftime('%Y-%m-%d')
    
    # 检测历史RSI底背离信号
    detect_historical_rsi_divergence(stock_code, start_date, end_date)


if __name__ == "__main__":
    main()