"""
Module for retrieving stock data
"""

import tushare as ts
import pandas as pd
from datetime import datetime, timedelta
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Set your Tushare API token here
# You can get a free token by registering at https://tushare.pro/
ts.set_token(os.getenv('TUSHARE_TOKEN'))
pro = ts.pro_api()


def get_stock_universe(universe, date=None):
    """
    Get stock universe data for a specific date
    
    Parameters:
    universe (list): List of stock universes to retrieve (e.g., ['A50', 'HS300', 'CSI500', 'CSI800'])
    date (str): Date in YYYY-MM-DD format. If None, use current date.
    
    Returns:
    dict: Dictionary with universe names as keys and stock data as values
    """
    if date is None:
        date = datetime.now().strftime('%Y%m%d')
    else:
        # Convert date format for tushare
        date_obj = datetime.strptime(date, '%Y-%m-%d')
        date = date_obj.strftime('%Y%m%d')
    
    stock_data = {}
    for uni in universe:
        try:
            if uni == 'HS300':
                # Get HS300 constituents from tushare
                df = pro.index_member(index_ts_code='000300.SH')
                if df is not None and not df.empty:
                    stocks = df['con_code'].tolist()
                    # Limit to 10 stocks for testing purposes
                    stocks = stocks[:10] if len(stocks) > 10 else stocks
                else:
                    # Fallback to sample stocks if no data retrieved
                    stocks = ['000300.SZ', '000004.SZ', '000005.SZ']
                    print("Using sample stocks for HS300")
            else:
                # For other universes, use sample stocks
                sample_stocks = {
                    'A50': ['000001.SZ', '000002.SZ', '000003.SZ'],
                    'CSI500': ['000905.SZ', '000006.SZ', '000007.SZ'],
                    'CSI800': ['000906.SZ', '000008.SZ', '000009.SZ']
                }
                stocks = sample_stocks.get(uni, [])
            
            data = {}
            for stock in stocks:
                try:
                    # Get stock data from tushare
                    # Get 6 months of data for RSI divergence analysis
                    end_date = date
                    start_date_obj = datetime.strptime(date, '%Y%m%d') - timedelta(days=180)
                    start_date = start_date_obj.strftime('%Y%m%d')
                    df = ts.pro_bar(ts_code=stock, adj='qfq', start_date=start_date, end_date=end_date)
                    if df is not None and not df.empty:
                        # Sort by date
                        df['trade_date'] = pd.to_datetime(df['trade_date'])
                        df.set_index('trade_date', inplace=True)
                        df.sort_index(inplace=True)
                        data[stock] = df
                    else:
                        print(f"No data retrieved for {stock}")
                except Exception as e:
                    print(f"Error retrieving data for {stock}: {e}")
            stock_data[uni] = data
        except Exception as e:
            print(f"Error retrieving {uni} universe: {e}")
            stock_data[uni] = {}
    
    return stock_data


def get_stock_industry_info(stock_list):
    """
    Get industry information for a list of stocks
    
    Parameters:
    stock_list (list): List of stock tickers
    
    Returns:
    dict: Dictionary with stock tickers as keys and industry information as values
    """
    industry_info = {}
    
    # Get industry information for all stocks
    for stock in stock_list:
        try:
            # Get stock information from tushare
            df = pro.stock_basic(ts_code=stock, fields='ts_code,name,industry,list_date')
            if df is not None and not df.empty:
                industry_info[stock] = {
                    'industry': df.iloc[0]['industry'],
                    'list_date': df.iloc[0]['list_date']
                }
            else:
                industry_info[stock] = {
                    'industry': 'Unknown',
                    'list_date': 'Unknown'
                }
                print(f"No industry information found for {stock}")
        except Exception as e:
            industry_info[stock] = {
                'industry': 'Error',
                'list_date': 'Error'
            }
            print(f"Error retrieving industry information for {stock}: {e}")
    
    # Get market capitalization data to determine rankings
    try:
        # Get market cap data for all stocks
        market_cap_data = {}
        for stock in stock_list:
            df = pro.daily_basic(ts_code=stock, fields='ts_code,market_cap')
            if df is not None and not df.empty:
                market_cap_data[stock] = df.iloc[0]['market_cap']
            else:
                market_cap_data[stock] = 0
        
        # Sort stocks by market cap to determine rankings
        sorted_stocks = sorted(market_cap_data.items(), key=lambda x: x[1], reverse=True)
        
        # Add market cap rankings to industry_info
        for rank, (stock, market_cap) in enumerate(sorted_stocks, 1):
            if stock in industry_info:
                industry_info[stock]['market_cap_rank'] = rank
            else:
                industry_info[stock] = {'market_cap_rank': rank}
    except Exception as e:
        print(f"Error retrieving market cap data: {e}")
        # Fallback to placeholder rankings
        for i, stock in enumerate(stock_list, 1):
            if stock in industry_info:
                industry_info[stock]['market_cap_rank'] = i
            else:
                industry_info[stock] = {'market_cap_rank': i}
    
    return industry_info