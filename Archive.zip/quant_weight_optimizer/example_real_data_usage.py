"""
使用真实数据运行量化权重优化器的示例脚本
"""

import pandas as pd
from main import main


def run_with_real_data():
    """
    使用真实数据运行模型
    """
    print("使用真实数据运行量化权重优化器...")
    
    # 使用真实数据运行主程序
    # 请确保已通过tushare_data_fetcher.py获取了真实数据并保存为real_stock_data.csv
    main(use_real_data=True, real_data_path="real_stock_data.csv")


def check_data_format():
    """
    检查数据格式是否正确
    """
    try:
        # 尝试读取数据
        data = pd.read_csv("real_stock_data.csv")
        
        # 检查必要的列
        required_columns = ['date', 'stock_code', 'close_price']
        missing_columns = set(required_columns) - set(data.columns)
        
        if missing_columns:
            print(f"数据缺少以下必要列: {missing_columns}")
            return False
        
        # 检查数据类型
        if not pd.api.types.is_datetime64_any_dtype(data['date']):
            print("日期列格式不正确")
            return False
        
        print("数据格式检查通过")
        print(f"数据形状: {data.shape}")
        print("前5行数据:")
        print(data.head())
        
        return True
    except Exception as e:
        print(f"检查数据格式时出错: {e}")
        return False


def main_example():
    """
    主函数示例
    """
    # 首先检查数据格式
    if check_data_format():
        # 运行模型
        run_with_real_data()
    else:
        print("数据格式不正确，请确保已正确获取并保存了真实数据")


if __name__ == "__main__":
    main_example()