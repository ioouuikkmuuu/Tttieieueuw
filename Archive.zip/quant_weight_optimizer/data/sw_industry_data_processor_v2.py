"""
申万行业数据处理器 v2
用于处理从Excel转换而来的申万各行业daily return时序数据
"""

import pandas as pd
import numpy as np
from typing import Optional
import os


def load_sw_industry_data_v2(filepath: str) -> pd.DataFrame:
    """
    加载从Excel转换而来的申万行业daily return数据
    
    数据格式要求：
    - 第一列为日期列
    - 其余列为各行业的收益率
    
    Parameters:
    filepath (str): 数据文件路径
    
    Returns:
    pd.DataFrame: 包含申万行业收益率数据的DataFrame
    """
    # 检查文件是否存在
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"数据文件 {filepath} 不存在")
    
    # 读取CSV文件
    data = pd.read_csv(filepath)
    
    # 获取日期列
    date_column = data.columns[0]
    
    # 转换日期列格式
    data[date_column] = pd.to_datetime(data[date_column])
    
    # 重塑数据格式，将宽格式转换为长格式
    # 获取所有行业列名
    industry_columns = data.columns[1:]
    
    # 创建行业代码映射
    industry_mapping = {name: f"IND{i:03d}" for i, name in enumerate(industry_columns, 1)}
    
    # 转换为长格式
    melted_data = pd.melt(
        data, 
        id_vars=[date_column], 
        value_vars=industry_columns,
        var_name='industry_name',
        value_name='return'
    )
    
    # 重命名日期列
    melted_data = melted_data.rename(columns={date_column: 'date'})
    
    # 添加行业代码
    melted_data['industry_code'] = melted_data['industry_name'].map(industry_mapping)
    
    # 重命名行业代码列为stock_code以匹配项目需求
    melted_data = melted_data.rename(columns={'industry_code': 'stock_code'})
    
    # 添加close_price列（通过累积收益率计算）
    # 假设初始价格为100
    melted_data = melted_data.sort_values(['stock_code', 'date']).reset_index(drop=True)
    melted_data['close_price'] = melted_data.groupby('stock_code')['return'].apply(
        lambda x: 100 * (1 + x).cumprod()
    ).reset_index(drop=True)
    
    # 按日期和行业代码排序
    melted_data = melted_data.sort_values(['stock_code', 'date']).reset_index(drop=True)
    
    return melted_data[['date', 'stock_code', 'close_price', 'return']]


def convert_sw_data_for_model_v2(filepath: str, output_path: Optional[str] = None) -> pd.DataFrame:
    """
    转换申万行业数据以适配动量因子模型
    
    Parameters:
    filepath (str): 原始申万行业数据文件路径
    output_path (Optional[str]): 转换后数据保存路径
    
    Returns:
    pd.DataFrame: 转换后的数据
    """
    # 加载数据
    data = load_sw_industry_data_v2(filepath)
    
    # 保存转换后的数据
    if output_path:
        data.to_csv(output_path, index=False)
        print(f"转换后的数据已保存到 {output_path}")
    
    return data


def main():
    """
    主函数 - 示例用法
    """
    # 示例：转换申万行业数据
    try:
        # 使用实际数据文件
        converted_data = convert_sw_data_for_model_v2(
            'data/sw_industry_daily_returns.csv', 
            'converted_sw_industry_data_v2.csv'
        )
        print("数据转换完成")
        print(converted_data.head(10))
    except FileNotFoundError as e:
        print(f"未找到数据文件: {e}")
    except ValueError as e:
        print(f"数据格式错误: {e}")
    except Exception as e:
        print(f"处理数据时出错: {e}")


if __name__ == "__main__":
    main()