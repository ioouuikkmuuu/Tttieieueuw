"""
模拟数据生成器
用于生成股票价格数据以测试动量因子模型
"""

import numpy as np
import pandas as pd
from typing import Tuple


def generate_simulated_data(n_stocks: int = 100, n_days: int = 252) -> pd.DataFrame:
    """
    生成模拟的股票价格数据
    
    Parameters:
    n_stocks (int): 股票数量
    n_days (int): 交易日数量
    
    Returns:
    pd.DataFrame: 包含模拟股票价格数据的DataFrame
    """
    # 生成日期索引
    dates = pd.date_range(start='2020-01-01', periods=n_days, freq='D')
    
    # 生成股票代码
    stock_codes = [f'STOCK_{i:04d}' for i in range(n_stocks)]
    
    # 初始化价格数据
    prices = []
    
    # 为每只股票生成价格数据
    for stock in stock_codes:
        # 生成随机游走价格序列
        returns = np.random.normal(0.0005, 0.02, n_days)  # 日收益率
        price_series = [100]  # 初始价格设为100
        
        for ret in returns:
            price_series.append(price_series[-1] * (1 + ret))
        
        # 创建DataFrame
        stock_data = pd.DataFrame({
            'date': dates,
            'stock_code': stock,
            'close_price': price_series[1:]  # 去掉初始价格
        })
        
        prices.append(stock_data)
    
    # 合并所有股票数据
    all_data = pd.concat(prices, ignore_index=True)
    
    return all_data


def load_real_data(filepath: str) -> pd.DataFrame:
    """
    加载真实数据
    
    Parameters:
    filepath (str): 数据文件路径
    
    Returns:
    pd.DataFrame: 包含真实股票价格数据的DataFrame
    """
    # 读取CSV文件
    data = pd.read_csv(filepath)
    
    # 转换日期列格式
    data['date'] = pd.to_datetime(data['date'])
    
    # 按日期和股票代码排序
    data = data.sort_values(['stock_code', 'date']).reset_index(drop=True)
    
    return data


if __name__ == "__main__":
    # 测试生成模拟数据
    simulated_data = generate_simulated_data()
    print(simulated_data.head(10))