import pandas as pd
import numpy as np
import plotly.graph_objects as go
import argparse
from datetime import datetime, timedelta
from config import data_config, model_config, optimization_config, explanation_config
from data.data_generator import load_real_data
from factors.momentum_factors import calculate_momentum_factors
from model.predictor import MarketTrendPredictor
from optimization.hyperparameter_tuning import optimize_hyperparameters, update_model_with_optimal_params
from explanation.model_explanation import create_shap_explainer, calculate_shap_values

def plot_shap_time_series(shap_time_series, factor_names, title="SHAP值时间序列图"):
    """
    使用Plotly创建短中长期SHAP值随时间推移的变化图
    """
    fig = go.Figure()
    
    # 为每个因子创建时间序列线
    colors = ['blue', 'green', 'red']  # 短、中、长期因子的颜色
    for i, (factor_name, color) in enumerate(zip(factor_names, colors)):
        fig.add_trace(go.Scatter(
            x=shap_time_series['dates'],
            y=shap_time_series[factor_name],
            mode='lines+markers',
            name=factor_name,
            line=dict(color=color),
            marker=dict(size=6)
        ))
    
    # 更新布局
    fig.update_layout(
        title=title,
        xaxis_title='日期',
        yaxis_title='平均SHAP值',
        template='plotly_white',
        width=1000,
        height=600,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        )
    )
    
    # 显示图表
    fig.show()
    
    # 保存图表
    filename = title.replace(' ', '_').replace('===', '').strip() + '.html'
    fig.write_html(filename)
    print(f'图表已保存为 {filename}')

def calculate_shap_time_series(start_date_str='2023-02-03', end_date_str=None, interval_days=30):
    """
    计算并绘制短中长期SHAP值随时间推移的变化
    
    对于每个时间点：
    1. 使用历史数据训练模型
    2. 对新数据点进行预测
    3. 使用SHAP解释模型预测，拆解各因子的贡献度
    """
    # 加载申万行业数据
    print('加载申万行业数据...')
    raw_data = load_real_data('converted_sw_industry_data_v2.csv')
    print(f'加载了 {len(raw_data)} 条数据记录')
    
    # 确定日期范围
    start_date = pd.Timestamp(start_date_str)
    if end_date_str:
        end_date = pd.Timestamp(end_date_str)
    else:
        # 默认为数据中的最后一天
        end_date = raw_data['date'].max()
    
    # 检查数据范围
    min_date = raw_data['date'].min()
    max_date = raw_data['date'].max()
    print(f'数据范围: {min_date} 到 {max_date}')
    
    # 确保起始日期有足够的历史数据
    # 长期动量需要252天数据，我们使用280天以确保安全
    required_history = pd.Timedelta(days=280)
    adjusted_start_date = min_date + required_history
    
    # 如果用户指定的起始日期早于调整后的日期，则使用调整后的日期
    if start_date < adjusted_start_date:
        print(f'调整起始日期从 {start_date} 到 {adjusted_start_date} 以确保有足够的历史数据')
        start_date = adjusted_start_date
    
    # 过滤数据日期范围
    raw_data = raw_data[(raw_data['date'] >= start_date) & (raw_data['date'] <= end_date)]
    
    # 获取因子名称
    factor_descriptions = ['short_momentum', 'medium_momentum', 'long_momentum']
    
    # 存储时间序列数据
    shap_time_series = {
        'dates': [],
        'short_momentum': [],
        'medium_momentum': [],
        'long_momentum': []
    }
    
    # 按时间间隔计算SHAP值
    current_date = start_date
    while current_date <= end_date:
        print(f'\n处理日期: {current_date.strftime("%Y-%m-%d")}')
        
        # 确定当前窗口的数据范围（使用足够大的窗口来计算动量因子）
        # 长期动量窗口为252天，为了确保有足够的数据，我们使用300天的窗口
        window_start_date = current_date - pd.Timedelta(days=300)
        window_data = raw_data[(raw_data['date'] >= window_start_date) & (raw_data['date'] <= current_date)]
        
        # 检查是否有足够的数据
        # 我们需要至少252天的数据来计算长期动量因子
        if len(window_data) < 252:
            print(f'  跳过日期 {current_date.strftime("%Y-%m-%d")}，数据不足')
            current_date += pd.Timedelta(days=interval_days)
            continue
        
        # 计算动量因子
        print('  计算动量因子...')
        factor_data = calculate_momentum_factors(window_data, data_config)
        
        # 移除包含缺失值的行
        factor_data = factor_data.dropna(subset=factor_descriptions)
        
        # 检查是否有足够的数据
        if len(factor_data) == 0:
            print(f'  跳过日期 {current_date.strftime("%Y-%m-%d")}，计算动量因子后无有效数据')
            current_date += pd.Timedelta(days=interval_days)
            continue
        
        # 创建预测器
        predictor = MarketTrendPredictor(model_config)
        
        # 准备特征和目标变量
        features = predictor.prepare_features(factor_data)
        target = predictor.prepare_target(factor_data)
        
        # 移除目标变量中的缺失值
        # 使用dropna来同时处理features和target
        combined_data = pd.concat([features, target], axis=1)
        combined_data = combined_data.dropna()
        features = combined_data.iloc[:, :-1]  # All columns except the last one (target)
        target = combined_data.iloc[:, -1]     # The last column (target)
        
        # 检查是否有足够的数据
        if len(features) < 50 or len(target) < 50:  # 降低数据量要求
            print(f'  跳过日期 {current_date.strftime("%Y-%m-%d")}，特征或目标变量数据不足')
            current_date += pd.Timedelta(days=interval_days)
            continue
        
        # 超参数优化
        print('  进行超参数优化...')
        try:
            optimization_result = optimize_hyperparameters(
                features, 
                target, 
                optimization_config
            )
            
            # 使用最优参数更新模型
            update_model_with_optimal_params(predictor, optimization_result['best_params'])
            
            # 重新训练模型
            predictor.train(features, target)
            print('  模型训练完成')
            
            # 创建SHAP解释器
            explainer = create_shap_explainer(predictor, features)
            
            # 计算SHAP值
            print('  计算SHAP值...')
            shap_values = calculate_shap_values(explainer, features, explanation_config)
            
            # 计算平均SHAP值
            mean_shap_values = np.mean(np.abs(shap_values), axis=0)
            
            # 存储结果
            shap_time_series['dates'].append(current_date)
            for i, factor_name in enumerate(factor_descriptions):
                shap_time_series[factor_name].append(mean_shap_values[i])
                
            print(f'  完成日期 {current_date.strftime("%Y-%m-%d")} 的SHAP值计算')
        except Exception as e:
            print(f'  处理日期 {current_date.strftime("%Y-%m-%d")} 时出错: {e}')
        
        # 移动到下一个时间点
        current_date += pd.Timedelta(days=interval_days)
    
    # 检查是否有足够的数据点来绘制图表
    if len(shap_time_series['dates']) < 2:
        print('\n数据点不足，无法绘制时间序列图')
        return
    
    # 绘制时间序列图
    print('\n绘制SHAP值时间序列图...')
    plot_shap_time_series(shap_time_series, factor_descriptions, '短中长期SHAP值随时间推移的变化')

if __name__ == "__main__":
    # 解析命令行参数
    parser = argparse.ArgumentParser(description='绘制短中长期SHAP值随时间推移的变化图')
    parser.add_argument('--start_date', type=str, default='2024-01-01', help='起始日期 (格式: YYYY-MM-DD)')
    parser.add_argument('--end_date', type=str, default='2025-06-30', help='结束日期 (格式: YYYY-MM-DD)')
    parser.add_argument('--interval', type=int, default=15, help='计算间隔天数')
    args = parser.parse_args()
    
    calculate_shap_time_series(args.start_date, args.end_date, args.interval)