"""
tushare配置文件
"""

# 请在此处填写您的tushare token
# 1. 访问 https://tushare.pro/ 注册账号
# 2. 登录后在个人主页获取您的token
# 3. 将下方的 'your_real_tushare_token_here' 替换为您获取到的真实token
tushare_token = '2876ea85cb005fb5fa17c809a98174f2d5aae8b1f830110a5ead6211'