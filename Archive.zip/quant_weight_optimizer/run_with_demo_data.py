"""
使用演示数据运行项目
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os
import sys

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# 创建演示数据
def create_demo_data():
    """创建演示用的股票数据"""
    np.random.seed(42)
    
    # 生成日期范围
    start_date = datetime(2023, 1, 1)
    end_date = datetime(2023, 12, 31)
    dates = pd.date_range(start=start_date, end=end_date, freq='D')
    
    # 过滤工作日
    dates = dates[dates.weekday < 5]
    
    # 创建5只股票的演示数据
    stocks = ['000001.SZ', '000002.SZ', '000003.SZ', '000004.SZ', '000005.SZ']
    
    all_data = []
    for stock_code in stocks:
        # 为每只股票生成价格数据
        base_price = np.random.uniform(10, 50)
        returns = np.random.normal(0.001, 0.02, len(dates))
        prices = [base_price]
        
        for ret in returns[1:]:
            prices.append(prices[-1] * (1 + ret))
        
        # 创建DataFrame
        stock_data = pd.DataFrame({
            'date': dates,
            'stock_code': stock_code,
            'close_price': prices
        })
        
        all_data.append(stock_data)
    
    # 合并所有数据
    demo_data = pd.concat(all_data, ignore_index=True)
    return demo_data

if __name__ == "__main__":
    print("创建演示数据...")
    demo_data = create_demo_data()
    
    print(f"成功创建演示数据，共{len(demo_data)}条记录")
    print("数据预览:")
    print(demo_data.head(10))
    
    # 保存演示数据
    demo_data.to_csv('demo_stock_data.csv', index=False)
    print("演示数据已保存到 demo_stock_data.csv")
    
    # 显示数据统计
    print(f"\n数据统计:")
    print(f"股票数量: {demo_data['stock_code'].nunique()}")
    print(f"日期范围: {demo_data['date'].min()} 到 {demo_data['date'].max()}")
    print(f"平均价格: {demo_data['close_price'].mean():.2f}")