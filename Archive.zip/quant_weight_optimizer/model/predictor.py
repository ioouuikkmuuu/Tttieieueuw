"""
市场趋势预测模型
使用机器学习方法预测市场趋势变化
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from typing import Tuple, Any, Dict


class MarketTrendPredictor:
    """
    市场趋势预测器
    """
    
    def __init__(self, config: Dict = None):
        """初始化预测器
        
        Parameters:
        config (Dict): 模型配置参数
        """
        # 使用配置中的参数，如果未提供则使用默认值
        if config and 'rf_default_params' in config:
            rf_params = config['rf_default_params']
        else:
            rf_params = {'n_estimators': 100, 'random_state': 42}
        
        self.model = RandomForestRegressor(**rf_params)
        self.is_fitted = False
    
    def prepare_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        准备特征数据
        
        Parameters:
        data (pd.DataFrame): 包含动量因子的数据
        
        Returns:
        pd.DataFrame: 特征数据
        """
        # 选择特征列
        feature_columns = ['short_momentum', 'medium_momentum', 'long_momentum']
        features = data[feature_columns].copy()
        
        # 处理缺失值
        features = features.fillna(0)
        
        return features
    
    def prepare_target(self, data: pd.DataFrame) -> pd.Series:
        """
        准备目标变量（未来收益率）
        
        Parameters:
        data (pd.DataFrame): 包含价格数据的DataFrame
        
        Returns:
        pd.Series: 目标变量
        """
        # 计算未来5天的收益率作为目标变量
        data = data.sort_values(['stock_code', 'date']).reset_index(drop=True)
        data['future_return'] = data.groupby('stock_code')['close_price'].shift(-5).pct_change(5)
        
        return data['future_return']
    
    def train(self, features: pd.DataFrame, target: pd.Series) -> None:
        """
        训练模型
        
        Parameters:
        features (pd.DataFrame): 特征数据
        target (pd.Series): 目标变量
        """
        # 移除目标变量中的缺失值
        valid_indices = ~target.isna()
        features_clean = features[valid_indices]
        target_clean = target[valid_indices]
        
        # 训练模型
        self.model.fit(features_clean, target_clean)
        self.is_fitted = True
    
    def predict(self, features: pd.DataFrame) -> np.ndarray:
        """
        进行预测
        
        Parameters:
        features (pd.DataFrame): 特征数据
        
        Returns:
        np.ndarray: 预测结果
        """
        if not self.is_fitted:
            raise ValueError("模型尚未训练，请先调用train方法")
        
        return self.model.predict(features)
    
    def evaluate(self, features: pd.DataFrame, target: pd.Series) -> Dict[str, float]:
        """
        评估模型性能
        
        Parameters:
        features (pd.DataFrame): 特征数据
        target (pd.Series): 目标变量
        
        Returns:
        Dict[str, float]: 评估指标
        """
        # 移除目标变量中的缺失值
        valid_indices = ~target.isna()
        features_clean = features[valid_indices]
        target_clean = target[valid_indices]
        
        # 预测
        predictions = self.model.predict(features_clean)
        
        # 计算评估指标
        mse = mean_squared_error(target_clean, predictions)
        rmse = np.sqrt(mse)
        
        # 计算信息比率 (Information Ratio)
        residuals = target_clean - predictions
        ir = np.mean(residuals) / np.std(residuals) if np.std(residuals) != 0 else 0
        
        # 计算预测值的信息比率
        from evaluation.metrics import calculate_information_ratio
        pred_ir = calculate_information_ratio(pd.Series(predictions))
        
        return {
            'mse': mse,
            'rmse': rmse,
            'information_ratio': ir,
            'prediction_information_ratio': pred_ir
        }


if __name__ == "__main__":
    # 这里可以添加测试代码
    pass