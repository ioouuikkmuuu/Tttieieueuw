"""
检查tushare账户权限
"""

import tushare as ts
from tushare_config import tushare_token

# 设置tushare token
ts.set_token(tushare_token)
pro = ts.pro_api()

# 检查账户权限
print("正在检查账户权限...")
try:
    # 获取账户信息
    user_info = pro.user()
    print("账户信息：")
    print(user_info)
except Exception as e:
    print(f"获取账户信息时出错: {e}")

# 尝试获取需要积分的接口
print("\n尝试获取需要积分的接口...")
try:
    # 获取股票复权因子
    adj_factor = pro.adj_factor(ts_code='000001.SZ', trade_date='20200101')
    print(f"成功获取到{len(adj_factor)}条复权因子数据")
    print(adj_factor.head())
except Exception as e:
    print(f"获取复权因子时出错: {e}")