"""
测试tushare数据获取功能
"""

import tushare as ts
import pandas as pd
import sys
import os

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from tushare_config import tushare_token


def test_tushare():
    """
    测试tushare基本功能
    """
    # 从配置文件读取token
    token = tushare_token
    
    if token == 'your_real_tushare_token_here':
        print("请先在tushare_config.py文件中设置您的真实tushare token")
        return
    
    # 设置token
    ts.set_token(token)
    pro = ts.pro_api()
    
    # 测试获取股票列表
    print("正在获取股票列表...")
    stock_list = pro.stock_basic(exchange='', list_status='L', fields='ts_code,symbol,name')
    print(f"成功获取到{len(stock_list)}只股票")
    print(stock_list.head())
    
    # 测试获取单只股票数据
    if not stock_list.empty:
        ts_code = stock_list.iloc[0]['ts_code']
        print(f"\n正在获取股票{ts_code}的历史数据...")
        stock_data = pro.daily(ts_code=ts_code, start_date='20230101', end_date='20231231')
        print(f"成功获取到{len(stock_data)}条数据记录")
        print(stock_data.head())


if __name__ == "__main__":
    test_tushare()