import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Tuple

class Portfolio:
    def __init__(self, name: str, portfolio_type: str, initial_capital: float):
        self.name = name
        self.portfolio_type = portfolio_type
        self.cash = initial_capital
        self.positions = {}
        self.nav = initial_capital
        self.trade_log = []
        self.returns = []
        self.ir = 0.0
        self.position_history = []

    def calculate_daily_return(self, daily_returns: pd.Series):
        """计算当日收益并更新NAV"""
        position_return = sum([alloc * daily_returns[sector] for sector, alloc in self.positions.items()])
        self.nav = self.cash + sum(self.positions.values()) + position_return
        self.returns.append((self.nav - initial_capital) / initial_capital)

    def get_current_allocation(self) -> Dict[str, float]:
        """获取当前持仓权重"""
        total = sum(self.positions.values()) + self.cash
        return {sector: alloc/total for sector, alloc in self.positions.items()}

    def rebalance(self, new_positions: Dict[str, float], trade_date: datetime):
        # 清仓逻辑
        self.cash += sum(self.positions.values())
        self.positions.clear()
        
        # 新持仓分配
        total_weight = sum(new_positions.values())
        for sector, weight in new_positions.items():
            allocation = self.cash * weight / total_weight
            self.positions[sector] = allocation
            self.cash -= allocation
        
        # 记录调仓信息
        self.trade_log.append({
            'date': trade_date,
            'action': 'rebalance',
            'positions': self.positions.copy(),
            'nav': self.nav
        })

class SimulationEngine:
    def __init__(self):
        self.portfolios = {}
        self.sector_returns = pd.DataFrame()
        self.rebalance_dates = []

    def generate_rebalance_dates(self, start_date: datetime, end_date: datetime):
        """生成调仓日期序列"""
        # 月末调仓基准日
        month_ends = pd.date_range(start_date, end_date, freq='BM')
        
        for m_end in month_ends:
            # 调仓准备日（次月第一个交易日）
            prep_date = m_end + pd.offsets.BMonthBegin(1)
            # 调仓生效日（准备日+1交易日）
            effective_date = prep_date + pd.offsets.BDay(1)
            
            self.rebalance_dates.append({
                '基准日': m_end,
                '准备日': prep_date,
                '生效日': effective_date
            })

    def run_backtest(self, start_date: datetime, end_date: datetime):
        # 初始化回测日期
        self.generate_rebalance_dates(start_date, end_date)
        all_dates = pd.date_range(start_date, end_date, freq='B')

        # 主循环
        for curr_date in all_dates:
            # 获取当日收益率
            daily_return = self.sector_returns.loc[curr_date]
            
            # 检查调仓时间点
            for rb in self.rebalance_dates:
                # 调仓准备日：计算新持仓
                if curr_date == rb['准备日']:
                    ranking = self.calculate_sector_ranking(rb['基准日'])
                    for port in self.portfolios.values():
                        new_pos = self.generate_new_positions(port, ranking)
                        port.pending_positions = new_pos
                
                # 调仓生效日：执行调仓
                if curr_date == rb['生效日']:
                    for port in self.portfolios.values():
                        port.rebalance(port.pending_positions, curr_date)

            # 计算每日收益
            for port in self.portfolios.values():
                port.calculate_daily_return(daily_return)

    def calculate_sector_ranking(self, ranking_date: datetime) -> pd.Series:
        """计算行业排名"""
        lookback = 63  # 3个月
        start_date = ranking_date - pd.offsets.BDay(lookback)
        cum_returns = self.sector_returns.loc[start_date:ranking_date].sum()
        return cum_returns.sort_values(ascending=False)

    def generate_new_positions(self, portfolio: Portfolio, ranking: pd.Series) -> Dict[str, float]:
        """生成新持仓权重"""
        if portfolio.portfolio_type == 'long_only':
            top5 = ranking.head(5)
            return {sector: 1.0/5 for sector in top5.index}
        
        elif portfolio.portfolio_type == 'long_short':
            top5 = ranking.head(5)
            bottom5 = ranking.tail(5)
            return {
                **{sector: 0.5/5 for sector in top5.index},
                **{sector: -0.5/5 for sector in bottom5.index}
            }

    def analyze_performance(self):
        """绩效分析"""
        results = {}
        for name, port in self.portfolios.items():
            # 计算年化波动率
            returns = pd.Series(port.returns)
            vol = returns.std() * np.sqrt(252)
            
            # 计算信息比率
            results[name] = {
                'Final_NAV': port.nav,
                'Annualized_Return': returns.mean() * 252,
                'Volatility': vol,
                'IR': returns.mean() / returns.std() * np.sqrt(252),
                'Max_Drawdown': (returns.cummax() - returns).max()
            }
        return pd.DataFrame(results)

    def plot_results(self, save_path: str = 'backtest_results.png'):
        """可视化结果"""
        plt.figure(figsize=(12, 6))
        for name, port in self.portfolios.items():
            plt.plot(pd.Series(port.returns).cumsum(), label=name)
        
        plt.title('Accumulative Returns')
        plt.ylabel('Returns')
        plt.xlabel('Date')
        plt.legend()
        plt.grid(True)
        plt.savefig(save_path)
        plt.close()

if __name__ == '__main__':
    # 初始化回测引擎
    engine = SimulationEngine()
    engine.sector_returns = pd.read_parquet('sector_returns.parquet')
    
    # 创建投资组合
    engine.portfolios = {
        'Long_Top5': Portfolio('Long_Top5', 'long_only', 1_000_000),
        'Long_Short': Portfolio('Long_Short', 'long_short', 1_000_000)
    }
    
    # 运行回测
    start_date = engine.sector_returns.index[0]
    end_date = engine.sector_returns.index[-1]
    engine.run_backtest(start_date, end_date)
    
    # 分析结果
    performance = engine.analyze_performance()
    performance.to_csv('performance_report.csv')
    
    # 可视化并保存
    engine.plot_results()
    print('Backtest completed. Results saved to performance_report.csv and backtest_results.png')
    
    # 导出持仓日志
    for port in engine.portfolios.values():
        pd.DataFrame(port.trade_log).to_csv(f'{port.name}_trades.csv', index=False)