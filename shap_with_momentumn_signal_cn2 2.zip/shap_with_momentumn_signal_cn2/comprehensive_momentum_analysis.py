"""
综合动量因子分析脚本
包含源数据检查、动量因子计算、模型训练与评估、SHAP分析等功能
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import shap
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
import warnings
import config

# 尝试导入XGBoost
try:
    import xgboost as xgb
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False
    print("警告: XGBoost未安装，将使用随机森林模型")

warnings.filterwarnings('ignore')

# 设置中文字体支持
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


def load_and_sanity_check_data(index_name='csi800'):
    """
    加载并检查源数据
    :param index_name: 指数名称
    :return: DataFrame
    """
    print("=== 源数据检查 ===")
    file_path = f'data/{index_name}_daily_returns.csv'
    df = pd.read_csv(file_path)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    
    print(f"数据形状: {df.shape}")
    print(f"日期范围: {df['date'].min()} 到 {df['date'].max()}")
    print(f"缺失值统计:\n{df.isnull().sum()}")
    print(f"收益率统计:\n{df['return'].describe()}")
    
    # 绘制收益分布图
    plt.figure(figsize=(10, 6))
    plt.hist(df['return'].dropna(), bins=100, alpha=0.7, color='skyblue', edgecolor='black')
    plt.title('日收益率分布')
    plt.xlabel('收益率')
    plt.ylabel('频次')
    plt.grid(True, alpha=0.3)
    plt.savefig('return_distribution.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("收益率分布图已保存为 return_distribution.png")
    
    return df


def calculate_momentum_signals_with_params_info(df, short_window=5, medium_window=66, long_window=252):
    """
    计算三个动量信号：短期、中期、长期
    
    动量信号参数介绍:
    - 短期动量 (short_momentum): 反映最近市场趋势，窗口期较短，对价格变化敏感
    - 中期动量 (medium_momentum): 平衡短期噪声和长期趋势，捕捉中期市场动向
    - 长期动量 (long_momentum): 反映长期市场趋势，窗口期较长，稳定性较好
    
    计算方法:
    动量信号 = 过去N个交易日的累计收益 / 过去N个交易日的收益波动率
    
    :param df: 包含日期和收益率的DataFrame
    :param short_window: 短期窗口大小 (默认5个交易日)
    :param medium_window: 中期窗口大小 (默认66个交易日，约3个月)
    :param long_window: 长期窗口大小 (默认252个交易日，约1年)
    :return: 包含动量信号的DataFrame
    """
    print("=== 动量因子计算 ===")
    print(f"参数设置: 短期={short_window}, 中期={medium_window}, 长期={long_window}")
    
    # 短期动量：过去short_window个交易日的累计收益除以波动率
    short_term_return = df['return'].rolling(window=short_window).sum()
    short_term_volatility = df['return'].rolling(window=short_window).std()
    df['short_momentum'] = short_term_return / short_term_volatility
    
    # 中期动量：过去medium_window个交易日的累计收益除以波动率
    medium_term_return = df['return'].rolling(window=medium_window).sum()
    medium_term_volatility = df['return'].rolling(window=medium_window).std()
    df['medium_momentum'] = medium_term_return / medium_term_volatility
    
    # 长期动量：过去long_window个交易日的累计收益除以波动率
    long_term_return = df['return'].rolling(window=long_window).sum()
    long_term_volatility = df['return'].rolling(window=long_window).std()
    df['long_momentum'] = long_term_return / long_term_volatility
    
    # 绘制动量因子时间序列图
    plt.figure(figsize=(12, 8))
    
    # 子图1: 收益率
    plt.subplot(2, 1, 1)
    plt.plot(df['date'], df['return'], linewidth=0.8, color='gray')
    plt.title('日收益率时间序列')
    plt.ylabel('收益率')
    plt.grid(True, alpha=0.3)
    
    # 子图2: 动量因子
    plt.subplot(2, 1, 2)
    plt.plot(df['date'], df['short_momentum'], label='短期动量', linewidth=0.8)
    plt.plot(df['date'], df['medium_momentum'], label='中期动量', linewidth=0.8)
    plt.plot(df['date'], df['long_momentum'], label='长期动量', linewidth=0.8)
    plt.title('动量因子时间序列')
    plt.xlabel('日期')
    plt.ylabel('动量值')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('momentum_factors_time_series.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("动量因子时间序列图已保存为 momentum_factors_time_series.png")
    
    return df


def create_target_variable(df, future_days=5):
    """
    创建目标变量：未来5个交易日的回报
    :param df: 包含收益率的DataFrame
    :param future_days: 未来天数
    :return: 包含目标变量的DataFrame
    """
    df['future_return'] = df['return'].shift(-future_days).rolling(window=future_days).sum()
    return df


def prepare_features_and_target(df):
    """
    准备特征和目标变量
    :param df: 包含所有数据的DataFrame
    :return: 特征和目标变量
    """
    # 删除包含NaN的行
    df = df.dropna()
    
    # 选择特征
    features = ['short_momentum', 'medium_momentum', 'long_momentum']
    X = df[features]
    y = df['future_return']
    
    return X, y, df


def train_model(X, y):
    """
    训练模型（随机森林或XGBoost）
    :param X: 特征
    :param y: 目标变量
    :return: 训练好的模型
    """
    print("=== 模型训练 ===")
    # 分割训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # 根据配置选择模型类型
    if config.MODEL_TYPE == 'xgboost' and XGBOOST_AVAILABLE:
        print("使用XGBoost模型")
        model = xgb.XGBRegressor(
            n_estimators=100,
            random_state=42,
            objective='reg:squarederror'
        )
    else:
        print("使用随机森林模型")
        model = RandomForestRegressor(n_estimators=100, random_state=42)
    
    # 训练模型
    model.fit(X_train, y_train)
    
    # 预测
    y_pred = model.predict(X_test)
    
    # 计算均方误差
    mse = mean_squared_error(y_test, y_pred)
    print(f"模型均方误差: {mse}")
    
    return model, X_train, X_test, y_train, y_test, y_pred


def calculate_information_ratio(y_true, y_pred):
    """
    计算信息比率（IR）
    :param y_true: 真实值
    :param y_pred: 预测值
    :return: 信息比率
    """
    # 计算预测误差
    residuals = y_true - y_pred
    
    # 计算平均误差
    mean_residual = np.mean(residuals)
    
    # 计算误差的标准差
    std_residual = np.std(residuals)
    
    # 计算信息比率
    if std_residual != 0:
        ir = mean_residual / std_residual
    else:
        ir = 0
    
    return ir


def optimize_momentum_parameters(df, future_days=5):
    """
    优化动量信号参数以最大化信息比率
    :param df: DataFrame containing returns
    :param future_days: Future days
    :return: Best parameter combination and corresponding IR value
    """
    print("=== 模型评估和调优 ===")
    best_ir = -np.inf
    best_params = None
    
    # 定义参数搜索范围
    short_windows = [3, 5, 10]
    medium_windows = [20, 66, 120]
    long_windows = [120, 252, 300]
    
    total_combinations = len(short_windows) * len(medium_windows) * len(long_windows)
    print(f"开始优化参数，总共需要测试 {total_combinations} 种组合...")
    
    count = 0
    for short_window in short_windows:
        for medium_window in medium_windows:
            for long_window in long_windows:
                # 确保窗口大小递增
                if short_window < medium_window < long_window:
                    count += 1
                    print(f"测试参数组合 {count}/{total_combinations}: 短期={short_window}, 中期={medium_window}, 长期={long_window}")
                    
                    # 复制数据以避免修改原始数据
                    df_copy = df.copy()
                    
                    # 计算动量信号
                    df_copy = calculate_momentum_signals_with_params_info(df_copy, short_window, medium_window, long_window)
                    
                    # 创建目标变量
                    df_copy = create_target_variable(df_copy, future_days)
                    
                    # 准备特征和目标变量
                    X, y, df_processed = prepare_features_and_target(df_copy)
                    
                    # 如果数据量不足，跳过这个参数组合
                    if len(X) < 10:
                        continue
                    
                    # 分割训练集和测试集
                    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
                    
                    # 根据配置选择模型类型
                    if config.MODEL_TYPE == 'xgboost' and XGBOOST_AVAILABLE:
                        model = xgb.XGBRegressor(
                            n_estimators=100,
                            random_state=42,
                            objective='reg:squarederror'
                        )
                    else:
                        model = RandomForestRegressor(n_estimators=100, random_state=42)
                    
                    # 训练模型
                    model.fit(X_train, y_train)
                    
                    # 预测
                    y_pred = model.predict(X_test)
                    
                    # 计算信息比率
                    ir = calculate_information_ratio(y_test, y_pred)
                    
                    # 更新最佳参数
                    if ir > best_ir:
                        best_ir = ir
                        best_params = (short_window, medium_window, long_window)
                        print(f"发现更好的参数组合: 短期={short_window}, 中期={medium_window}, 长期={long_window}, IR={ir}")
    
    return best_params, best_ir


def plot_shap_timeseries(model, X, df):
    """
    绘制因子SHAP值的时间序列
    :param model: 训练好的模型
    :param X: 特征数据
    :param df: 包含日期信息的DataFrame
    :return: None
    """
    print("=== 绘制因子SHAP值的时间序列 ===")
    # 使用SHAP计算所有样本的贡献度
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X)
    
    # 创建DataFrame存储贡献度
    contributions_df = pd.DataFrame(shap_values, columns=['短期动量', '中期动量', '长期动量'])
    contributions_df['date'] = df['date'].iloc[:len(shap_values)].values
    
    # 保存贡献度到CSV文件
    contributions_df.to_csv('momentum_shap_contributions.csv', index=False)
    print("SHAP贡献度已保存为 momentum_shap_contributions.csv")
    
    # 绘制图表
    plt.figure(figsize=(12, 6))
    
    # 绘制三条线
    plt.plot(contributions_df['date'], contributions_df['短期动量'], label='短期动量', linewidth=0.8)
    plt.plot(contributions_df['date'], contributions_df['中期动量'], label='中期动量', linewidth=0.8)
    plt.plot(contributions_df['date'], contributions_df['长期动量'], label='长期动量', linewidth=0.8)
    
    # 添加标题和标签
    plt.title('三个动量因子SHAP贡献度随时间推移的变化')
    plt.xlabel('日期')
    plt.ylabel('SHAP贡献度')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # 保存图表
    plt.savefig('shap_contributions_timeseries.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("SHAP贡献度时间序列图已保存为 shap_contributions_timeseries.png")


def get_momentum_contributions_for_date(model, X, date_str, df):
    """
    获取指定日期的动量贡献度
    :param model: 训练好的模型
    :param X: 特征数据
    :param date_str: 日期字符串 (格式: 'yyyymmdd')
    :param df: 包含日期信息的DataFrame
    :return: 动量贡献度
    """
    print(f"=== 获取 {date_str} 的动量贡献度 ===")
    # 将日期字符串转换为datetime对象
    target_date = pd.to_datetime(date_str, format='%Y%m%d')
    
    # 找到最接近的日期索引
    date_diff = abs(df['date'] - target_date)
    closest_idx = date_diff.argmin()
    
    # 获取该日期的特征值
    feature_values = X.iloc[closest_idx].values.reshape(1, -1)
    
    # 使用SHAP计算贡献度
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(feature_values)
    
    # 获取特征名称
    feature_names = ['短期动量', '中期动量', '长期动量']
    
    # 返回贡献度
    contributions = dict(zip(feature_names, shap_values[0]))
    
    # 绘制瀑布图
    plot_waterfall(explainer, feature_values, feature_names, shap_values[0], date_str)
    
    return contributions


def plot_waterfall(explainer, feature_values, feature_names, shap_values, date_str):
    """
    绘制SHAP瀑布图
    :param explainer: SHAP解释器
    :param feature_values: 特征值
    :param feature_names: 特征名称
    :param shap_values: SHAP值
    :param date_str: 日期字符串
    :return: None
    """
    # 创建SHAP解释对象
    explanation = shap.Explanation(
        values=shap_values,
        base_values=explainer.expected_value,
        data=feature_values[0],
        feature_names=feature_names
    )
    
    # 绘制瀑布图
    shap.waterfall_plot(explanation, show=False)
    plt.title(f'{date_str} SHAP贡献度瀑布图')
    plt.tight_layout()
    plt.savefig(f'momentum_waterfall_{date_str}.png', dpi=300, bbox_inches='tight')
    plt.close()
    print(f"瀑布图已保存为 momentum_waterfall_{date_str}.png")


def analyze_momentum_change_around_date(model, X, df, date_str):
    """
    分析指定日期前后的动量因子变化
    :param model: 训练好的模型
    :param X: 特征数据
    :param df: 包含日期信息的DataFrame
    :param date_str: 日期字符串 (格式: 'yyyymmdd')
    :return: None
    """
    print(f"=== 分析 {date_str} 前后的动量因子变化 ===")
    # 将日期字符串转换为datetime对象
    target_date = pd.to_datetime(date_str, format='%Y%m%d')
    
    # 找到目标日期的索引
    date_diff = abs(df['date'] - target_date)
    target_idx = date_diff.argmin()
    
    # 确定分析的时间范围
    # 过去一个月（约22个交易日）
    start_idx = max(0, target_idx - 22)
    # 接下来5个交易日
    end_idx = min(len(df), target_idx + 5)
    
    # 获取分析范围内的数据
    analysis_df = df.iloc[start_idx:end_idx].copy()
    analysis_X = X.iloc[start_idx:end_idx]
    
    # 使用SHAP计算所有样本的贡献度
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(analysis_X)
    
    # 创建DataFrame存储贡献度
    contributions_df = pd.DataFrame(shap_values, columns=['短期动量', '中期动量', '长期动量'])
    contributions_df['date'] = analysis_df['date'].values
    
    # 找到目标日期在分析范围内的索引
    target_in_analysis = abs(contributions_df['date'] - target_date).argmin()
    
    # 计算过去一个月的平均贡献度
    past_month_contributions = contributions_df.iloc[:target_in_analysis+1][['短期动量', '中期动量', '长期动量']].mean()
    
    # 计算接下来5个交易日的平均贡献度
    future_5_contributions = contributions_df.iloc[target_in_analysis:][['短期动量', '中期动量', '长期动量']].mean()
    
    # 创建对比数据
    comparison_data = pd.DataFrame({
        '过去一个月': past_month_contributions,
        '接下来5个交易日': future_5_contributions
    })
    
    # 绘制对比图
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))
    
    # 第一个子图：柱状图对比
    comparison_data.plot(kind='bar', ax=ax1, color=['skyblue', 'lightcoral'])
    ax1.set_title(f'{date_str} 前后动量因子贡献度变化对比')
    ax1.set_xlabel('动量因子')
    ax1.set_ylabel('平均SHAP贡献度')
    ax1.set_xticklabels(ax1.get_xticklabels(), rotation=45)
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    # 在柱状图上添加数值标签
    for container in ax1.containers:
        ax1.bar_label(container, fmt='%.4f', padding=3)
    
    # 第二个子图：时间序列图
    contributions_df.plot(x='date', y=['短期动量', '中期动量', '长期动量'], ax=ax2)
    ax2.axvline(x=contributions_df['date'].iloc[target_in_analysis], color='red', linestyle='--', linewidth=1, label=f'目标日期 ({date_str})')
    ax2.set_title(f'{date_str} 前后动量因子贡献度时间序列')
    ax2.set_xlabel('日期')
    ax2.set_ylabel('SHAP贡献度')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    # 格式化日期显示
    fig.autofmt_xdate()
    
    plt.tight_layout()
    plt.savefig(f'momentum_change_around_{date_str}.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"动量因子变化图已保存为 momentum_change_around_{date_str}.png")
    
    # 打印详细信息
    print(f"\n{date_str} 前后动量因子贡献度变化分析:")
    print("\n过去一个月平均贡献度:")
    for factor, value in past_month_contributions.items():
        print(f"  {factor}: {value:.6f}")
    
    print("\n接下来5个交易日平均贡献度:")
    for factor, value in future_5_contributions.items():
        print(f"  {factor}: {value:.6f}")
    
    # 计算变化量
    change = future_5_contributions - past_month_contributions
    print("\n变化量 (接下来5个交易日 - 过去一个月):")
    for factor, value in change.items():
        print(f"  {factor}: {value:.6f}")


def detect_abnormal_signals(contributions_df, df_with_returns):
    """
    检测异常信号并分析后续收益
    :param contributions_df: 包含SHAP贡献度的DataFrame
    :param df_with_returns: 包含收益率的DataFrame
    :return: None
    """
    print("=== 检测异常信号并分析后续收益 ===")
    
    # 计算每个动量因子的1%分位数和99%分位数
    percentiles = [1, 99]
    
    # 创建结果存储
    alerts_summary = []
    
    for column in ['短期动量', '中期动量', '长期动量']:
        values = contributions_df[column]
        lower_percentile = np.percentile(values, percentiles[0])
        upper_percentile = np.percentile(values, percentiles[1])
        
        # 找出低于1%分位数和高于99%分位数的极端值
        lower_extremes = contributions_df[contributions_df[column] < lower_percentile]
        upper_extremes = contributions_df[contributions_df[column] > upper_percentile]
        
        # 合并极端值
        extremes = pd.concat([lower_extremes, upper_extremes])
        
        print(f"\n{column}的异常信号检测:")
        print(f"1%分位数: {lower_percentile:.6f}")
        print(f"99%分位数: {upper_percentile:.6f}")
        print(f"异常信号数量: {len(extremes)}")
        
        # 分析每个异常信号日期后的5日收益
        future_returns = []
        for _, row in extremes.iterrows():
            alert_date = row['date']
            # 找到该日期在原始数据中的索引
            date_idx = df_with_returns[df_with_returns['date'] == alert_date].index
            if len(date_idx) > 0:
                idx = date_idx[0]
                # 计算接下来5个交易日的收益
                if idx + 5 < len(df_with_returns):
                    future_5d_return = df_with_returns.loc[idx+1:idx+5, 'return'].sum()
                    future_returns.append(future_5d_return)
                else:
                    future_returns.append(np.nan)
        
        # 统计分析
        valid_returns = [r for r in future_returns if not np.isnan(r)]
        if valid_returns:
            avg_future_return = np.mean(valid_returns)
            positive_count = sum(1 for r in valid_returns if r > 0)
            negative_count = len(valid_returns) - positive_count
            positive_rate = positive_count / len(valid_returns) if len(valid_returns) > 0 else 0
            
            print(f"后续5日平均收益: {avg_future_return:.6f}")
            print(f"正收益次数: {positive_count}")
            print(f"负收益次数: {negative_count}")
            print(f"正收益比例: {positive_rate:.2%}")
            
            # 绘制后续收益分布图
            plt.figure(figsize=(10, 6))
            plt.hist(valid_returns, bins=30, alpha=0.7, color='lightblue', edgecolor='black')
            plt.axvline(avg_future_return, color='red', linestyle='--', linewidth=2, 
                       label=f'平均收益: {avg_future_return:.4f}')
            plt.axvline(0, color='black', linestyle='-', linewidth=1)
            plt.title(f'{column}异常信号后5日收益分布')
            plt.xlabel('5日收益')
            plt.ylabel('频次')
            plt.legend()
            plt.grid(True, alpha=0.3)
            plt.savefig(f'abnormal_signals_future_returns_{column}.png', dpi=300, bbox_inches='tight')
            plt.close()
            print(f"收益分布图已保存为 abnormal_signals_future_returns_{column}.png")
            
            # 保存结果摘要
            alerts_summary.append({
                '因子': column,
                '异常信号数量': len(extremes),
                '后续5日平均收益': avg_future_return,
                '正收益比例': positive_rate
            })
        else:
            print("无有效后续收益数据")
    
    # 保存摘要到CSV
    if alerts_summary:
        summary_df = pd.DataFrame(alerts_summary)
        summary_df.to_csv('abnormal_signals_summary.csv', index=False)
        print("\n异常信号分析摘要已保存为 abnormal_signals_summary.csv")
        print(summary_df.to_string(index=False))


def main():
    """
    主函数
    """
    print("开始综合动量因子分析...")
    
    # 1. 源数据检查
    df = load_and_sanity_check_data(config.INDEX_NAME)
    
    # 2. 动量因子计算
    df = calculate_momentum_signals_with_params_info(df)
    
    # 3. 创建目标变量
    df = create_target_variable(df, config.FUTURE_DAYS)
    
    # 4. 准备特征和目标变量
    X, y, df_processed = prepare_features_and_target(df)
    
    # 5. 模型训练
    model, X_train, X_test, y_train, y_test, y_pred = train_model(X, y)
    
    # 6. 模型评估
    ir = calculate_information_ratio(y_test, y_pred)
    print(f"\n模型信息比率 (IR): {ir}")
    
    # 7. 输出特征重要性
    feature_names = ['短期动量', '中期动量', '长期动量']
    importances = model.feature_importances_
    print("\n特征重要性:")
    for name, importance in zip(feature_names, importances):
        print(f"{name}: {importance:.6f}")
    
    # 8. 绘制因子SHAP值的时间序列
    plot_shap_timeseries(model, X, df_processed)
    
    # 9. 获取特定日期的动量贡献度
    # 读取SHAP贡献度数据
    contributions_df = pd.read_csv('momentum_shap_contributions.csv')
    contributions_df['date'] = pd.to_datetime(contributions_df['date'])
    
    # 选择一个示例日期进行分析
    example_date = '20240924'
    contributions = get_momentum_contributions_for_date(model, X, example_date, df_processed)
    print(f"\n{example_date} 的动量贡献度:")
    for factor, contribution in contributions.items():
        print(f"{factor}: {contribution:.6f}")
    
    # 10. 分析指定日期前后的动量因子变化
    analyze_momentum_change_around_date(model, X, df_processed, example_date)
    
    # 11. 检测异常信号并分析后续收益
    detect_abnormal_signals(contributions_df, df)
    
    print("\n=== 主要结论 ===")
    print("1. 数据质量良好，包含足够的历史数据用于分析")
    print(f"2. 使用{config.MODEL_TYPE}模型训练，信息比率(IR)为{ir:.4f}")
    print("3. 通过SHAP分析，可以量化各动量因子对预测的贡献")
    print("4. 能够检测异常信号并分析其后续收益表现")
    
    print("\n=== 下一步建议 ===")
    print("1. 可以进一步优化模型参数，提高预测准确性")
    print("2. 可以增加更多类型的因子，丰富模型特征")
    print("3. 可以建立实时监控系统，持续跟踪动量因子变化")
    print("4. 可以将模型集成到交易系统中，实现自动化决策")
    
    print("\n综合动量因子分析完成！")


if __name__ == "__main__":
    main()