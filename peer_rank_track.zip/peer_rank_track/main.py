#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys

# 添加项目根目录到Python路径
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

def get_project_root():
    """
    获取项目根目录的绝对路径
    这样可以确保在不同环境中都能正确找到配置文件
    """
    # 获取当前文件所在的目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    return current_dir

def load_config():
    """
    动态加载配置文件
    """
    # 动态导入配置文件
    try:
        import config
        return config.FUNDS
    except ImportError as e:
        print(f"无法导入配置文件: {e}")
        return []

def display_funds(funds):
    """
    显示基金信息
    """
    if not funds:
        print("没有找到基金信息")
        return
    
    print("基金产品信息:")
    print("-" * 50)
    for fund in funds:
        print(f"ID: {fund.get('id', 'N/A')}")
        print(f"名称: {fund.get('name', 'N/A')}")
        print(f"代码: {fund.get('code', 'N/A')}")
        print(f"类型: {fund.get('type', 'N/A')}")
        print(f"公司: {fund.get('company', 'N/A')}")
        print(f"成立日期: {fund.get('establish_date', 'N/A')}")
        print(f"基金经理: {fund.get('manager', 'N/A')}")
        print(f"规模: {fund.get('scale', 'N/A')}")
        print(f"货币: {fund.get('currency', 'N/A')}")
        
        # 如果有成立日期，计算并显示不同时间段的日期
        establish_date = fund.get('establish_date', 'N/A')
        if establish_date != 'N/A':
            try:
                from util import calculate_date_ranges
                date_ranges = calculate_date_ranges(establish_date)
                if date_ranges:
                    print("历史关键日期:")
                    for period, date in date_ranges.items():
                        print(f"  {period}: {date}")
            except ImportError:
                print("  无法导入日期计算工具")
        
        print("-" * 30)

def display_filtered_funds_by_range(csv_file_path: str, date_range_key: str, reference_date: str):
    """
    显示按日期范围筛选的基金信息
    
    Args:
        csv_file_path (str): 基金数据CSV文件路径
        date_range_key (str): 日期范围键（如'1w', '1m', '3m', '6m', '1y', '2y', '3y'）
        reference_date (str): 参考日期，格式为 'YYYY-MM-DD'
    """
    try:
        from util import filter_funds_by_date_range, calculate_date_ranges
        
        # 计算日期范围
        date_ranges = calculate_date_ranges(reference_date)
        target_date = date_ranges.get(date_range_key)
        
        if not target_date:
            print(f"无效的日期范围键: {date_range_key}")
            return
            
        print(f"\n在{date_range_key}({target_date})之前成立的基金:")
        print("-" * 50)
        
        # 筛选基金
        filtered_results = filter_funds_by_date_range(csv_file_path, [date_range_key], reference_date)
        filtered_df = filtered_results[date_range_key]
        
        if filtered_df.empty:
            print("没有找到符合条件的基金")
            return
            
        print(f"共找到 {len(filtered_df)} 只基金:")
        for i, (_, fund) in enumerate(filtered_df.head(10).iterrows(), 1):  # 只显示前10只
            print(f"{i}. {fund['fund_code']} {fund['fund_name']} 成立日期: {fund['establish_date']}")
            
        if len(filtered_df) > 10:
            print(f"... 还有 {len(filtered_df) - 10} 只基金")
            
    except Exception as e:
        print(f"显示筛选基金时发生错误: {e}")


def main():
    """
    主函数
    """
    print(f"项目根目录: {get_project_root()}")
    
    # 加载基金配置
    funds = load_config()
    
    # 显示基金信息
    display_funds(funds)
    
    # 演示日期范围筛选功能
    csv_file_path = "fund_data.csv"
    reference_date = "2024-12-27"
    
    print("\n" + "="*60)
    print("基金筛选功能演示")
    print("="*60)
    
    # 演示几种不同的日期范围筛选
    date_ranges_demo = ['1w', '1m', '3m', '1y']
    for date_range in date_ranges_demo:
        display_filtered_funds_by_range(csv_file_path, date_range, reference_date)

if __name__ == "__main__":
    main()