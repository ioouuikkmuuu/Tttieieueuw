# 基金产品配置文件

# 基金产品信息列表
FUNDS = [
    {
        "id": "001",
        "name": "沪深300指数基金",
        "code": "160123",
        "type": "指数型",
        "company": "南方基金",
        "establish_date": "2010-05-15",
        "manager": "张三",
        "scale": "50亿",
        "currency": "人民币"
    },
    {
        "id": "002",
        "name": "中证500增强基金",
        "code": "160234",
        "type": "主动型",
        "company": "华夏基金",
        "establish_date": "2012-03-21",
        "manager": "李四",
        "scale": "30亿",
        "currency": "人民币"
    },
    {
        "id": "003",
        "name": "纳斯达克100ETF",
        "code": "160345",
        "type": "QDII",
        "company": "易方达基金",
        "establish_date": "2015-11-08",
        "manager": "王五",
        "scale": "20亿",
        "currency": "美元"
    },
    {
        "id": "004",
        "name": "债券优选基金",
        "code": "160456",
        "type": "债券型",
        "company": "博时基金",
        "establish_date": "2018-07-30",
        "manager": "赵六",
        "scale": "15亿",
        "currency": "人民币"
    }
]