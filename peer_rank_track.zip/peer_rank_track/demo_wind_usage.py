#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Wind接口基金表现数据获取演示
展示如何使用wind_util模块获取基金在不同时间段的表现数据
"""

import os
import sys
import pandas as pd

# 添加项目根目录到Python路径
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

try:
    from wind_util import get_fund_performance_by_code, get_single_fund_performance
    print("成功导入wind_util模块")
except ImportError as e:
    print(f"导入wind_util模块失败: {e}")
    sys.exit(1)

def main():
    print("Wind接口基金表现数据获取演示")
    print("=" * 50)
    
    # 创建示例基金数据
    sample_funds = pd.DataFrame({
        'fund_code': ['000001.OF', '000002.OF', '000003.OF', '000004.OF', '000005.OF'],
        'fund_name': ['华夏成长', '易方达消费', '嘉实沪深300', '南方中证500', '博时主题']
    })
    
    print("示例基金数据:")
    print(sample_funds)
    print()
    
    # 演示1: 获取所有基金的表现数据
    print("演示1: 获取所有基金的表现数据")
    print("-" * 30)
    try:
        # 获取基金表现数据
        performance_df = get_fund_performance_by_code(sample_funds)
        print("基金表现数据:")
        print(performance_df)
        print()
    except Exception as e:
        print(f"获取基金表现数据时出错: {e}")
        print()
    
    # 演示2: 获取特定时间段的表现数据
    print("演示2: 获取特定时间段的表现数据")
    print("-" * 30)
    try:
        # 只获取日度、月度和年度表现数据
        selected_periods = ['daily', '1m', '1y']
        performance_df_selected = get_fund_performance_by_code(sample_funds, selected_periods)
        print(f"基金在{selected_periods}时间段的表现数据:")
        print(performance_df_selected)
        print()
    except Exception as e:
        print(f"获取特定时间段表现数据时出错: {e}")
        print()
    
    # 演示3: 获取单个基金的表现数据
    print("演示3: 获取单个基金的表现数据")
    print("-" * 30)
    try:
        single_fund_perf = get_single_fund_performance('000001.OF')
        print("单个基金表现数据:")
        for key, value in single_fund_perf.items():
            print(f"  {key}: {value}")
        print()
    except Exception as e:
        print(f"获取单个基金表现数据时出错: {e}")
        print()
    
    # 演示4: 与其他数据结合使用
    print("演示4: 与其他数据结合使用")
    print("-" * 30)
    try:
        # 假设我们有一些额外的基金信息
        extended_fund_info = pd.DataFrame({
            'fund_code': ['000001.OF', '000002.OF', '000003.OF'],
            'fund_name': ['华夏成长', '易方达消费', '嘉实沪深300'],
            'fund_type': ['股票型', '混合型', '指数型'],
            'manager': ['张三', '李四', '王五']
        })
        
        print("扩展基金信息:")
        print(extended_fund_info)
        print()
        
        # 获取这些基金的表现数据
        performance_with_info = get_fund_performance_by_code(extended_fund_info)
        print("结合表现数据的基金信息:")
        print(performance_with_info)
        print()
    except Exception as e:
        print(f"结合其他数据时出错: {e}")
        print()

if __name__ == "__main__":
    main()