#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import datetime
from typing import Dict, List, Optional
from dateutil.relativedelta import relativedelta

def calculate_date_ranges(base_date: str) -> Dict[str, str]:
    """
    根据基准日期计算不同时间段的日期
    注意：除了1周外，其他时间间隔都需要在计算结果基础上加回1天
    
    Args:
        base_date (str): 基准日期，格式为 'YYYY-MM-DD'
        
    Returns:
        Dict[str, str]: 包含不同时间段日期的字典
    """
    try:
        # 将字符串转换为日期对象
        date_obj = datetime.datetime.strptime(base_date, '%Y-%m-%d')
        
        # 计算不同时间段的日期
        dates = {}
        
        # 1周前（不需要加回1天）
        week_ago = date_obj - datetime.timedelta(weeks=1)
        dates['1w'] = week_ago.strftime('%Y-%m-%d')
        
        # 1个月前（加回1天）
        month_ago = date_obj - relativedelta(months=1) + datetime.timedelta(days=1)
        dates['1m'] = month_ago.strftime('%Y-%m-%d')
        
        # 3个月前（加回1天）
        three_months_ago = date_obj - relativedelta(months=3) + datetime.timedelta(days=1)
        dates['3m'] = three_months_ago.strftime('%Y-%m-%d')
        
        # 6个月前（加回1天）
        six_months_ago = date_obj - relativedelta(months=6) + datetime.timedelta(days=1)
        dates['6m'] = six_months_ago.strftime('%Y-%m-%d')
        
        # 1年前（加回1天）
        year_ago = date_obj - relativedelta(years=1) + datetime.timedelta(days=1)
        dates['1y'] = year_ago.strftime('%Y-%m-%d')
        
        # 2年前（加回1天）
        two_years_ago = date_obj - relativedelta(years=2) + datetime.timedelta(days=1)
        dates['2y'] = two_years_ago.strftime('%Y-%m-%d')
        
        # 3年前（加回1天）
        three_years_ago = date_obj - relativedelta(years=3) + datetime.timedelta(days=1)
        dates['3y'] = three_years_ago.strftime('%Y-%m-%d')
        
        return dates
        
    except ValueError as e:
        print(f"日期格式错误: {e}")
        return {}

def calculate_fund_date_ranges(fund_list: List[Dict]) -> List[Dict]:
    """
    为基金列表中的每个基金计算日期范围
    
    Args:
        fund_list (List[Dict]): 基金信息列表
        
    Returns:
        List[Dict]: 添加了日期范围信息的基金列表
    """
    result = []
    
    for fund in fund_list:
        # 复制原始基金信息
        fund_with_dates = fund.copy()
        
        # 获取基金的成立日期
        establish_date = fund.get('establish_date')
        
        if establish_date:
            # 计算该基金的日期范围
            date_ranges = calculate_date_ranges(establish_date)
            fund_with_dates['date_ranges'] = date_ranges
        else:
            fund_with_dates['date_ranges'] = {}
            
        result.append(fund_with_dates)
        
    return result


def filter_funds_by_date_range(csv_file_path: str, date_range_keys: list, reference_date: str) -> dict:
    """
    根据多个日期范围筛选基金数据，返回切片后的DataFrames
    
    Args:
        csv_file_path (str): 基金数据CSV文件路径
        date_range_keys (list): 日期范围键列表（如['1w', '1m', '3m', '6m', '1y', '2y', '3y']）
        reference_date (str): 参考日期，格式为 'YYYY-MM-DD'
        
    Returns:
        dict: 以日期范围为键，切片后的DataFrames为值的字典
    """
    import pandas as pd
    from datetime import datetime
    
    try:
        # 读取CSV文件
        df = pd.read_csv(csv_file_path)
        
        # 计算参考日期范围内对应的日期
        date_ranges = calculate_date_ranges(reference_date)
        
        # 存储结果的字典
        result = {}
        
        # 对每个日期范围进行筛选
        for date_range_key in date_range_keys:
            target_date_str = date_ranges.get(date_range_key)
            
            if not target_date_str:
                print(f"警告: 无效的日期范围键: {date_range_key}")
                result[date_range_key] = pd.DataFrame()  # 空DataFrame
                continue
            
            # 筛选出成立日期早于或等于目标日期的基金
            filtered_df = df[df['establish_date'] <= target_date_str]
            
            # 将筛选后的DataFrame添加到结果字典中
            result[date_range_key] = filtered_df
        
        return result
        
    except FileNotFoundError:
        print(f"文件未找到: {csv_file_path}")
        return {key: pd.DataFrame() for key in date_range_keys}  # 返回空DataFrame字典
    except Exception as e:
        print(f"处理过程中发生错误: {e}")
        return {key: pd.DataFrame() for key in date_range_keys}  # 返回空DataFrame字典


# 示例用法
if __name__ == "__main__":
    # 测试单个日期计算
    test_date = "2023-01-01"
    ranges = calculate_date_ranges(test_date)
    print(f"基准日期: {test_date}")
    for key, value in ranges.items():
        print(f"{key}: {value}")