#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Wind接口基金表现数据获取工具
用于获取基金在不同时间段的表现数据
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# 模拟WindPy模块用于演示（实际使用时需要替换为真实的WindPy）
class MockWind:
    def __init__(self):
        self.connected = False
    
    def start(self):
        self.connected = True
        print("Mock Wind connected")
    
    def isconnected(self):
        return self.connected
    
    def wss(self, codes, indicators, params):
        """模拟Wind数据获取"""
        class MockData:
            def __init__(self, codes):
                self.ErrorCode = 0
                # 生成模拟数据
                self.Data = [[np.random.uniform(-0.1, 0.1) for _ in range(len(codes))]]
                # 第一个基金设置为NaN模拟缺失数据的情况
                if len(self.Data[0]) > 0:
                    self.Data[0][0] = np.nan
        
        return MockData(codes)

# 尝试导入真实的WindPy，如果失败则使用模拟版本
try:
    from WindPy import w
    WIND_AVAILABLE = True
except ImportError:
    w = MockWind()
    WIND_AVAILABLE = False
    print("Warning: WindPy module not found. Using mock WindPy for demonstration.")

def get_fund_performance_by_code(fund_df, performance_periods=None):
    """
    使用Wind接口获取基金在不同时间段的表现数据
    
    Args:
        fund_df (pd.DataFrame): 包含基金代码的DataFrame，必须包含'fund_code'列
        performance_periods (list): 时间段列表，默认为['daily', '1w', '1m', '3m', '6m', '1y', '2y', '3y']
        
    Returns:
        pd.DataFrame: 包含基金代码和各时间段表现数据的DataFrame
    """
    # 检查输入DataFrame是否包含fund_code列
    if 'fund_code' not in fund_df.columns:
        raise ValueError("Input DataFrame must contain 'fund_code' column")
    
    # 默认时间段
    if performance_periods is None:
        performance_periods = ['daily', '1w', '1m', '3m', '6m', '1y', '2y', '3y']
    
    # 初始化Wind连接
    if not w.isconnected():
        w.start()
        if not w.isconnected():
            print("Error: Failed to connect to Wind.")
            # 返回原始DataFrame，但添加空的性能列
            result_df = fund_df.copy()
            for period in performance_periods:
                result_df[f'perf_{period}'] = None
            return result_df
    
    # 创建结果DataFrame
    result_df = fund_df.copy()
    
    # 为每个时间段获取数据
    for period in performance_periods:
        try:
            # 构造Wind指标和参数
            indicator, params = _construct_wind_params(period)
            
            # 获取基金代码列表
            fund_codes = fund_df['fund_code'].tolist()
            
            # 从Wind获取数据
            data = w.wss(fund_codes, indicator, params)
            
            # 检查数据是否有效
            if data.ErrorCode != 0:
                print(f"Warning: Failed to fetch {period} performance data. Error code: {data.ErrorCode}")
                result_df[f'perf_{period}'] = None
                continue
            
            # 将数据添加到结果DataFrame
            if data.Data and len(data.Data) > 0:
                result_df[f'perf_{period}'] = data.Data[0]
            else:
                result_df[f'perf_{period}'] = None
                
        except Exception as e:
            print(f"Warning: Exception occurred while fetching {period} performance data: {e}")
            result_df[f'perf_{period}'] = None
    
    return result_df

def _construct_wind_params(period):
    """
    根据时间段构造Wind指标和参数
    
    Args:
        period (str): 时间段标识符
        
    Returns:
        tuple: (指标, 参数)元组
    """
    # Wind参数映射表
    params_map = {
        'daily': ('NAV_period_chg', 'unit=1;startDate=ED-1D'),
        '1w': ('NAV_period_chg', 'unit=1;startDate=ED-7D'),
        '1m': ('NAV_period_chg', 'unit=1;startDate=ED-1M'),
        '3m': ('NAV_period_chg', 'unit=1;startDate=ED-3M'),
        '6m': ('NAV_period_chg', 'unit=1;startDate=ED-6M'),
        '1y': ('NAV_period_chg', 'unit=1;startDate=ED-1Y'),
        '2y': ('NAV_period_chg', 'unit=1;startDate=ED-2Y'),
        '3y': ('NAV_period_chg', 'unit=1;startDate=ED-3Y')
    }
    
    # 返回对应的时间段参数，如果没有匹配则返回默认值
    return params_map.get(period, ('NAV_period_chg', 'unit=1;startDate=ED0D'))

def get_single_fund_performance(fund_code, performance_periods=None):
    """
    获取单个基金在不同时间段的表现数据
    
    Args:
        fund_code (str): 基金代码
        performance_periods (list): 时间段列表，默认为['daily', '1w', '1m', '3m', '6m', '1y', '2y', '3y']
        
    Returns:
        dict: 包含各时间段表现数据的字典
    """
    # 创建只有一个基金代码的DataFrame
    fund_df = pd.DataFrame({'fund_code': [fund_code]})
    
    # 获取表现数据
    result_df = get_fund_performance_by_code(fund_df, performance_periods)
    
    # 返回第一行数据（因为只有一个基金）
    if not result_df.empty:
        return result_df.iloc[0].to_dict()
    else:
        return {}

# 示例用法
if __name__ == "__main__":
    # 示例：创建一个包含基金代码的DataFrame
    sample_funds = pd.DataFrame({
        'fund_code': ['000001.OF', '000002.OF', '000003.OF'],
        'fund_name': ['基金A', '基金B', '基金C']
    })
    
    print("示例基金数据:")
    print(sample_funds)
    print("\n获取基金表现数据...")
    
    # 获取基金表现数据
    performance_df = get_fund_performance_by_code(sample_funds)
    print("\n基金表现数据:")
    print(performance_df)