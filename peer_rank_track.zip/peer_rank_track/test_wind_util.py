#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
测试wind_util.py模块的脚本
"""

import os
import sys
import pandas as pd

# 添加项目根目录到Python路径
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

try:
    from wind_util import get_fund_performance_by_code, get_single_fund_performance
    WIND_UTIL_AVAILABLE = True
except ImportError:
    WIND_UTIL_AVAILABLE = False
    print("Warning: wind_util module not found or WindPy not installed.")

def main():
    if not WIND_UTIL_AVAILABLE:
        print("Cannot run tests without wind_util module.")
        return
    
    print("Wind基金表现数据获取测试")
    print("=" * 50)
    
    # 创建示例基金数据
    sample_funds = pd.DataFrame({
        'fund_code': ['000001.OF', '000002.OF', '000003.OF'],
        'fund_name': ['基金A', '基金B', '基金C']
    })
    
    print("测试数据:")
    print(sample_funds)
    print()
    
    # 测试获取多个基金的表现数据
    print("测试获取多个基金的表现数据...")
    try:
        result = get_fund_performance_by_code(sample_funds)
        print("获取结果:")
        print(result)
        print()
    except Exception as e:
        print(f"获取多个基金表现数据时出错: {e}")
        print()
    
    # 测试获取单个基金的表现数据
    print("测试获取单个基金的表现数据...")
    try:
        single_result = get_single_fund_performance('000001.OF')
        print("单个基金表现数据:")
        print(single_result)
        print()
    except Exception as e:
        print(f"获取单个基金表现数据时出错: {e}")
        print()

if __name__ == "__main__":
    main()