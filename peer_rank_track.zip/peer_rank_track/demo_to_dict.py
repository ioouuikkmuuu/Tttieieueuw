#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import pandas as pd

# 创建一个示例DataFrame
data = {
    'fund_code': ['001.OF', '002.OF', '003.OF'],
    'fund_name': ['基金A', '基金B', '基金C'],
    'establish_date': ['2020-01-01', '2021-06-15', '2022-12-30']
}

df = pd.DataFrame(data)
print("原始DataFrame:")
print(df)
print()

# 使用不同的to_dict参数
print("使用 to_dict() 不带参数:")
print(df.to_dict())
print()

print("使用 to_dict('records'):")
result = df.to_dict('records')
print(result)
print()

print("结果类型:", type(result))
if result:
    print("第一个元素类型:", type(result[0]))
    print("第一个元素内容:", result[0])