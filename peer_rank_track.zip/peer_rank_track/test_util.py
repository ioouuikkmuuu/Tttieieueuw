#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os

# 添加项目根目录到Python路径
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

from util import calculate_date_ranges

def test_date_calculation():
    """
    测试日期计算函数
    """
    # 测试日期 2025-11-20 (将 20251120 转换为标准格式)
    test_date = "2025-11-20"
    
    print(f"基准日期: {test_date}")
    print("=" * 40)
    
    # 计算各个时间段的日期
    date_ranges = calculate_date_ranges(test_date)
    
    if date_ranges:
        for period, date in date_ranges.items():
            print(f"{period:>3}: {date}")
    else:
        print("日期计算失败")
    
    print("\n" + "=" * 40)
    print("说明：除了1周(1w)外，其他时间间隔都在计算结果基础上加回了1天")

if __name__ == "__main__":
    test_date_calculation()