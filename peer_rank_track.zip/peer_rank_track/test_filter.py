#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys

# 添加项目根目录到Python路径
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

from util import filter_funds_by_date_range, calculate_date_ranges

def main():
    # CSV文件路径
    csv_file_path = "fund_data.csv"
    
    # 参考日期
    reference_date = "2024-12-27"
    
    # 显示参考日期的不同时间范围
    print(f"参考日期: {reference_date}")
    date_ranges = calculate_date_ranges(reference_date)
    for key, value in date_ranges.items():
        print(f"{key}: {value}")
    
    print("\n" + "="*50)
    
    # 测试不同的日期范围筛选
    date_ranges_to_test = ['1w', '1m', '3m', '6m', '1y', '2y', '3y']
    
    # 使用新的函数签名获取所有日期范围的数据
    filtered_results = filter_funds_by_date_range(csv_file_path, date_ranges_to_test, reference_date)
    
    for date_range in date_ranges_to_test:
        print(f"\n筛选在{date_range}({date_ranges[date_range]})之前成立的基金:")
        filtered_df = filtered_results[date_range]
        print(f"符合条件的基金数量: {len(filtered_df)}")
        
        # 显示前几个基金作为示例
        for i, (_, fund) in enumerate(filtered_df.head(3).iterrows()):
            print(f"  {i+1}. {fund['fund_code']} {fund['fund_name']} {fund['establish_date']}")

if __name__ == "__main__":
    main()