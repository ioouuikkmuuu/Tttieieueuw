import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体支持
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

def load_data():
    """加载数据"""
    # 加载SHAP贡献度数据
    shap_df = pd.read_csv('momentum_shap_contributions.csv')
    shap_df['date'] = pd.to_datetime(shap_df['date'])
    
    # 加载原始收益数据
    returns_df = pd.read_csv('data/csi800_daily_returns.csv')
    returns_df['date'] = pd.to_datetime(returns_df['date'])
    returns_df = returns_df.dropna(subset=['return'])  # 移除空值
    
    return shap_df, returns_df

def calculate_statistics(shap_df):
    """
    计算每个因子的统计信息（历史平均值、标准差等）
    :param shap_df: SHAP贡献度数据
    :return: 包含统计信息的字典
    """
    factors = ['短期动量', '中期动量', '长期动量']
    stats = {}
    
    for factor in factors:
        values = shap_df[factor]
        stats[factor] = {
            'mean': values.mean(),
            'std': values.std(),
            'min': values.min(),
            'max': values.max(),
            'median': values.median()
        }
    
    return stats

def get_top_shap_dates_with_stats(shap_df, stats, n=10):
    """
    获取每个因子SHAP贡献值前n的日期，并计算与历史平均值的偏离程度
    :param shap_df: SHAP贡献度数据
    :param stats: 统计信息
    :param n: 前n个日期
    :return: 包含前n个日期和统计信息的字典
    """
    factors = ['短期动量', '中期动量', '长期动量']
    top_dates = {
        'positive': {},  # 正向贡献
        'negative': {}   # 负向贡献
    }
    
    for factor in factors:
        # 正向贡献：按SHAP值降序排列
        positive_df = shap_df[shap_df[factor] > 0].copy()
        positive_df = positive_df.iloc[positive_df[factor].argsort()[::-1]]
        top_positive = positive_df.head(n)[['date', factor]].copy()
        
        # 计算与历史平均值的偏离程度
        mean_value = stats[factor]['mean']
        top_positive['与历史平均偏离'] = top_positive[factor] - mean_value
        top_positive['偏离倍数'] = top_positive['与历史平均偏离'] / stats[factor]['std']
        
        top_dates['positive'][factor] = top_positive
        
        # 负向贡献：按SHAP值升序排列（最负的在前）
        negative_df = shap_df[shap_df[factor] < 0].copy()
        negative_df = negative_df.iloc[negative_df[factor].argsort()]
        top_negative = negative_df.head(n)[['date', factor]].copy()
        
        # 计算与历史平均值的偏离程度
        top_negative['与历史平均偏离'] = top_negative[factor] - mean_value
        top_negative['偏离倍数'] = top_negative['与历史平均偏离'] / stats[factor]['std']
        
        top_dates['negative'][factor] = top_negative
    
    return top_dates

def print_top_shap_analysis(top_shap_dates, stats):
    """
    打印前几大SHAP值的详细分析，包括历史平均值和偏离程度
    :param top_shap_dates: 前n个SHAP值日期
    :param stats: 统计信息
    """
    print("SHAP贡献值分析报告（包含历史平均值及偏离程度）")
    print("=" * 80)
    
    # 打印每个因子的统计信息
    print("\n各因子历史统计信息:")
    print("-" * 50)
    for factor in ['短期动量', '中期动量', '长期动量']:
        print(f"\n{factor}:")
        print(f"  历史平均值: {stats[factor]['mean']:.6f}")
        print(f"  标准差:     {stats[factor]['std']:.6f}")
        print(f"  中位数:     {stats[factor]['median']:.6f}")
        print(f"  最小值:     {stats[factor]['min']:.6f}")
        print(f"  最大值:     {stats[factor]['max']:.6f}")
    
    # 打印前10个SHAP贡献值日期的信息（正向贡献）
    print("\n\n各因子SHAP贡献值前10日期（正向贡献）:")
    print("=" * 80)
    
    for factor, dates_df in top_shap_dates['positive'].items():
        print(f"\n{factor} 正向贡献:")
        print("-" * 60)
        print(f"{'排名':<4} {'日期':<12} {'SHAP值':<12} {'偏离程度':<12} {'偏离倍数':<10}")
        print("-" * 60)
        for i, (_, row) in enumerate(dates_df.iterrows(), 1):
            date = row['date'].strftime('%Y-%m-%d')
            shap_value = row[factor]
            deviation = row['与历史平均偏离']
            std_deviation = row['偏离倍数']
            print(f"{i:<4} {date:<12} {shap_value:<12.6f} {deviation:<12.6f} {std_deviation:<10.2f}")
    
    # 打印前10个SHAP贡献值日期的信息（负向贡献）
    print("\n\n各因子SHAP贡献值前10日期（负向贡献）:")
    print("=" * 80)
    
    for factor, dates_df in top_shap_dates['negative'].items():
        print(f"\n{factor} 负向贡献:")
        print("-" * 60)
        print(f"{'排名':<4} {'日期':<12} {'SHAP值':<12} {'偏离程度':<12} {'偏离倍数':<10}")
        print("-" * 60)
        for i, (_, row) in enumerate(dates_df.iterrows(), 1):
            date = row['date'].strftime('%Y-%m-%d')
            shap_value = row[factor]
            deviation = row['与历史平均偏离']
            std_deviation = row['偏离倍数']
            print(f"{i:<4} {date:<12} {shap_value:<12.6f} {deviation:<12.6f} {std_deviation:<10.2f}")

def save_top_shap_analysis_to_file(top_shap_dates, stats, filename='top_shap_values_with_statistics.txt'):
    """
    保存前几大SHAP值的详细分析到文件，包括历史平均值和偏离程度
    :param top_shap_dates: 前n个SHAP值日期
    :param stats: 统计信息
    :param filename: 保存的文件名
    """
    with open(filename, 'w', encoding='utf-8') as f:
        f.write("SHAP贡献值分析报告（包含历史平均值及偏离程度）\n")
        f.write("=" * 80 + "\n")
        
        # 写入每个因子的统计信息
        f.write("\n各因子历史统计信息:\n")
        f.write("-" * 50 + "\n")
        for factor in ['短期动量', '中期动量', '长期动量']:
            f.write(f"\n{factor}:\n")
            f.write(f"  历史平均值: {stats[factor]['mean']:.6f}\n")
            f.write(f"  标准差:     {stats[factor]['std']:.6f}\n")
            f.write(f"  中位数:     {stats[factor]['median']:.6f}\n")
            f.write(f"  最小值:     {stats[factor]['min']:.6f}\n")
            f.write(f"  最大值:     {stats[factor]['max']:.6f}\n")
        
        # 写入前10个SHAP贡献值日期的信息（正向贡献）
        f.write("\n\n各因子SHAP贡献值前10日期（正向贡献）:\n")
        f.write("=" * 80 + "\n")
        
        for factor, dates_df in top_shap_dates['positive'].items():
            f.write(f"\n{factor} 正向贡献:\n")
            f.write("-" * 60 + "\n")
            f.write(f"{'排名':<4} {'日期':<12} {'SHAP值':<12} {'偏离程度':<12} {'偏离倍数':<10}\n")
            f.write("-" * 60 + "\n")
            for i, (_, row) in enumerate(dates_df.iterrows(), 1):
                date = row['date'].strftime('%Y-%m-%d')
                shap_value = row[factor]
                deviation = row['与历史平均偏离']
                std_deviation = row['偏离倍数']
                f.write(f"{i:<4} {date:<12} {shap_value:<12.6f} {deviation:<12.6f} {std_deviation:<10.2f}\n")
        
        # 写入前10个SHAP贡献值日期的信息（负向贡献）
        f.write("\n\n各因子SHAP贡献值前10日期（负向贡献）:\n")
        f.write("=" * 80 + "\n")
        
        for factor, dates_df in top_shap_dates['negative'].items():
            f.write(f"\n{factor} 负向贡献:\n")
            f.write("-" * 60 + "\n")
            f.write(f"{'排名':<4} {'日期':<12} {'SHAP值':<12} {'偏离程度':<12} {'偏离倍数':<10}\n")
            f.write("-" * 60 + "\n")
            for i, (_, row) in enumerate(dates_df.iterrows(), 1):
                date = row['date'].strftime('%Y-%m-%d')
                shap_value = row[factor]
                deviation = row['与历史平均偏离']
                std_deviation = row['偏离倍数']
                f.write(f"{i:<4} {date:<12} {shap_value:<12.6f} {deviation:<12.6f} {std_deviation:<10.2f}\n")
    
    print(f"\n分析报告已保存为 {filename}")

def create_summary_table(top_shap_dates, stats):
    """
    创建包含偏离值信息的汇总表格
    :param top_shap_dates: 前n个SHAP值日期
    :param stats: 统计信息
    :return: 汇总表格数据
    """
    summary_data = []
    
    # 处理正向贡献
    for factor, dates_df in top_shap_dates['positive'].items():
        for i, (_, row) in enumerate(dates_df.iterrows(), 1):
            date = row['date'].strftime('%Y-%m-%d')
            shap_value = row[factor]
            deviation = row['与历史平均偏离']
            std_deviation = row['偏离倍数']
            summary_data.append({
                '因子': factor,
                '方向': '正向',
                '排名': i,
                '日期': date,
                'SHAP值': shap_value,
                '历史平均值': stats[factor]['mean'],
                '偏离值': deviation,
                '偏离倍数': std_deviation
            })
    
    # 处理负向贡献
    for factor, dates_df in top_shap_dates['negative'].items():
        for i, (_, row) in enumerate(dates_df.iterrows(), 1):
            date = row['date'].strftime('%Y-%m-%d')
            shap_value = row[factor]
            deviation = row['与历史平均偏离']
            std_deviation = row['偏离倍数']
            summary_data.append({
                '因子': factor,
                '方向': '负向',
                '排名': i,
                '日期': date,
                'SHAP值': shap_value,
                '历史平均值': stats[factor]['mean'],
                '偏离值': deviation,
                '偏离倍数': std_deviation
            })
    
    return pd.DataFrame(summary_data)

def save_summary_table_to_markdown(top_shap_dates, stats, filename='shap_values_summary_table.md'):
    """
    保存包含偏离值信息的汇总表格到Markdown文件
    :param top_shap_dates: 前n个SHAP值日期
    :param stats: 统计信息
    :param filename: 保存的文件名
    """
    summary_df = create_summary_table(top_shap_dates, stats)
    
    # 按因子和方向分组保存
    with open(filename, 'w', encoding='utf-8') as f:
        f.write("# SHAP贡献值分析汇总表（包含历史平均值及偏离程度）\n\n")
        f.write("## 统计信息\n\n")
        
        # 写入统计信息
        f.write("| 因子 | 历史平均值 | 标准差 | 中位数 | 最小值 | 最大值 |\n")
        f.write("|------|------------|--------|--------|--------|--------|\n")
        for factor in ['短期动量', '中期动量', '长期动量']:
            mean_val = stats[factor]['mean']
            std_val = stats[factor]['std']
            median_val = stats[factor]['median']
            min_val = stats[factor]['min']
            max_val = stats[factor]['max']
            f.write(f"| {factor} | {mean_val:.6f} | {std_val:.6f} | {median_val:.6f} | {min_val:.6f} | {max_val:.6f} |\n")
        
        # 写入正向贡献表格
        f.write("\n## 正向贡献前10日期\n\n")
        for factor in ['短期动量', '中期动量', '长期动量']:
            f.write(f"### {factor} 正向贡献\n\n")
            factor_df = summary_df[(summary_df['因子'] == factor) & (summary_df['方向'] == '正向')]
            f.write("| 排名 | 日期 | SHAP值 | 历史平均值 | 偏离值 | 偏离倍数 |\n")
            f.write("|------|------|--------|------------|--------|----------|\n")
            for _, row in factor_df.iterrows():
                f.write(f"| {row['排名']} | {row['日期']} | {row['SHAP值']:.6f} | {row['历史平均值']:.6f} | {row['偏离值']:.6f} | {row['偏离倍数']:.2f} |\n")
            f.write("\n")
        
        # 写入负向贡献表格
        f.write("## 负向贡献前10日期\n\n")
        for factor in ['短期动量', '中期动量', '长期动量']:
            f.write(f"### {factor} 负向贡献\n\n")
            factor_df = summary_df[(summary_df['因子'] == factor) & (summary_df['方向'] == '负向')]
            f.write("| 排名 | 日期 | SHAP值 | 历史平均值 | 偏离值 | 偏离倍数 |\n")
            f.write("|------|------|--------|------------|--------|----------|\n")
            for _, row in factor_df.iterrows():
                f.write(f"| {row['排名']} | {row['日期']} | {row['SHAP值']:.6f} | {row['历史平均值']:.6f} | {row['偏离值']:.6f} | {row['偏离倍数']:.2f} |\n")
            f.write("\n")
    
    print(f"\n汇总表格已保存为 {filename}")

def plot_top_shap_with_stats(top_shap_dates, stats):
    """
    绘制前几大SHAP值的图表，包含历史平均值和偏离程度
    :param top_shap_dates: 前n个SHAP值日期
    :param stats: 统计信息
    """
    factors = ['短期动量', '中期动量', '长期动量']
    
    # 创建图表
    fig, axes = plt.subplots(3, 2, figsize=(20, 15))
    fig.suptitle('SHAP贡献值前10日期分析（包含历史平均值及偏离程度）', fontsize=16)
    
    colors_positive = {'短期动量': 'red', '中期动量': 'green', '长期动量': 'orange'}
    colors_negative = {'短期动量': 'purple', '中期动量': 'brown', '长期动量': 'pink'}
    
    # 绘制正向贡献图
    for i, factor in enumerate(factors):
        ax = axes[i, 0]
        dates_df = top_shap_dates['positive'][factor]
        
        # 绘制柱状图
        x_pos = range(len(dates_df))
        shap_values = dates_df[factor].values
        deviations = dates_df['与历史平均偏离'].values
        
        bars = ax.bar(x_pos, shap_values, color=colors_positive[factor], alpha=0.7, label=f'{factor} SHAP值')
        
        # 添加历史平均值线
        mean_value = stats[factor]['mean']
        ax.axhline(y=mean_value, color='blue', linestyle='--', linewidth=2, 
                  label=f'{factor} 历史平均值 ({mean_value:.6f})')
        
        # 设置x轴标签
        dates_labels = [date.strftime('%Y-%m-%d') for date in dates_df['date']]
        ax.set_xticks(x_pos)
        ax.set_xticklabels(dates_labels, rotation=45, ha='right')
        
        # 设置标题和标签
        ax.set_title(f'{factor} 正向贡献前10')
        ax.set_ylabel('SHAP贡献值')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # 在柱状图上添加数值标签
        for j, (bar, shap_val, dev_val) in enumerate(zip(bars, shap_values, deviations)):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + 0.0001,
                   f'{shap_val:.4f}\n(偏{dev_val:+.2f}σ)',
                   ha='center', va='bottom', fontsize=8)
    
    # 绘制负向贡献图
    for i, factor in enumerate(factors):
        ax = axes[i, 1]
        dates_df = top_shap_dates['negative'][factor]
        
        # 绘制柱状图
        x_pos = range(len(dates_df))
        shap_values = dates_df[factor].values
        deviations = dates_df['与历史平均偏离'].values
        
        bars = ax.bar(x_pos, shap_values, color=colors_negative[factor], alpha=0.7, label=f'{factor} SHAP值')
        
        # 添加历史平均值线
        mean_value = stats[factor]['mean']
        ax.axhline(y=mean_value, color='blue', linestyle='--', linewidth=2, 
                  label=f'{factor} 历史平均值 ({mean_value:.6f})')
        
        # 设置x轴标签
        dates_labels = [date.strftime('%Y-%m-%d') for date in dates_df['date']]
        ax.set_xticks(x_pos)
        ax.set_xticklabels(dates_labels, rotation=45, ha='right')
        
        # 设置标题和标签
        ax.set_title(f'{factor} 负向贡献前10')
        ax.set_ylabel('SHAP贡献值')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # 在柱状图上添加数值标签
        for j, (bar, shap_val, dev_val) in enumerate(zip(bars, shap_values, deviations)):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height - 0.0001,
                   f'{shap_val:.4f}\n(偏{dev_val:+.2f}σ)',
                   ha='center', va='top', fontsize=8)
    
    # 调整布局
    plt.tight_layout()
    
    # 保存图表
    plt.savefig('top_shap_values_with_statistics.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("\n图表已保存为 top_shap_values_with_statistics.png")

def main():
    """主函数"""
    print("加载数据...")
    shap_df, returns_df = load_data()
    
    print("计算统计信息...")
    stats = calculate_statistics(shap_df)
    
    print("分析前几大SHAP值...")
    top_shap_dates = get_top_shap_dates_with_stats(shap_df, stats, 10)
    
    print("生成分析报告...")
    print_top_shap_analysis(top_shap_dates, stats)
    save_top_shap_analysis_to_file(top_shap_dates, stats)
    save_summary_table_to_markdown(top_shap_dates, stats)
    
    print("\n绘制图表...")
    plot_top_shap_with_stats(top_shap_dates, stats)
    
    print("\n分析完成！")

if __name__ == "__main__":
    main()