import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import shap
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import config
import warnings
warnings.filterwarnings('ignore')

# Set font support for Chinese characters
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


def load_and_prepare_data(index_name='csi800'):
    """
    Load and prepare data
    :param index_name: Index name
    :return: DataFrame
    """
    file_path = f'data/{index_name}_daily_returns.csv'
    df = pd.read_csv(file_path)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    return df


def calculate_momentum_signals(df, short_window=5, medium_window=66, long_window=252):
    """
    Calculate three momentum signals: short-term, medium-term, and long-term
    :param df: DataFrame containing date and return data
    :param short_window: Short-term window size
    :param medium_window: Medium-term window size
    :param long_window: Long-term window size
    :return: DataFrame containing momentum signals
    """
    # Short-term momentum: Absolute return over the past short_window trading days divided by volatility
    short_term_return = df['return'].rolling(window=short_window).sum()
    short_term_volatility = df['return'].rolling(window=short_window).std()
    df['short_momentum'] = short_term_return / short_term_volatility
    
    # Medium-term momentum: Absolute return over the past medium_window trading days divided by volatility
    medium_term_return = df['return'].rolling(window=medium_window).sum()
    medium_term_volatility = df['return'].rolling(window=medium_window).std()
    df['medium_momentum'] = medium_term_return / medium_term_volatility
    
    # Long-term momentum: Absolute return over the past long_window trading days divided by volatility
    long_term_return = df['return'].rolling(window=long_window).sum()
    long_term_volatility = df['return'].rolling(window=long_window).std()
    df['long_momentum'] = long_term_return / long_term_volatility
    
    return df


def create_target_variable(df, future_days=5):
    """
    Create target variable: Return over the next 5 trading days
    :param df: DataFrame containing return data
    :param future_days: Number of future days
    :return: DataFrame containing target variable
    """
    df['future_return'] = df['return'].shift(-future_days).rolling(window=future_days).sum()
    return df


def prepare_features_and_target(df, future_days=5):
    """
    Prepare features and target variable
    :param df: DataFrame containing all data
    :param future_days: Number of future days
    :return: Features and target variable
    """
    # Remove rows containing NaN
    df = df.dropna()
    
    # Select features
    features = ['short_momentum', 'medium_momentum', 'long_momentum']
    X = df[features]
    y = df['future_return']
    
    return X, y, df


def train_model(X, y):
    """
    Train random forest regression model
    :param X: Features
    :param y: Target variable
    :return: Trained model
    """
    # Split training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Create and train model
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    return model, X_train, X_test, y_train, y_test


def get_momentum_contributions_for_date(model, X, date_str, df):
    """
    Given a date, return the contributions of three momentum factors
    :param model: Trained model
    :param X: Feature data
    :param date_str: Date string (format: 'yyyymmdd')
    :param df: DataFrame containing date information
    :return: Contributions of three momentum factors
    """
    # Convert date string to datetime object
    target_date = pd.to_datetime(date_str, format='%Y%m%d')
    
    # Find the closest date index
    date_diff = abs(df['date'] - target_date)
    closest_idx = date_diff.argmin()
    
    # Get feature values for that date
    feature_values = X.iloc[closest_idx].values.reshape(1, -1)
    
    # Use SHAP to calculate contributions
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(feature_values)
    
    # Get feature names
    feature_names = ['Short-term Momentum', 'Medium-term Momentum', 'Long-term Momentum']
    
    # Return contributions
    contributions = dict(zip(feature_names, shap_values[0]))
    
    # Plot waterfall chart
    plot_waterfall(explainer, feature_values, feature_names, shap_values[0], date_str)
    
    return contributions


def plot_waterfall(explainer, feature_values, feature_names, shap_values, date_str):
    """
    Plot SHAP waterfall chart
    :param explainer: SHAP explainer
    :param feature_values: Feature values
    :param feature_names: Feature names
    :param shap_values: SHAP values
    :param date_str: Date string
    :return: None
    """
    # Create SHAP Explanation object
    import shap
    explanation = shap.Explanation(
        values=shap_values,
        base_values=explainer.expected_value,
        data=feature_values[0],
        feature_names=feature_names
    )
    
    # Plot waterfall chart
    shap.waterfall_plot(explanation, show=False)
    plt.title(f'{date_str} Momentum Factor Contribution Waterfall Chart')
    plt.tight_layout()
    plt.savefig(f'momentum_waterfall_{date_str}.png', dpi=300, bbox_inches='tight')
    plt.close()
    print(f"Waterfall chart saved as momentum_waterfall_{date_str}.png")


def plot_momentum_factors_over_time(model, X, df):
    """
    Plot the changes of three momentum factors over time
    :param model: Trained model
    :param X: Feature data
    :param df: DataFrame containing date information
    :return: None
    """
    # Use SHAP to calculate contributions for all samples
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X)
    
    # Create DataFrame to store contributions
    contributions_df = pd.DataFrame(shap_values, columns=['Short-term Momentum', 'Medium-term Momentum', 'Long-term Momentum'])
    contributions_df['date'] = df['date'].iloc[:len(shap_values)].values
    
    # Save contributions to CSV file
    contributions_df.to_csv('momentum_shap_contributions.csv', index=False)
    print("SHAP contributions saved as momentum_shap_contributions.csv")
    
    # Analyze extreme values
    analyze_extreme_values(contributions_df)
    
    # Plot chart
    plt.figure(figsize=(12, 6))
    
    # Plot three lines
    plt.plot(contributions_df['date'], contributions_df['Short-term Momentum'], label='Short-term Momentum', linewidth=1)
    plt.plot(contributions_df['date'], contributions_df['Medium-term Momentum'], label='Medium-term Momentum', linewidth=1)
    plt.plot(contributions_df['date'], contributions_df['Long-term Momentum'], label='Long-term Momentum', linewidth=1)
    
    # Add title and labels
    plt.title('Changes of Three Momentum Factors Over Time')
    plt.xlabel('Date')
    plt.ylabel('SHAP Contribution')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Save chart
    plt.savefig('momentum_factors_over_time.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("Momentum factor change chart saved as momentum_factors_over_time.png")


def analyze_momentum_contributions(date_str):
    """
    Analyze contributions of three momentum factors for a specified date
    :param date_str: Date string (format: 'yyyymmdd')
    :return: Dictionary of three momentum factor contributions
    """
    print("Loading and preparing data...")
    df = load_and_prepare_data(config.INDEX_NAME)
    
    print("Calculating momentum signals...")
    df = calculate_momentum_signals(df)
    
    print("Creating target variable...")
    df = create_target_variable(df, config.FUTURE_DAYS)
    
    print("Preparing features and target variable...")
    X, y, df = prepare_features_and_target(df, config.FUTURE_DAYS)
    
    print("Training model...")
    model, X_train, X_test, y_train, y_test = train_model(X, y)
    
    print(f"\nGetting momentum contributions for {date_str}...")
    contributions = get_momentum_contributions_for_date(model, X, date_str, df)
    for factor, contribution in contributions.items():
        print(f"{factor}: {contribution:.6f}")
    
    return contributions


def analyze_momentum_change_around_date(date_str):
    """
    Analyze changes in momentum factors before and after a specified date
    :param date_str: Date string (format: 'yyyymmdd')
    :return: None
    """
    print("Loading and preparing data...")
    df = load_and_prepare_data(config.INDEX_NAME)
    
    print("Calculating momentum signals...")
    df = calculate_momentum_signals(df)
    
    print("Creating target variable...")
    df = create_target_variable(df, config.FUTURE_DAYS)
    
    print("Preparing features and target variable...")
    X, y, df = prepare_features_and_target(df, config.FUTURE_DAYS)
    
    print("Training model...")
    model, X_train, X_test, y_train, y_test = train_model(X, y)
    
    # Convert date string to datetime object
    target_date = pd.to_datetime(date_str, format='%Y%m%d')
    
    # Find the index of target date
    date_diff = abs(df['date'] - target_date)
    target_idx = date_diff.argmin()
    
    # Determine analysis time range
    # Past month (about 22 trading days)
    start_idx = max(0, target_idx - 22)
    # Next 5 trading days
    end_idx = min(len(df), target_idx + 5)
    
    # Get data within analysis range
    analysis_df = df.iloc[start_idx:end_idx].copy()
    analysis_X = X.iloc[start_idx:end_idx]
    
    # Use SHAP to calculate contributions for all samples
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(analysis_X)
    
    # Create DataFrame to store contributions
    contributions_df = pd.DataFrame(shap_values, columns=['Short-term Momentum', 'Medium-term Momentum', 'Long-term Momentum'])
    contributions_df['date'] = analysis_df['date'].values
    
    # Find the index of target date within analysis range
    target_in_analysis = abs(contributions_df['date'] - target_date).argmin()
    
    # Calculate average contributions for past month
    past_month_contributions = contributions_df.iloc[:target_in_analysis+1][['Short-term Momentum', 'Medium-term Momentum', 'Long-term Momentum']].mean()
    
    # Calculate average contributions for next 5 trading days
    future_5_contributions = contributions_df.iloc[target_in_analysis:][['Short-term Momentum', 'Medium-term Momentum', 'Long-term Momentum']].mean()
    
    # Create comparison data
    comparison_data = pd.DataFrame({
        'Past Month': past_month_contributions,
        'Next 5 Trading Days': future_5_contributions
    })
    
    # Plot comparison chart
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))
    
    # First subplot: Bar chart comparison
    comparison_data.plot(kind='bar', ax=ax1, color=['skyblue', 'lightcoral'])
    ax1.set_title(f'{date_str} Momentum Factor Contribution Changes Before and After')
    ax1.set_xlabel('Momentum Factors')
    ax1.set_ylabel('Average SHAP Contribution')
    ax1.set_xticklabels(ax1.get_xticklabels(), rotation=45)
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    # Add value labels on bar chart
    for container in ax1.containers:
        ax1.bar_label(container, fmt='%.4f', padding=3)
    
    # Second subplot: Time series chart
    contributions_df.plot(x='date', y=['Short-term Momentum', 'Medium-term Momentum', 'Long-term Momentum'], ax=ax2)
    ax2.axvline(x=contributions_df['date'].iloc[target_in_analysis], color='red', linestyle='--', linewidth=1, label=f'Target Date ({date_str})')
    ax2.set_title(f'{date_str} Momentum Factor Contribution Time Series')
    ax2.set_xlabel('Date')
    ax2.set_ylabel('SHAP Contribution')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    # Format date display
    fig.autofmt_xdate()
    
    plt.tight_layout()
    plt.savefig(f'momentum_change_around_{date_str}.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"Momentum factor change chart saved as momentum_change_around_{date_str}.png")
    
    # Print detailed information
    print(f"\n{date_str} Momentum Factor Contribution Change Analysis:")
    print("\nAverage contributions for past month:")
    for factor, value in past_month_contributions.items():
        print(f"  {factor}: {value:.6f}")
    
    print("\nAverage contributions for next 5 trading days:")
    for factor, value in future_5_contributions.items():
        print(f"  {factor}: {value:.6f}")
    
    # Calculate changes
    change = future_5_contributions - past_month_contributions
    print("\nChanges (Next 5 Trading Days - Past Month):")
    for factor, value in change.items():
        print(f"  {factor}: {value:.6f}")


def analyze_extreme_values(contributions_df):
    """
    Analyze extreme values of SHAP contributions
    :param contributions_df: DataFrame containing SHAP contributions
    :return: None
    """
    print("\nAnalyzing extreme values of SHAP contributions...")
    
    # Calculate 1% and 99% percentiles for each momentum factor
    percentiles = [0.01, 0.99]
    
    for column in ['Short-term Momentum', 'Medium-term Momentum', 'Long-term Momentum']:
        values = contributions_df[column]
        lower_percentile, upper_percentile = np.percentile(values, [p * 100 for p in percentiles])
        
        # Find extreme values below 1% percentile and above 99% percentile
        lower_extremes = contributions_df[contributions_df[column] < lower_percentile]
        upper_extremes = contributions_df[contributions_df[column] > upper_percentile]
        
        print(f"\nExtreme value analysis for {column}:")
        print(f"1% percentile: {lower_percentile:.6f}")
        print(f"99% percentile: {upper_percentile:.6f}")
        print(f"Number of dates below 1% percentile: {len(lower_extremes)}")
        print(f"Number of dates above 99% percentile: {len(upper_extremes)}")
        
        # Display top 5 extreme values
        if len(lower_extremes) > 0:
            print("\n5 lowest values:")
            print(lower_extremes.nsmallest(5, column)[['date', column]])
        
        if len(upper_extremes) > 0:
            print("\n5 highest values:")
            print(upper_extremes.nlargest(5, column)[['date', column]])
    
    print("\nExtreme value analysis completed!")


def plot_momentum_factors():
    """
    Plot the changes of three momentum factors over time
    :return: None
    """
    print("Loading and preparing data...")
    df = load_and_prepare_data(config.INDEX_NAME)
    
    print("Calculating momentum signals...")
    df = calculate_momentum_signals(df)
    
    print("Creating target variable...")
    df = create_target_variable(df, config.FUTURE_DAYS)
    
    print("Preparing features and target variable...")
    X, y, df = prepare_features_and_target(df, config.FUTURE_DAYS)
    
    print("Training model...")
    model, X_train, X_test, y_train, y_test = train_model(X, y)
    
    print("\nPlotting momentum factors changes over time...")
    plot_momentum_factors_over_time(model, X, df)


def main():
    """
    Main function
    """
    import sys
    
    if len(sys.argv) > 1:
        # Check for special commands
        if sys.argv[1] == '--around-date' and len(sys.argv) > 2:
            # Analyze momentum factor changes before and after specified date
            date_str = sys.argv[2]
            analyze_momentum_change_around_date(date_str)
        else:
            # If date parameter is provided, analyze contributions for specified date
            date_str = sys.argv[1]
            analyze_momentum_contributions(date_str)
    else:
        # Default behavior: Analyze contributions and plot
        # Example: Get contributions for a specific date
        # Note: This uses an example date, which should be replaced with a valid date in actual use
        example_date = '20230101'
        analyze_momentum_contributions(example_date)
        
        # Plot momentum factors changes over time
        plot_momentum_factors()
        
        print("\nSHAP analysis completed!")


if __name__ == "__main__":
    main()