"""
Configuration file
"""

# Index configuration
INDEX_NAME = 'csi800'  # Options: 'hs300' or 'csi800'

# Prediction configuration
FUTURE_DAYS = 5