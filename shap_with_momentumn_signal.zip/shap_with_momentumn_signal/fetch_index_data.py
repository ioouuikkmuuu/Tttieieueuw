import tushare as ts
import pandas as pd
import numpy as np
from datetime import datetime

# Set Tushare API token (need to register on Tushare website to get)
# Please visit https://tushare.pro/ to register an account and get token
ts.set_token('2876ea85cb005fb5fa17c809a98174f2d5aae8b1f830110a5ead6211')
pro = ts.pro_api()

# Note: The following code requires a valid Tushare token to run

def generate_sample_data():
    """Generate sample data to demonstrate CSV file format"""
    # Generate date sequence from December 2015 to current date
    start_date = '2015-12-01'
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    # Create date range
    dates = pd.date_range(start=start_date, end=end_date, freq='D')
    dates = dates[dates.weekday < 5]  # Keep only weekdays
    
    # Generate simulated return data for HS300 and CSI800
    n_days = len(dates)
    hs300_returns = pd.Series(
        data=np.random.normal(0, 0.02, n_days),  # Normal distribution with mean 0 and standard deviation 2%
        index=dates,
        name='hs300_return'
    )
    
    cs800_returns = pd.Series(
        data=np.random.normal(0, 0.02, n_days),  # Normal distribution with mean 0 and standard deviation 2%
        index=dates,
        name='cs800_return'
    )
    
    # Merge data
    df = pd.DataFrame({
        'date': dates,
        'hs300_return': hs300_returns.values,
        'cs800_return': cs800_returns.values
    })
    
    return df

def fetch_hs300_data():
    """Fetch HS300 index data (requires valid Tushare token)"""
    # Get HS300 index data
    # Set end date to today
    end_date = datetime.now().strftime('%Y%m%d')
    hs300 = pro.index_daily(ts_code='000300.SH', start_date='20151201', end_date=end_date)
    
    # Print last few rows of original data to check for future dates
    print("Last 5 rows of HS300 original data:")
    print(hs300[['trade_date', 'close']].tail())
    
    # Convert date format
    hs300['date_obj'] = pd.to_datetime(hs300['trade_date'], format='%Y%m%d')
    
    # Filter out future date data
    today = pd.to_datetime('today').date()
    print("Today's date:", today)
    print("Maximum date in HS300 data:", hs300['date_obj'].max().date())
    print("Number of HS300 data entries before filtering:", len(hs300))
    # Ensure filtering condition is correctly applied
    hs300_filtered = hs300[hs300['date_obj'].dt.date <= today].copy()
    print("Number of HS300 data entries after filtering:", len(hs300_filtered))
    # Check filtered data
    print("Maximum date in filtered HS300 data:", hs300_filtered['date_obj'].max().date())
    hs300 = hs300_filtered
    
    # Calculate daily returns
    hs300.sort_values('trade_date', inplace=True)
    hs300['return'] = hs300['close'].pct_change()
    hs300['date'] = pd.to_datetime(hs300['trade_date'], format='%Y%m%d')
    hs300 = hs300[['date', 'return']]
    print("Last 5 rows of HS300 data after date conversion (before sorting):")
    print(hs300.tail())
    print("First 5 rows of HS300 data after date conversion (before sorting):")
    print(hs300.head())
    
    # Sort by date
    hs300.sort_values('date', inplace=True)
    print("Last 5 rows of HS300 data after sorting:")
    print(hs300.tail())
    print("First 5 rows of HS300 data after sorting:")
    print(hs300.head())
    
    return hs300

def fetch_csi800_data():
    """Fetch CSI800 index data (requires valid Tushare token)"""
    # Get CSI800 index data
    # Set end date to today
    end_date = datetime.now().strftime('%Y%m%d')
    csi800 = pro.index_daily(ts_code='000906.SH', start_date='20151201', end_date=end_date)
    
    # Print last few rows of original data to check for future dates
    print("Last 5 rows of CSI800 original data:")
    print(csi800[['trade_date', 'close']].tail())
    
    # Convert date format
    csi800['date_obj'] = pd.to_datetime(csi800['trade_date'], format='%Y%m%d')
    
    # Filter out future date data
    today = pd.to_datetime('today').date()
    print("Today's date:", today)
    print("Maximum date in CSI800 data:", csi800['date_obj'].max().date())
    print("Number of CSI800 data entries before filtering:", len(csi800))
    # Ensure filtering condition is correctly applied
    csi800_filtered = csi800[csi800['date_obj'].dt.date <= today].copy()
    print("Number of CSI800 data entries after filtering:", len(csi800_filtered))
    # Check filtered data
    print("Maximum date in filtered CSI800 data:", csi800_filtered['date_obj'].max().date())
    csi800 = csi800_filtered
    
    # Calculate daily returns
    csi800.sort_values('trade_date', inplace=True)
    csi800['return'] = csi800['close'].pct_change()
    csi800['date'] = pd.to_datetime(csi800['trade_date'], format='%Y%m%d')
    csi800 = csi800[['date', 'return']]
    print("Last 5 rows of CSI800 data after date conversion (before sorting):")
    print(csi800.tail())
    print("First 5 rows of CSI800 data after date conversion (before sorting):")
    print(csi800.head())
    
    # Sort by date
    csi800.sort_values('date', inplace=True)
    print("Last 5 rows of CSI800 data after sorting:")
    print(csi800.tail())
    print("First 5 rows of CSI800 data after sorting:")
    print(csi800.head())
    
    return csi800

def save_to_csv(df, filename):
    """Save data to CSV file"""
    df.to_csv(filename, index=False)
    print(f"Data saved to {filename}")

if __name__ == "__main__":
    # Get HS300 data
    hs300_data = fetch_hs300_data()
    
    # Save HS300 data to CSV file
    save_to_csv(hs300_data, 'data/hs300_daily_returns.csv')
    
    # Get CSI800 data
    csi800_data = fetch_csi800_data()
    
    # Save CSI800 data to CSV file
    save_to_csv(csi800_data, 'data/csi800_daily_returns.csv')