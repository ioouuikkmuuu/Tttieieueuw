import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
import warnings
import sys
warnings.filterwarnings('ignore')

# Import configuration
import config


def load_data(index_name='hs300'):
    """
    Load index data
    :param index_name: Index name, 'hs300' or 'csi800'
    :return: DataFrame
    """
    file_path = f'data/{index_name}_daily_returns.csv'
    df = pd.read_csv(file_path)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    return df


def calculate_momentum_signals(df, short_window=5, medium_window=66, long_window=252):
    """
    Calculate three momentum signals: short-term, medium-term, and long-term
    :param df: DataFrame containing date and return data
    :param short_window: Short-term window size
    :param medium_window: Medium-term window size
    :param long_window: Long-term window size
    :return: DataFrame containing momentum signals
    """
    # Short-term momentum: Absolute return over the past short_window trading days divided by volatility
    short_term_return = df['return'].rolling(window=short_window).sum()
    short_term_volatility = df['return'].rolling(window=short_window).std()
    df['short_momentum'] = short_term_return / short_term_volatility
    
    # Medium-term momentum: Absolute return over the past medium_window trading days divided by volatility
    medium_term_return = df['return'].rolling(window=medium_window).sum()
    medium_term_volatility = df['return'].rolling(window=medium_window).std()
    df['medium_momentum'] = medium_term_return / medium_term_volatility
    
    # Long-term momentum: Absolute return over the past long_window trading days divided by volatility
    long_term_return = df['return'].rolling(window=long_window).sum()
    long_term_volatility = df['return'].rolling(window=long_window).std()
    df['long_momentum'] = long_term_return / long_term_volatility
    
    return df


def create_target_variable(df, future_days=5):
    """
    Create target variable: Return over the next 5 trading days
    :param df: DataFrame containing return data
    :param future_days: Number of future days
    :return: DataFrame containing target variable
    """
    df['future_return'] = df['return'].shift(-future_days).rolling(window=future_days).sum()
    return df


def prepare_features_and_target(df, future_days=5):
    """
    Prepare features and target variable
    :param df: DataFrame containing all data
    :param future_days: Number of future days
    :return: Features and target variable
    """
    # Remove rows containing NaN
    df = df.dropna()
    
    # Select features
    features = ['short_momentum', 'medium_momentum', 'long_momentum']
    X = df[features]
    y = df['future_return']
    
    return X, y


def train_model(X, y):
    """
    Train random forest regression model
    :param X: Features
    :param y: Target variable
    :return: Trained model
    """
    # Split training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Create and train model
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    # Predict
    y_pred = model.predict(X_test)
    
    # Calculate mean squared error
    mse = mean_squared_error(y_test, y_pred)
    print(f"Model mean squared error: {mse}")
    
    return model, X_test, y_test, y_pred


def calculate_information_ratio(y_true, y_pred):
    """
    Calculate information ratio (IR)
    :param y_true: True values
    :param y_pred: Predicted values
    :return: Information ratio
    """
    # Calculate prediction errors
    residuals = y_true - y_pred
    
    # Calculate mean error
    mean_residual = np.mean(residuals)
    
    # Calculate standard deviation of errors
    std_residual = np.std(residuals)
    
    # Calculate information ratio
    if std_residual != 0:
        ir = mean_residual / std_residual
    else:
        ir = 0
    
    return ir


def optimize_momentum_parameters(df, future_days=5):
    """
    Optimize momentum signal parameters to maximize information ratio
    :param df: DataFrame containing return data
    :param future_days: Number of future days
    :return: Best parameter combination and corresponding IR value
    """
    best_ir = -np.inf
    best_params = None
    
    # Define parameter search range
    short_windows = [3, 5, 10]
    medium_windows = [20, 66, 120]
    long_windows = [120, 252, 300]
    
    total_combinations = len(short_windows) * len(medium_windows) * len(long_windows)
    print(f"Starting parameter optimization, need to test {total_combinations} combinations...")
    
    count = 0
    for short_window in short_windows:
        for medium_window in medium_windows:
            for long_window in long_windows:
                # Ensure window sizes are increasing
                if short_window < medium_window < long_window:
                    count += 1
                    print(f"Testing parameter combination {count}/{total_combinations}: Short={short_window}, Medium={medium_window}, Long={long_window}")
                    
                    # Copy data to avoid modifying original data
                    df_copy = df.copy()
                    
                    # Calculate momentum signals
                    df_copy = calculate_momentum_signals(df_copy, short_window, medium_window, long_window)
                    
                    # Create target variable
                    df_copy = create_target_variable(df_copy, future_days)
                    
                    # Prepare features and target variable
                    X, y = prepare_features_and_target(df_copy, future_days)
                    
                    # Skip this parameter combination if data is insufficient
                    if len(X) < 10:
                        continue
                    
                    # Split training and testing sets
                    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
                    
                    # Train model
                    model = RandomForestRegressor(n_estimators=100, random_state=42)
                    model.fit(X_train, y_train)
                    
                    # Predict
                    y_pred = model.predict(X_test)
                    
                    # Calculate information ratio
                    ir = calculate_information_ratio(y_test, y_pred)
                    
                    # Update best parameters
                    if ir > best_ir:
                        best_ir = ir
                        best_params = (short_window, medium_window, long_window)
                        print(f"Found better parameter combination: Short={short_window}, Medium={medium_window}, Long={long_window}, IR={ir}")
    
    return best_params, best_ir


def main():
    """
    Main function
    """
    # Load data
    print("Loading data...")
    df = load_data(config.INDEX_NAME)
    
    # Optimize momentum signal parameters
    print("Optimizing momentum signal parameters...")
    best_params, best_ir = optimize_momentum_parameters(df, config.FUTURE_DAYS)
    
    if best_params:
        short_window, medium_window, long_window = best_params
        print(f"\nBest parameter combination:")
        print(f"Short-term window: {short_window}")
        print(f"Medium-term window: {medium_window}")
        print(f"Long-term window: {long_window}")
        print(f"Best IR value: {best_ir}")
        
        # Recalculate momentum signals using best parameters
        print("\nRecalculating momentum signals using best parameters...")
        df = calculate_momentum_signals(df, short_window, medium_window, long_window)
        
        # Create target variable
        print("Creating target variable...")
        df = create_target_variable(df, config.FUTURE_DAYS)
        
        # Prepare features and target variable
        print("Preparing features and target variable...")
        X, y = prepare_features_and_target(df, config.FUTURE_DAYS)
        
        # Train model
        print("Training model...")
        model, X_test, y_test, y_pred = train_model(X, y)
        
        # Calculate information ratio
        print("Calculating information ratio...")
        ir = calculate_information_ratio(y_test, y_pred)
        print(f"Model information ratio (IR): {ir}")
        
        # Output feature importance
        feature_names = ['Short-term Momentum', 'Medium-term Momentum', 'Long-term Momentum']
        importances = model.feature_importances_
        print("\nFeature importance:")
        for name, importance in zip(feature_names, importances):
            print(f"{name}: {importance}")
    else:
        print("Could not find valid parameter combinations")


if __name__ == "__main__":
    main()