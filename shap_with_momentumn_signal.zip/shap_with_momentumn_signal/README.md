# SHAP Momentum Factor Analysis Tool

This tool uses the SHAP explainer to analyze momentum factors based on predictive model results, implementing the following functions:

1. Given any date (format: yyyymmdd), returns the contributions of three momentum factors
2. Plots the changes of three momentum factors over time
3. Generates a SHAP contribution waterfall chart for a specified date

## Usage

### 1. Analyze momentum contributions for a specified date

```bash
python shap_analysis.py 20230101
```

This will output the SHAP contributions of three momentum factors (short-term, medium-term, long-term) for the specified date.

### 2. Plot momentum factors changes over time

```bash
python shap_analysis.py
```

This will generate a chart file named `momentum_factors_over_time.png`, showing the changes in SHAP contributions of three momentum factors over time.

At the same time, the program will also save the daily SHAP contributions as a CSV file `momentum_shap_contributions.csv`, and analyze extreme values (1% and 99% percentiles).

### 3. Generate SHAP contribution waterfall chart for a specified date

When using the first method to analyze momentum contributions for a specified date, the program will automatically generate a SHAP contribution waterfall chart with the filename `momentum_waterfall_yyyymmdd.png`.

For example, execute the following command:

```bash
python shap_analysis.py 20240924
```

In addition to outputting contribution values to the console, a waterfall chart file named `momentum_waterfall_20240924.png` will also be generated.

### 4. Analyze changes in momentum factors before and after a specified date

Using the `--around-date` parameter, you can analyze changes in momentum factors before and after a specified date, comparing the average SHAP contributions of the past month and the next 5 trading days.

```bash
python shap_analysis.py --around-date 20240924
```

This will generate a chart file named `momentum_change_around_20240924.png`, showing changes in momentum factor contributions before and after the specified date. The chart contains two subplots:

1. Bar chart comparison: Shows the comparison of average SHAP contributions between the past month and the next 5 trading days
2. Time series chart: Shows the time series changes of momentum factor contributions before and after the specified date

## Dependencies

- pandas
- numpy
- matplotlib
- shap
- scikit-learn

## Configuration

The following parameters can be modified in the configuration file `config.py`:

- `INDEX_NAME`: Select index name ('hs300' or 'csi800')
- `FUTURE_DAYS`: Predict returns for how many days in the future

## Output Files

- `momentum_factors_over_time.png`: SHAP contribution chart of momentum factors over time
- `momentum_waterfall_yyyymmdd.png`: SHAP contribution waterfall chart for a specified date
- `momentum_shap_contributions.csv`: Daily SHAP contribution data, including extreme value analysis results
- `momentum_change_around_yyyymmdd.png`: Comparison chart of momentum factor contribution changes before and after a specified date

## Implementation Principles

1. Calculate three momentum factors (short-term, medium-term, long-term) using historical data
2. Train a random forest regression model to predict future returns
3. Use the SHAP explainer to analyze model prediction results and calculate factor contributions
4. Provide chart visualization and specified date analysis functions
5. Analyze changes in momentum factors before and after a specified date, comparing average SHAP contributions of the past month and the next 5 trading days

## What is SHAP and Its Applications in Investment

SHAP (SHapley Additive exPlanations) is a machine learning model explanation method based on game theory. It provides a unified, interpretable model explanation framework by calculating each feature's contribution to the model's prediction results.

In the investment field, SHAP can help us:

1. Understand model decisions: Explain why the model makes a certain prediction, increasing the transparency of investment decisions
2. Factor analysis: Quantify the contributions of different factors (such as momentum factors) to return predictions
3. Risk management: Identify factors that have the greatest impact on prediction results, helping to assess model risks
4. Strategy optimization: Optimize investment strategies and factor allocation by analyzing factor contributions

## Random Forest Model Principles and Reasons for Use

Random forest is an ensemble learning method that improves model accuracy and stability by building multiple decision trees and combining their prediction results.

Main advantages of random forest models:

1. High accuracy: Reduces overfitting risk by integrating multiple decision trees
2. Strong robustness: Has good tolerance for noisy data and outliers
3. Feature importance evaluation: Can provide feature importance ranking
4. Handling nonlinear relationships: Can capture complex nonlinear relationships between features
5. Suitable for financial data: Financial data usually has nonlinear and high-dimensional characteristics, making random forests very suitable for handling this type of data

Reasons we chose the random forest model:

1. Good predictive performance: Performs excellently in financial time series prediction
2. Interpretability: When used with SHAP, can provide clear model explanations
3. Stability: Can maintain relatively stable performance in different market environments
4. Easy to implement: Has mature library support, making implementation relatively simple

## Investment Value of the Project

This project analyzes momentum factor contributions through SHAP, providing the following value for investment decisions:

1. Factor effectiveness validation: Quantitatively validates the effectiveness of momentum factors with different time windows
2. Strategy optimization: Helps investors select optimal momentum factor parameter combinations
3. Decision support: Provides intuitive visualization charts to assist investment decisions
4. Risk control: Timely identifies market risk signals by analyzing factor contribution changes
5. Backtesting framework: Provides a backtesting foundation for building investment strategies based on momentum factors