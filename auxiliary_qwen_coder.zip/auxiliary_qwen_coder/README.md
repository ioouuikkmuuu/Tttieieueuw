# 模拟数据生成与投资组合管理系统

这是一个完整的投资组合分析系统，包含以下功能：
1. 生成模拟交易数据或使用申万行业每日收益率真实数据（默认）
2. 计算行业排名
3. 管理不同类型的投资组合
4. 执行调仓逻辑
5. 可视化结果并计算信息比率(IR)

## 项目结构

- `data_processing/`: 数据处理模块
  - `data_generator.py`: 模拟数据生成器
  - `date_utils.py`: 日期处理工具
- `portfolio_management/`: 投资组合管理模块
  - `portfolio.py`: 投资组合类定义
  - `simulation.py`: 模拟交易引擎
- `visualization/`: 可视化模块
  - `plotting.py`: 图表绘制和指标计算
- `data/`: 存储生成的模拟数据
- `results/`: 存储模拟结果和图表

## 安装依赖

```bash
pip install -r requirements.txt
```

## 使用方法

1. 生成模拟数据或使用申万行业每日收益率真实数据（默认）：
```bash
python main.py
```

系统默认使用申万行业每日收益率真实数据。如果需要使用模拟数据，可以修改 `main.py` 文件中的 `generate_simulated_data(use_sw_data=True)` 为 `generate_simulated_data(use_sw_data=False)`。

2. 获取申万一级行业真实数据：
```bash
python -m data_processing.sw_industry_data
```

注意：此功能使用akshare库获取申万行业指数数据。

3. 运行模拟交易：
```bash
python -m portfolio_management.simulation
```

4. 查看模拟结果：
```bash
python -m portfolio_management.simulation --show-results
```

5. 生成可视化图表：
```bash
python -m visualization.plotting
```

6. 使用 Jupyter Notebook：
```bash
jupyter notebook portfolio_analysis.ipynb
```

7. 测试Tushare数据获取（需要有效token）：
```bash
python test_sw_data.py
```
请在运行前编辑 `test_sw_data.py` 文件，填入您的Tushare token。

8. 获取申万一级行业每日收益率数据（需要有效token）：
```bash
python -m data_processing.fetch_sw_industry_data
```
该脚本会获取申万一级行业指数的每日收益率数据，并将行业作为列，日期作为索引保存到 `sw_industry_daily_return.csv` 文件中。

### 高级可视化选项

可视化模块支持两种绘图引擎：matplotlib（默认）和 plotly。您可以通过修改 `visualization/plotting.py` 文件中的主函数调用来选择不同的引擎：

```python
# 使用 matplotlib（默认）
plot_cumulative_returns()

# 使用 plotly
plot_cumulative_returns(engine='plotly')

# 绘制特定的投资组合
plot_cumulative_returns(portfolios=["Long Only", "Benchmark"], engine='matplotlib')

# 绘制 Long/Short 组合的多头和空头部分
plot_long_short_components(engine='plotly')
```

支持绘制的投资组合类型：
- **Long Only**: 多头策略组合
- **Long/Short**: 多空策略组合
- **Benchmark**: 基准策略组合
- **Long Component**: Long/Short 组合的多头部分
- **Short Component**: Long/Short 组合的空头部分

## Jupyter Notebook 说明

为了更方便地探索和可视化数据，我们提供了一个 Jupyter Notebook (`portfolio_analysis.ipynb`)，其中包含了完整的项目介绍、安装说明、使用方法和可视化示例。您可以直接运行这个 notebook 来体验项目的各项功能。

## 功能说明

### 投资组合类型
- **Long Only**: 多头策略，买入排名前5的行业
- **Long/Short**: 多空策略，买入排名前5的行业，卖出排名后5的行业
- **Benchmark**: 基准策略，等权重持有所有行业

### 调仓逻辑
- **调仓基准日**: 月末最后一个工作日
- **调仓准备日**: 月初第一个交易日
- **调仓生效日**: 调仓准备日的下一个交易日

在调仓准备日收盘时进行调仓操作，调仓后的持仓在调仓生效日开始生效。