import pandas as pd
import numpy as np
from datetime import datetime
import warnings
import logging
import os

# 创建logs目录
logs_dir = 'logs'
if not os.path.exists(logs_dir):
    os.makedirs(logs_dir)

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(logs_dir, 'portfolio.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

warnings.filterwarnings('ignore')

class Portfolio:
    def __init__(self, name, initial_cash=1000000, portfolio_type='long_only'):
        """
        初始化投资组合
        
        参数:
        name: 投资组合名称
        initial_cash: 初始资金
        portfolio_type: 投资组合类型 ('long_only', 'long_short', 'benchmark')
        """
        self.name = name
        self.initial_cash = initial_cash
        self.portfolio_type = portfolio_type
        
        # 持仓信息
        self.cash = initial_cash
        self.position = {}  # 格式: {行业: 金额}
        self.date = None
        self.IR = 0.0
        self.return_rate = 0.0
        self.NAV = initial_cash  # 净资产价值
        
        # 历史记录
        self.nav_history = []  # 格式: [(日期, NAV)]
        self.position_history = []  # 格式: [(日期, 持仓)]
        self.return_history = []  # 格式: [(日期, 收益率)]
        self.rebalancing_history = []  # 调仓历史
        
        # 标记是否为特殊日期
        self.is_special_date = False
        self.date_type = None
        
        # 排名信息
        self.rank = None
    
    def update_position(self, date, returns_df, rank_scores=None, rebalance=False, m=5, n=5):
        """
        更新持仓
        
        参数:
        date: 当前日期
        returns_df: 收益率数据
        rank_scores: 排名分数
        rebalance: 是否需要调仓
        m: long的行业数量
        n: short的行业数量
        """
        self.date = date
        
        # 记录调仓前的NAV
        previous_NAV = self.NAV
        
        # 如果是调仓基准日，记录排名信息
        if rebalance and rank_scores is not None and date in rank_scores.index:
            self.rank = rank_scores.loc[date].to_dict()
        
        # 如果需要调仓，执行调仓逻辑
        if rebalance:
            logger.info(f"[{self.name}] {date.date()} - 开始调仓操作")
            self._rebalance_portfolio(returns_df, rank_scores, m, n)
        
        # 计算当日收益
        self._calculate_daily_return(returns_df)
        
        # 更新NAV历史记录
        self.nav_history.append((date, self.NAV))
        
        # 更新持仓历史记录
        self.position_history.append((date, self.position.copy()))
        
        # 更新收益率历史记录
        self.return_history.append((date, self.return_rate))
    
    def _rebalance_portfolio(self, returns_df, rank_scores, m, n):
        """
        执行调仓逻辑
        """
        if self.date not in rank_scores.index:
            logger.warning(f"[{self.name}] {self.date} 不在排名数据中，无法调仓")
            return
        
        # 记录调仓前的持仓
        previous_position = self.position.copy()
        previous_cash = self.cash
        
        # 获取当前日期的排名
        current_rank = rank_scores.loc[self.date]
        
        # 根据投资组合类型进行调仓
        if self.portfolio_type == 'long_only':
            # 多头策略：买入排名前m的行业
            top_industries = current_rank.nsmallest(m).index.tolist()  # 排名越小越好
            logger.info(f"[{self.name}] {self.date.date()} - 多头策略，选择行业: {', '.join(top_industries)}")
            self._allocate_long_positions(top_industries)
        elif self.portfolio_type == 'long_short':
            # 多空策略：买入排名前m的行业，卖出排名后n的行业
            top_industries = current_rank.nsmallest(m).index.tolist()
            bottom_industries = current_rank.nlargest(n).index.tolist()
            logger.info(f"[{self.name}] {self.date.date()} - 多空策略，做多行业: {', '.join(top_industries)}，做空行业: {', '.join(bottom_industries)}")
            self._allocate_long_short_positions(top_industries, bottom_industries)
        elif self.portfolio_type == 'benchmark':
            # 基准策略：等权重持有所有行业
            all_industries = returns_df.columns.tolist()
            logger.info(f"[{self.name}] {self.date.date()} - 基准策略，持有所有 {len(all_industries)} 个行业")
            self._allocate_benchmark_positions(all_industries)
        
        # 记录调仓信息
        rebalancing_record = {
            'date': self.date,
            'previous_position': previous_position,
            'previous_cash': previous_cash,
            'new_position': self.position.copy(),
            'new_cash': self.cash,
            'type': self.portfolio_type
        }
        self.rebalancing_history.append(rebalancing_record)
        
        logger.info(f"[{self.name}] {self.date.date()} - 调仓完成，现金: {self.cash:.2f}")
    
    def _allocate_long_positions(self, industries):
        """
        分配多头持仓
        """
        # 清空现有持仓，将所有资产转为现金
        previous_position_value = sum(self.position.values())
        self.cash += previous_position_value
        previous_position = self.position.copy()
        self.position = {}
        
        logger.info(f"[{self.name}] 调仓前持仓: {previous_position}, 总值: {previous_position_value:.2f}")
        
        # 等权重分配到指定行业
        if industries:
            allocation_per_industry = self.cash / len(industries)
            for industry in industries:
                self.position[industry] = allocation_per_industry
            self.cash = 0.0
            
            logger.info(f"[{self.name}] 调仓后持仓: {self.position}")
    
    def _allocate_long_short_positions(self, long_industries, short_industries):
        """
        分配多空持仓
        """
        # 清空现有持仓，将所有资产转为现金
        # 对于多头仓位，直接加到现金中
        # 对于空头仓位，由于是无成本做空，只将损益部分加到现金中
        previous_position_value = 0
        for industry, position in self.position.items():
            if position > 0:  # 多头仓位
                previous_position_value += position
            else:  # 空头仓位，只计算损益部分
                # 空头仓位的损益 = -position * daily_return
                # 由于在调仓时没有具体的daily_return，我们假设损益为0
                # 因此不加任何值到previous_position_value中
                pass
        self.cash += previous_position_value
        previous_position = self.position.copy()
        self.position = {}
        
        logger.info(f"[{self.name}] 调仓前持仓: {previous_position}, 总值: {previous_position_value:.2f}")
        
        # 计算多头和空头的分配金额
        total_cash = self.cash
        if long_industries:
            long_allocation = total_cash / 2  # 一半资金用于多头
            short_allocation = total_cash / 2  # 一半资金用于空头（作为保证金）
            
            # 分配多头仓位
            allocation_per_long = long_allocation / len(long_industries)
            for industry in long_industries:
                self.position[industry] = allocation_per_long
            
            # 更新现金余额
            self.cash = total_cash - long_allocation
            
            # 分配空头仓位（用负值表示）
            allocation_per_short = short_allocation / len(short_industries)
            for industry in short_industries:
                self.position[industry] = -allocation_per_short
            
            # 更新现金余额
            # 由于空头仓位是无成本的，所以不需要从现金中扣除
            self.cash = total_cash - long_allocation
            
            logger.info(f"[{self.name}] 调仓后持仓: {self.position}")
    
    def _allocate_benchmark_positions(self, industries):
        """
        分配基准持仓（等权重）
        """
        # 清空现有持仓，将所有资产转为现金
        previous_position_value = sum(self.position.values())
        self.cash += previous_position_value
        previous_position = self.position.copy()
        self.position = {}
        
        logger.info(f"[{self.name}] 调仓前持仓: {previous_position}, 总值: {previous_position_value:.2f}")
        
        # 等权重分配到所有行业
        if industries:
            allocation_per_industry = self.cash / len(industries)
            for industry in industries:
                self.position[industry] = allocation_per_industry
            self.cash = 0.0
            
            logger.info(f"[{self.name}] 调仓后持仓: {self.position}")
    
    def _calculate_daily_return(self, returns_df):
        """
        计算每日收益
        """
        if self.date not in returns_df.index:
            self.return_rate = 0.0
            return
        
        # 获取当日各行业的收益率
        daily_returns = returns_df.loc[self.date]
        
        # 计算投资组合的收益率
        total_return = 0.0
        # 使用绝对值计算总投资额，因为空头仓位用负值表示
        total_investment = sum(abs(pos) for pos in self.position.values()) + self.cash
        
        if total_investment > 0:
            # 计算各行业持仓的收益贡献
            for industry, position in self.position.items():
                if industry in daily_returns:
                    # 收益 = 持仓金额 * 行业收益率
                    total_return += position * daily_returns[industry]
            
            # 计算总收益率
            self.return_rate = total_return / total_investment
        else:
            self.return_rate = 0.0
        
        # 更新NAV
        previous_NAV = self.NAV
        self.NAV = previous_NAV * (1 + self.return_rate)
        
        # 记录日志
        if self.return_rate != 0.0:
            logger.debug(f"[{self.name}] {self.date.date()} - 收益率: {self.return_rate:.6f}, NAV: {previous_NAV:.2f} -> {self.NAV:.2f}")
    
    def get_current_position_value(self, returns_df):
        """
        获取当前持仓市值
        """
        if self.date not in returns_df.index:
            return self.NAV
        
        position_value = self.cash
        daily_returns = returns_df.loc[self.date]
        
        for industry, position in self.position.items():
            if industry in daily_returns:
                # 持仓市值 = 持仓金额 * (1 + 行业收益率)
                # 对于空头仓位，持仓金额为负值，所以需要特殊处理
                # 空头仓位的收益计算应为: -持仓金额 * 行业收益率
                if position < 0:  # 空头仓位
                    position_value += position * daily_returns[industry]
                else:  # 多头仓位
                    position_value += position * (1 + daily_returns[industry])
            else:
                position_value += position
        
        return position_value
    
    def get_history_dataframe(self):
        """
        获取历史记录的DataFrame格式
        """
        # NAV历史
        nav_df = pd.DataFrame(self.nav_history, columns=['date', 'NAV'])
        nav_df.set_index('date', inplace=True)
        
        # 收益率历史
        return_df = pd.DataFrame(self.return_history, columns=['date', 'return'])
        return_df.set_index('date', inplace=True)
        
        # 合并数据
        history_df = nav_df.join(return_df, how='outer')
        
        # 计算累计收益率
        history_df['cumulative_return'] = (1 + history_df['return']).cumprod() - 1
        
        return history_df