import pandas as pd
import sys
sys.path.append('data_processing')
from data_generator import generate_simulated_data, save_data_to_file

if __name__ == "__main__":
    # 生成模拟数据
    print("正在生成模拟数据...")
    simulated_data = generate_simulated_data()
    print(f"生成了 {len(simulated_data)} 天的数据，包含 {len(simulated_data.columns)} 个行业")
    print(simulated_data.head())
    
    # 保存数据到文件
    filepath = save_data_to_file(simulated_data)
    print(f"数据已保存到 {filepath}")