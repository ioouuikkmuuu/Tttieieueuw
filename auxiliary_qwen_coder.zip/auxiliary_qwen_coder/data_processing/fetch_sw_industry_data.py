import tushare as ts
import pandas as pd
from datetime import datetime, timedelta

# 请在这里填入您的Tushare token
token = '2876ea85cb005fb5fa17c809a98174f2d5aae8b1f830110a5ead6211'
pro = ts.pro_api(token)

def get_sw_industry_data():
    # 获取申万一级行业列表
    industries = pro.index_classify(level='L1', src='SW2021')
    print(f"获取到 {len(industries)} 个申万一级行业")
    print(industries[['index_code', 'industry_name']].head())
    
    # 创建一个空的DataFrame来存储结果
    result_df = pd.DataFrame()
    
    # 遍历每个行业代码
    for index, row in industries.iterrows():
        industry_code = row['index_code']
        industry_name = row['industry_name']
        
        # 获取该行业指数的历史数据，限制日期范围为最近5年
        df = pro.sw_daily(ts_code=industry_code, fields='trade_date,close', start_date='20200101')
        print(f"行业 {industry_name} ({industry_code}) 获取到 {len(df)} 条数据")
        if not df.empty:
            print(df.head())
        
        # 重命名close列为行业名称
        df = df.rename(columns={'close': industry_name})
        
        # 计算每日收益率
        df[industry_name] = df[industry_name].pct_change()
        
        # 如果result_df为空，则直接赋值
        if result_df.empty:
            result_df = df
        else:
            # 否则，将新数据合并到result_df中
            result_df = pd.merge(result_df, df, on='trade_date', how='outer')
    
    # 将trade_date设置为索引
    result_df = result_df.set_index('trade_date')
    
    # 按日期排序
    result_df = result_df.sort_index()
    
    # 删除全为空值的行
    result_df = result_df.dropna(how='all')
    
    # 保存到CSV文件
    result_df.to_csv('sw_industry_daily_return.csv')
    
    print("数据已保存到 sw_industry_daily_return.csv")
    print(result_df.head())

if __name__ == "__main__":
    get_sw_industry_data()