import pandas as pd
import numpy as np
from datetime import datetime

def calculate_rolling_annual_return(daily_returns):
    """
    计算滚动年化收益率
    """
    # 假设252个交易日为一年
    annual_return = (1 + daily_returns).rolling(window=252).apply(np.prod, raw=True) - 1
    return annual_return

# 读取CSV文件
df = pd.read_csv('/Users/x/Downloads/auxiliary_qwen_coder/data/sw_industry_daily_return.csv')

# 将trade_date列转换为日期格式
df['trade_date'] = pd.to_datetime(df['trade_date'], format='%Y%m%d')

# 设置日期为索引
df.set_index('trade_date', inplace=True)

# 计算每个行业的滚动年化收益率
rolling_annual_returns = df.apply(calculate_rolling_annual_return, axis=0)

# 重塑数据以包含所有日期的年化收益率
rolling_annual_returns_reset = rolling_annual_returns.reset_index()

# 将数据转换为长格式，包含industry和annual_return两列
result_list = []
for industry in rolling_annual_returns.columns:
    industry_data = rolling_annual_returns_reset[['trade_date', industry]].dropna()
    industry_data.columns = ['trade_date', 'annual_return']
    industry_data['industry'] = industry
    result_list.append(industry_data)

result_df = pd.concat(result_list, ignore_index=True)
# 重新排列列顺序，只保留industry和annual_return两列
result_df = result_df[['industry', 'annual_return']]

# 保存结果到新的CSV文件
result_df.to_csv('/Users/x/Downloads/auxiliary_qwen_coder/data/rolling_annual_returns.csv', index=False)

print('滚动年化收益率已保存到 /Users/x/Downloads/auxiliary_qwen_coder/data/rolling_annual_returns.csv')