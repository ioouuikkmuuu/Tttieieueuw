import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from datetime import datetime
import warnings
import logging

# 尝试导入 plotly，如果失败则忽略
try:
    import plotly.graph_objects as go
    import plotly.offline as pyo
    PLOTLY_AVAILABLE = True
except ImportError:
    PLOTLY_AVAILABLE = False
    logging.warning("Plotly 未安装，将使用 matplotlib 进行绘图")
warnings.filterwarnings('ignore')

# 创建logs目录
logs_dir = 'logs'
if not os.path.exists(logs_dir):
    os.makedirs(logs_dir)

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(logs_dir, 'plotting.log')),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


def load_portfolio_history(portfolio_name):
    """
    加载投资组合历史数据
    """
    results_dir = os.path.join(os.path.dirname(__file__), '..', 'results')
    filename = f"{portfolio_name.replace('/', '_')}_history.csv"
    filepath = os.path.join(results_dir, filename)
    
    try:
        logger.info(f"加载投资组合历史数据: {portfolio_name}")
        df = pd.read_csv(filepath, index_col=0, parse_dates=True)
        return df
    except FileNotFoundError:
        logger.warning(f"文件 {filepath} 不存在")
        return None

def calculate_information_ratio(returns, benchmark_returns):
    """
    计算信息比率 (Information Ratio)
    """
    logger.info("计算信息比率")
    # 计算超额收益
    excess_returns = returns - benchmark_returns
    
    # 计算超额收益的平均值和标准差
    mean_excess_return = np.mean(excess_returns)
    std_excess_return = np.std(excess_returns)
    
    # 计算信息比率
    if std_excess_return != 0:
        information_ratio = mean_excess_return / std_excess_return
    else:
        information_ratio = 0
    
    return information_ratio

def plot_cumulative_returns(portfolios=None, engine='matplotlib'):
    """
    绘制累计收益曲线
    
    Parameters:
    portfolios (list): 要绘制的投资组合列表，默认为 None（绘制所有组合）
    engine (str): 绘图引擎，'matplotlib' 或 'plotly'，默认为 'matplotlib'
    """
    logger.info("正在加载投资组合历史数据...")
    
    # 定义所有可用的投资组合
    all_portfolios = {
        "Long Only": load_portfolio_history("Long Only"),
        "Long/Short": load_portfolio_history("Long/Short"),
        "Benchmark": load_portfolio_history("Benchmark")
    }
    
    # 如果用户指定了要绘制的投资组合，则过滤
    if portfolios is not None:
        selected_portfolios = {k: v for k, v in all_portfolios.items() if k in portfolios}
    else:
        selected_portfolios = all_portfolios
    
    # 检查数据是否加载成功
    if any(df is None for df in selected_portfolios.values()):
        logger.error("部分数据加载失败，无法绘图")
        return
    
    # 移除值为 None 的投资组合
    selected_portfolios = {k: v for k, v in selected_portfolios.items() if v is not None}
    
    logger.info("正在计算累计收益...")
    
    # 根据选择的引擎进行绘图
    if engine == 'plotly' and PLOTLY_AVAILABLE:
        _plot_with_plotly(selected_portfolios)
    else:
        _plot_with_matplotlib(selected_portfolios)
    
    # 计算并打印信息比率
    if "Long Only" in selected_portfolios and "Long/Short" in selected_portfolios and "Benchmark" in selected_portfolios:
        calculate_and_save_IR(selected_portfolios["Long Only"], selected_portfolios["Long/Short"], selected_portfolios["Benchmark"])
    elif "Long Only" in selected_portfolios and "Benchmark" in selected_portfolios:
        calculate_and_save_IR(selected_portfolios["Long Only"], None, selected_portfolios["Benchmark"])
    elif "Long/Short" in selected_portfolios and "Benchmark" in selected_portfolios:
        calculate_and_save_IR(None, selected_portfolios["Long/Short"], selected_portfolios["Benchmark"])

def calculate_and_save_IR(long_only_df, long_short_df, benchmark_df):
    """
    计算并保存信息比率
    """
    logger.info("正在计算信息比率...")
    
    # 初始化IR值
    ir_long_only = None
    ir_long_short = None
    
    # 确保基准数据存在
    if benchmark_df is not None:
        benchmark_returns = benchmark_df['return']
        
        # 计算各个投资组合的信息比率
        if long_only_df is not None:
            common_dates = long_only_df.index.intersection(benchmark_df.index)
            long_only_returns = long_only_df.loc[common_dates, 'return']
            ir_long_only = calculate_information_ratio(long_only_returns, benchmark_returns)
        
        if long_short_df is not None:
            common_dates = long_short_df.index.intersection(benchmark_df.index)
            long_short_returns = long_short_df.loc[common_dates, 'return']
            ir_long_short = calculate_information_ratio(long_short_returns, benchmark_returns)
    
    # 创建IR结果DataFrame
    portfolios = []
    ir_values = []
    
    if ir_long_only is not None:
        portfolios.append('Long Only')
        ir_values.append(ir_long_only)
    
    if ir_long_short is not None:
        portfolios.append('Long/Short')
        ir_values.append(ir_long_short)
    
    ir_data = {
        'Portfolio': portfolios,
        'Information_Ratio': ir_values
    }
    ir_df = pd.DataFrame(ir_data)
    
    # 保存IR结果
    results_dir = os.path.join(os.path.dirname(__file__), '..', 'results')
    ir_path = os.path.join(results_dir, 'information_ratios.csv')
    ir_df.to_csv(ir_path, index=False)
    logger.info(f"信息比率已保存到 {ir_path}")
    
    # 打印IR结果
    logger.info("\n信息比率 (Information Ratio):")
    logger.info(ir_df)

def _plot_with_matplotlib(portfolios):
    """
    使用 matplotlib 绘制累计收益曲线
    """
    plt.figure(figsize=(12, 8))
    
    # 绘制每个投资组合的累计收益曲线
    for name, df in portfolios.items():
        plt.plot(df.index, df['cumulative_return'], label=name, linewidth=2)
    
    # 设置图形属性
    plt.title('投资组合累计收益曲线', fontsize=16)
    plt.xlabel('日期', fontsize=12)
    plt.ylabel('累计收益', fontsize=12)
    plt.legend(fontsize=12)
    plt.grid(True, alpha=0.3)
    
    # 旋转x轴标签以提高可读性
    plt.xticks(rotation=45)
    
    # 调整布局
    plt.tight_layout()
    
    # 保存图形
    results_dir = os.path.join(os.path.dirname(__file__), '..', 'results')
    plot_path = os.path.join(results_dir, 'cumulative_returns.png')
    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
    logger.info(f"累计收益曲线已保存到 {plot_path}")
    
    # 显示图形
    plt.show()


def _plot_with_plotly(portfolios):
    """
    使用 plotly 绘制累计收益曲线
    """
    fig = go.Figure()
    
    # 绘制每个投资组合的累计收益曲线
    for name, df in portfolios.items():
        fig.add_trace(go.Scatter(x=df.index, y=df['cumulative_return'], mode='lines', name=name, line=dict(width=2)))
    
    # 设置图形属性
    fig.update_layout(
        title='投资组合累计收益曲线',
        xaxis_title='日期',
        yaxis_title='累计收益',
        legend_title='投资组合',
        font=dict(size=12),
        width=1000,
        height=600
    )
    
    # 保存图形
    results_dir = os.path.join(os.path.dirname(__file__), '..', 'results')
    plot_path = os.path.join(results_dir, 'cumulative_returns.html')
    pyo.plot(fig, filename=plot_path, auto_open=False)
    logger.info(f"累计收益曲线已保存到 {plot_path}")
    
    # 显示图形
    pyo.plot(fig, filename='temp_plot.html', auto_open=True)


def plot_long_short_components(engine='matplotlib'):
    """
    绘制 Long/Short 组合的多头和空头部分
    """
    logger.info("正在加载 Long/Short 组合历史数据...")
    long_short_df = load_portfolio_history("Long/Short")
    
    if long_short_df is None:
        logger.error("Long/Short 数据加载失败，无法绘图")
        return
    
    # 分离多头和空头部分
    long_component = long_short_df[long_short_df['return'] > 0].copy()
    short_component = long_short_df[long_short_df['return'] < 0].copy()
    
    # 计算累计收益
    long_component['cumulative_return'] = (1 + long_component['return']).cumprod() - 1
    short_component['cumulative_return'] = (1 + short_component['return']).cumprod() - 1
    
    # 创建包含所有组件的数据字典
    components = {
        "Long/Short": long_short_df,
        "Long Component": long_component,
        "Short Component": short_component
    }
    
    # 根据选择的引擎进行绘图
    if engine == 'plotly' and PLOTLY_AVAILABLE:
        _plot_with_plotly(components)
    else:
        _plot_with_matplotlib(components)


if __name__ == "__main__":
    # 默认使用 matplotlib 绘制所有投资组合的累计收益曲线
    plot_cumulative_returns()
    
    # 示例：使用 plotly 绘制所有投资组合的累计收益曲线
    # plot_cumulative_returns(engine='plotly')
    
    # 示例：只绘制特定的投资组合
    # plot_cumulative_returns(portfolios=["Long Only", "Benchmark"], engine='matplotlib')
    
    # 示例：绘制 Long/Short 组合的多头和空头部分
    # plot_long_short_components(engine='plotly')