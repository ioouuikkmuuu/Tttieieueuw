import tushare as ts
import pandas as pd
import numpy as np

# 设置Tushare的token（需要用户自己申请）
token = '2876ea85cb005fb5fa17c809a98174f2d5aae8b1f830110a5ead6211'  # 请替换为您的Tushare token

if token == 'your_token_here':
    print("请先设置您的Tushare token。您需要在Tushare官网注册并获取token。")
    print("获取token后，请将代码中的 'your_token_here' 替换为您的实际token。")
else:
    try:
        ts.set_token(token)
        pro = ts.pro_api()

        # 获取CSI 800指数数据
        # 注意：这里使用的是沪深300和中证500的数据来模拟CSI 800，因为Tushare可能没有直接的CSI 800数据
        # 在实际应用中，您可能需要调整获取数据的方式
        hs300 = pro.index_daily(ts_code='000300.SH', start_date='20230203', end_date='20250630')
        zz500 = pro.index_daily(ts_code='000905.SH', start_date='20230203', end_date='20250630')

        # 合并数据以模拟CSI 800
        # 这里简单地取两个指数的平均值作为CSI 800的近似值
        hs300 = hs300.sort_values('trade_date')
        zz500 = zz500.sort_values('trade_date')

        # 计算日收益率
        csi800_data = pd.DataFrame()
        csi800_data['date'] = hs300['trade_date']
        csi800_data['close'] = (hs300['close'] + zz500['close']) / 2
        csi800_data['daily_return'] = csi800_data['close'].pct_change()
        csi800_data['cumulative_return'] = (1 + csi800_data['daily_return']).cumprod() - 1

        # 删除第一行（因为pct_change会产生NaN）
        csi800_data = csi800_data.dropna()

        # 保存数据到CSV文件
        csi800_data.to_csv('/Users/x/Downloads/auxiliary_qwen_coder/aux_test/aux_plot/csi800_data.csv', index=False)

        print('CSI 800 data saved to csi800_data.csv')
    except Exception as e:
        print(f"获取数据时出错: {e}")
        print("请确保您的Tushare token正确，并且您有权限访问所需的数据。")