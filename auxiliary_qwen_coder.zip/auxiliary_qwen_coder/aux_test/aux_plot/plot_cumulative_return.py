from operator import index
import pandas as pd
import plotly.graph_objects as go
import sys
import os

# 添加当前目录到Python路径，以便导入parse_long_short_position模块
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from parse_long_short_position import parse_long_short_position, calculate_cumulative_returns

# 读取两个CSV文件
# 注意：parse_date参数应为parse_dates
# 对于test.csv，日期列是索引列，需要指定index_col=0
# 对于csi800_data.csv，日期列名为'date'，需要指定index_col='date'和parse_dates=True
df_test = pd.read_csv('/Users/x/Downloads/auxiliary_qwen_coder/aux_test/aux_plot/test.csv', index_col=0, parse_dates=True)
df_csi800 = pd.read_csv('/Users/x/Downloads/auxiliary_qwen_coder/aux_test/aux_plot/csi800_data.csv', index_col='date', parse_dates=True)

# 统一日期索引格式
# 将df_test的索引格式调整为与df_csi800一致（datetime格式）
df_test.index = pd.to_datetime(df_test.index)
# 将df_csi800的日期索引格式调整为与df_test一致（如果需要的话）
df_csi800.index = pd.to_datetime(df_csi800.index, format='%Y%m%d')

# 计算long和short部分的累积收益
df_long, df_short = parse_long_short_position('/Users/x/Downloads/auxiliary_qwen_coder/aux_test/aux_plot/test.csv')
# 读取每日收益和调仓日
daily_returns = df_test['Daily_Return']
rebalance_day = df_test['Rebalance_Day']
long_cumulative, short_cumulative,filter_mask = calculate_cumulative_returns(df_long, df_short, daily_returns, rebalance_day)
df_test = df_test[filter_mask]
df_test['Cumulative_Return_1'] = (1 + df_test['Daily_Return']).cumprod() -1
df_csi800 = df_csi800[filter_mask]

############################################

def analyze_rebalance_day_returns(file_path):
    """
    读取test csv里所有rebalance day标记为1的行，然后分别拿到有>0持仓的行业的return，和<0的持仓的行业的return
    
    参数:
    file_path (str): test.csv文件的路径
    
    返回:
    tuple: (positive_returns, negative_returns) 分别为正持仓和负持仓行业的收益
    """
    # 读取CSV文件
    df = pd.read_csv(file_path, index_col=0, parse_dates=True)
    
    # 筛选出rebalance day为1的行
    rebalance_df = df[df['Rebalance_Day'] == 1]
    
    # 获取持仓列
    holding_columns = [col for col in df.columns if col.startswith('Holding_SW_')]
    
    # 分别收集正持仓和负持仓行业的收益
    positive_returns = []
    negative_returns = []
    
    for index, row in rebalance_df.iterrows():
        for col in holding_columns:
            if row[col] > 0:
                # 找到对应的收益列（去掉'Holding_'前缀）
                return_col = col.replace('Holding_', '') + '_x'
                if return_col in df.columns:
                    positive_returns.append(row[return_col])
            elif row[col] < 0:
                # 找到对应的收益列（去掉'Holding_'前缀）
                return_col = col.replace('Holding_', '') + '_y'
                if return_col in df.columns:
                    negative_returns.append(row[return_col])
    
    return positive_returns, negative_returns

############################################
# 创建图表
fig = go.Figure()

# 添加四条Cumulative Return线
# 为每条线设置自定义颜色
fig.add_trace(go.Scatter(x=df_test.index, y=df_test['Cumulative_Return_1'], mode='lines+markers', name='Test Cumulative Return', line=dict(color='blue')))
fig.add_trace(go.Scatter(x=df_csi800.index, y=df_csi800['cumulative_return'], mode='lines+markers', name='CSI 800 Cumulative Return', line=dict(color='grey')))
fig.add_trace(go.Scatter(x=long_cumulative.index, y=long_cumulative.values, mode='lines+markers', name='Long Positions Cumulative Return', line=dict(color='red')))
fig.add_trace(go.Scatter(x=short_cumulative.index, y=short_cumulative.values, mode='lines+markers', name='Short Positions Cumulative Return', line=dict(color='green')))

# 设置图表标题和轴标签
fig.update_layout(title='Cumulative Return Comparison', xaxis_title='Date', yaxis_title='Cumulative Return', legend_title_text='Legend')

# 保存图表为HTML文件
fig.write_html('/Users/x/Downloads/auxiliary_qwen_coder/aux_test/aux_plot/cumulative_return_comparison_chart.html')

# 显示图表
fig.show()