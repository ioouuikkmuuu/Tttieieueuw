import pandas as pd

def parse_long_short_position(file_path):
    """
    读取持仓数据文件，并对long和short部分进行拆解
    
    参数:
    file_path (str): 持仓数据文件的路径
    
    返回:
    tuple: 包含long和short部分的DataFrame元组
    """
    # 读取CSV文件
    df = pd.read_csv(file_path, index_col=0, parse_dates=True)
    

    
    # 选择包含持仓信息的列（从Holding_SW_Agriculture到Holding_SW_Beauty_Care）
    holding_columns = [col for col in df.columns if col.startswith('Holding_SW_')]
    
    # 分离long和short部分
    # Long部分：正值表示做多
    df_long = df[holding_columns].clip(lower=0)
    
    # Short部分：负值表示做空，转换为正值表示做空的金额
    df_short = df[holding_columns].clip(upper=0).abs()
    
    return df_long, df_short

def calculate_cumulative_returns(df_long, df_short, daily_returns, rebalance_day=None):
    """
    计算long和short部分各自按列加总的累积收益
    
    参数:
    df_long (DataFrame): long部分的DataFrame
    df_short (DataFrame): short部分的DataFrame
    daily_returns (Series): 每日收益序列
    rebalance_day (Series, optional): 调仓日序列，默认为None
    
    返回:
    tuple: 包含long和short部分累积收益的DataFrame元组
    """
    # 计算long和short部分的按列加总
    long_sum = df_long.sum(axis=1)
    short_sum = df_short.sum(axis=1)
    
    # 如果提供了rebalance_day，则过滤掉rebalance_day为1的行
    if rebalance_day is not None:
        # 创建一个过滤器，标记rebalance_day不为1的行
        filter_mask = rebalance_day != 1
        
        # 应用过滤器
        # long_sum = long_sum[filter_mask]
        # short_sum = short_sum[filter_mask]
    
    # 计算每日收益
    long_daily_return = long_sum.pct_change()[filter_mask]
    short_daily_return = -short_sum.pct_change()[filter_mask]
    
    # 计算累积收益
    long_cumulative = (1 + long_daily_return).cumprod() -1
    short_cumulative = (1 + short_daily_return).cumprod() -1
    
    return long_cumulative, short_cumulative,filter_mask

# 示例用法
if __name__ == "__main__":
    file_path = '/Users/x/Downloads/auxiliary_qwen_coder/aux_test/aux_plot/test.csv'
    df_long, df_short = parse_long_short_position(file_path)
    
    print("Long部分（前5行）：")
    print(df_long.head())
    
    print("\nShort部分（前5行）：")
    print(df_short.head())
    
    # 读取每日收益和调仓日
    df = pd.read_csv(file_path, index_col=0, parse_dates=True)
    daily_returns = df['Daily_Return']
    rebalance_day = df['Rebalance_Day']
    
    # 计算累积收益
    long_cumulative, short_cumulative = calculate_cumulative_returns(df_long, df_short, daily_returns, rebalance_day)
    
    print("\nLong部分累积收益（前5行）：")
    print(long_cumulative.head())
    
    print("\nShort部分累积收益（前5行）：")
    print(short_cumulative.head())