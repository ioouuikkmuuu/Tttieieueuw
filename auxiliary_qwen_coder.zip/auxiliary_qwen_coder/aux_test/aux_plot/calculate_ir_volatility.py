import pandas as pd
import numpy as np
import plotly.graph_objects as go
from parse_long_short_position import parse_long_short_position, calculate_cumulative_returns

# 读取数据
df_test = pd.read_csv('/Users/x/Downloads/auxiliary_qwen_coder/aux_test/aux_plot/test.csv', index_col=0, parse_dates=True)
df_csi800 = pd.read_csv('/Users/x/Downloads/auxiliary_qwen_coder/aux_test/aux_plot/csi800_data.csv', index_col='date', parse_dates=True)

# 统一日期索引格式
df_test.index = pd.to_datetime(df_test.index)
df_csi800.index = pd.to_datetime(df_csi800.index, format='%Y%m%d')

# 计算long和short部分的累积收益
df_long, df_short = parse_long_short_position('/Users/x/Downloads/auxiliary_qwen_coder/aux_test/aux_plot/test.csv')
# 读取每日收益和调仓日
daily_returns = df_test['Daily_Return']
rebalance_day = df_test['Rebalance_Day']
long_cumulative, short_cumulative, filter_mask = calculate_cumulative_returns(df_long, df_short, daily_returns, rebalance_day)
df_test = df_test[filter_mask]
df_csi800 = df_csi800[filter_mask]

# 计算超额收益（相对于CSI 800）
df_test['Excess_Return'] = df_test['Daily_Return'] - df_csi800['daily_return']

# 按年份分组计算IR和波动率
def calculate_annual_ir_volatility(df, df_csi800):
    # 按年份分组
    df['Year'] = df.index.year
    annual_data = df.groupby('Year')
    
    results = []
    for year, group in annual_data:
        # 计算年化收益率
        annual_return = (1 + group['Daily_Return']).prod() - 1
        
        # 计算年化波动率
        annual_volatility = group['Daily_Return'].std() * np.sqrt(252)
        
        # 获取对应年份的基准数据
        csi800_group = df_csi800[df_csi800.index.year == year]
        
        # 计算信息比率 (IR)
        # IR = (策略年化收益 - 基准年化收益) / 超额收益波动率
        benchmark_return = (1 + csi800_group['daily_return']).prod() - 1
        excess_return = group['Excess_Return']
        ir = (annual_return - benchmark_return) / excess_return.std() * np.sqrt(252)
        
        results.append({
            'Year': year,
            'Annual Return': annual_return,
            'Annual Volatility': annual_volatility,
            'Information Ratio': ir
        })
    
    return pd.DataFrame(results)

# 计算结果
annual_metrics = calculate_annual_ir_volatility(df_test, df_csi800)

# 绘制表格
fig = go.Figure(data=[go.Table(
    header=dict(values=['Year', 'Annual Return', 'Annual Volatility', 'Information Ratio'],
                fill_color='paleturquoise',
                align='left'),
    cells=dict(values=[annual_metrics['Year'], 
                       annual_metrics['Annual Return'].round(4), 
                       annual_metrics['Annual Volatility'].round(4), 
                       annual_metrics['Information Ratio'].round(4)],
               fill_color='lavender',
               align='left'))
])

fig.update_layout(title='Annual Information Ratio and Volatility')
fig.write_html('/Users/x/Downloads/auxiliary_qwen_coder/aux_test/aux_plot/annual_ir_volatility_table.html')
fig.show()

# 打印结果
print(annual_metrics)