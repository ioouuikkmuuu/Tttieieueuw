

from helperfunc import *


def portfolio_update(day, rebalanced_cash, LONG_SHORT_N):
    print("portfolio_update")
    if not portfolio_long_short :
        print("first day")
        
        long_pos = []
        short_pos = []
        long_ret = []
        short_ret = []
        portfolio_long_short.append({'date': day,
                                    'cash': INIT_CASH,
                                    'long_pos': long_pos,
                                    'short_pos': short_pos,
                                    'long_ret': long_ret,
                                    'short_ret': short_ret,
                                    'day_type':'Inception day',
                                    'NAV': INIT_CASH
        })


    elif date_classification.loc[day, 'rebalance_day']:
        # 执行再平衡逻辑
        print(f"rebalance_day:{day}")
        current_index = return_index.get_loc(day)
        prev_2_day = return_index[current_index - 2]


        print(f"rebalanced_cash:{rebalanced_cash}")
        pass
    else:
        print(day)

        prev_entry = portfolio_long_short[-1]  # 获取列表中最后一个元素
        prev_date = prev_entry['date']
        prev_cash = prev_entry['cash']
        prev_long_pos = prev_entry['long_pos']
        prev_short_pos = prev_entry['short_pos']
        prev_long_ret = prev_entry['long_ret']
        prev_short_ret = prev_entry['short_ret']
        prev_day_type = prev_entry['day_type']
        prev_NAV = prev_entry['NAV']

        day_returns = return_df.loc[day]

        long_pos = [(sector, val*(1+day_returns[sector])) for sector, val in prev_long_pos]
        short_pos = [(sector, val*(1+day_returns[sector])) for sector, val in prev_short_pos]
        long_ret = [(sector, day_returns[sector]) for sector, val in prev_long_pos]
        short_ret = [(sector, day_returns[sector]) for sector, val in prev_short_pos]
        portfolio_long_short.append({'date': day,
                                     'cash': 0,
                                     'long_pos': long_pos,
                                     'short_pos': short_pos,
                                     'long_ret': long_ret,
                                     'short_ret': short_ret,
                                     'day_type':'Normal Day',
                                     'NAV': rebalanced_cash + sum([pos[1] for pos in long_pos]) + sum([pos[1] for pos in short_pos])
                                     })





####################################################
LONG_SHORT_N = 2
INIT_CASH = 10000
return_file_path = '/Users/x/Downloads/auxiliary_qwen_coder/data/sw_industry_daily_return.csv'
return_df, return_index = read_return(return_file_path)
score_df = scoring_return_df(return_df)

initial_day = get_one_day_before_earliest(return_df)
portfolio_long_short = []
rebalanced_cash = INIT_CASH
date_classification = classify_dates(return_df)

for day in return_index:
    portfolio_update(day, rebalanced_cash,LONG_SHORT_N)

print(portfolio_long_short[-3:])

