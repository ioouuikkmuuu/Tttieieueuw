# Instruction Log

This file will contain the instructions provided by the user. Each new prompt will be recorded here.

## Instructions

3. Added read_return() function to auxiliary.py:
   - Function reads data/sw_industry_daily_return.csv
   - Returns both the DataFrame and its index
   - Usage: df, index = read_return()

4. `read_score()` 函数用于读取 `data/rolling_annual_returns.csv` 文件，返回 DataFrame 和索引。
   使用方法：`score_df, score_index = read_score()`

5. `main(return_file_path, score_file_path)` 函数接受两个参数，分别指定return数据和score数据的文件路径。
   使用方法：`main()` (使用默认路径) 或 `main('path/to/return/file.csv', 'path/to/score/file.csv')`