
import pandas as pd

def get_one_day_before_earliest(return_df):
    """
    找到return_df里最早的日期，并往前再数一天，返回日期字符串

    Parameters:
    return_df (DataFrame): 包含行业return值的DataFrame，索引为日期

    Returns:
    str: 比最早日期早一天的日期字符串，格式为 'YYYY-MM-DD'
    """
    # 找到最早日期
    earliest_date = return_df.index.min()

    # 往前推一天
    one_day_earlier = earliest_date - pd.Timedelta(days=1)

    # 转换为字符串格式
    result_date_str = one_day_earlier.strftime('%Y-%m-%d')

    return result_date_str

# 使用示例
# one_day_before = get_one_day_before_earliest(return_df)
# print(f"One day before earliest date: {one_day_before}")

def read_return(file_path='data/sw_industry_daily_return.csv'):
    """Read CSV file and return df and index

    Parameters:
    file_path (str): Path to the CSV file

    Returns:
    tuple: (DataFrame, Index)"""
    df = pd.read_csv(file_path, index_col='trade_date', parse_dates=True)
    return df, df.index


def scoring_return_df(return_df):
    """
    对每一行的行业按return值进行排名打分，最高的是1，以此类推

    Parameters:
    return_df (DataFrame): 包含行业return值的DataFrame，行为日期，列为行业

    Returns:
    DataFrame: 与return_df形状相同的DataFrame，值为排名分数
    """
    # 对每一行按值进行排名，数值最高的为1，依次递增
    # axis=1表示按行操作，ascending=False表示数值高的排名靠前
    score_df = return_df.rank(axis=1, method='min', ascending=False)

    return score_df


def classify_dates(return_df):
    """
    读入return_df, 返回一个df，index是return df的index，列是判断index date是哪种日期
    考虑到return_df本身只包含交易日，有些日期可能不存在

    Parameters:
    return_df (DataFrame): 包含行业return值的DataFrame，索引为交易日日期

    Returns:
    DataFrame: 与return_df索引相同的DataFrame，包含以下列：
               - rebalance_benchmark: True/False，表示是否为每个月最后一天（或之前的最近交易日），但不包括数据集的最后一天
               - prep_day: True/False，表示是否为每个月第一天（或之后的最近交易日）
               - rebalance_day: True/False，表示是否为prep_day的下一个交易日
    """
    # 创建结果DataFrame
    date_classification = pd.DataFrame(index=return_df.index)
    date_classification['rebalance_benchmark'] = False
    date_classification['prep_day'] = False
    date_classification['rebalance_day'] = False

    # 获取所有交易日
    trading_days = return_df.index

    # 获取数据集的最后一天
    last_day_in_dataset = trading_days.max()

    # 按月分组处理
    monthly_groups = trading_days.to_series().groupby([trading_days.year, trading_days.month])

    # 对每个月进行处理
    for (year, month), month_days in monthly_groups:
        if len(month_days) < 13: # TODO: temp solution
            continue

        # 获取当月的所有交易日
        month_trading_days = month_days.tolist()

        # prep_day: 当月第一个交易日
        date_classification.loc[month_trading_days[0], 'prep_day'] = True

        # rebalance_day: prep_day的下一个交易日（如果存在）
        if len(month_trading_days) > 1:
            date_classification.loc[month_trading_days[1], 'rebalance_day'] = True

        # rebalance_benchmark: 当月最后一个交易日，但不包括数据集的最后一天
        last_trading_day_of_month = month_trading_days[-1]
        if last_trading_day_of_month != last_day_in_dataset:
            date_classification.loc[last_trading_day_of_month, 'rebalance_benchmark'] = True

    return date_classification
