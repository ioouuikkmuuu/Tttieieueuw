import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

def load_data():
    """加载数据"""
    # 加载SHAP贡献度数据
    shap_df = pd.read_csv('momentum_shap_contributions.csv')
    shap_df['date'] = pd.to_datetime(shap_df['date'])
    
    # 加载原始收益数据
    returns_df = pd.read_csv('data/csi800_daily_returns.csv')
    returns_df['date'] = pd.to_datetime(returns_df['date'])
    
    return shap_df, returns_df

def calculate_window_returns(returns_df, target_date, window):
    """
    计算指定日期后指定窗口期的总收益
    :param returns_df: 收益数据
    :param target_date: 目标日期
    :param window: 窗口期（工作日）
    :return: 窗口期总收益
    """
    # 找到目标日期在收益数据中的位置
    date_matches = returns_df[returns_df['date'] == target_date]
    if len(date_matches) == 0:
        # 如果精确匹配不到，找最近的日期
        date_diff = abs(returns_df['date'] - target_date)
        closest_idx = date_diff.argmin()
        target_date = returns_df.iloc[closest_idx]['date']
    
    # 找到目标日期的索引
    target_idx = returns_df[returns_df['date'] == target_date].index[0]
    
    # 计算窗口期结束索引
    end_idx = min(target_idx + window, len(returns_df))
    
    # 计算窗口期内的总收益（复合收益）
    window_returns = returns_df.iloc[target_idx:end_idx]['return']
    total_return = (1 + window_returns).prod() - 1
    
    return total_return

def analyze_top_shap_dates():
    """分析SHAP贡献值前10的日期"""
    shap_df, returns_df = load_data()
    
    # 为每个动量因子找出SHAP贡献值前10的日期
    factors = ['短期动量', '中期动量', '长期动量']
    top_dates = {}
    
    for factor in factors:
        # 按绝对值排序找出贡献最大的日期
        shap_df_sorted = shap_df.iloc[abs(shap_df[factor]).argsort()[::-1]]
        top_dates[factor] = shap_df_sorted.head(10)[['date', factor]].copy()
    
    # 计算这些日期的5, 10, 20工作日总收益
    windows = [5, 10, 20]
    results = {}
    
    for factor in factors:
        results[factor] = []
        for _, row in top_dates[factor].iterrows():
            date = row['date']
            shap_value = row[factor]
            
            # 计算不同窗口期的收益
            window_returns = {}
            for window in windows:
                total_return = calculate_window_returns(returns_df, pd.to_datetime(date), window)
                window_returns[f'{window}日收益'] = total_return
            
            results[factor].append({
                'date': date,
                'shap_value': shap_value,
                **window_returns
            })
    
    return results, shap_df, returns_df

def calculate_average_returns(returns_df, windows):
    """计算所有日期的平均收益"""
    avg_returns = {}
    
    for window in windows:
        total_returns = []
        # 对于每个日期，计算窗口期收益
        for i in range(len(returns_df) - window):
            window_return = (1 + returns_df.iloc[i:i+window]['return']).prod() - 1
            total_returns.append(window_return)
        
        avg_returns[f'{window}日平均收益'] = np.mean(total_returns)
    
    return avg_returns

def generate_report():
    """生成分析报告"""
    results, shap_df, returns_df = analyze_top_shap_dates()
    windows = [5, 10, 20]
    avg_returns = calculate_average_returns(returns_df, windows)
    
    # 创建报告
    report = "# SHAP贡献值前10日期收益分析报告\n\n"
    
    # 添加平均收益信息
    report += "## 所有日期平均收益\n\n"
    for key, value in avg_returns.items():
        report += f"- {key}: {value:.4f} ({value*100:.2f}%)\n"
    report += "\n"
    
    # 分析每个因子
    for factor in results.keys():
        report += f"## {factor} SHAP贡献值前10日期分析\n\n"
        report += "| 日期 | SHAP值 | 5日收益 | 10日收益 | 20日收益 |\n"
        report += "|------|--------|---------|----------|----------|\n"
        
        # 计算该因子前10日期的平均收益
        factor_returns = {5: [], 10: [], 20: []}
        
        for item in results[factor]:
            date = item['date']
            shap_value = item['shap_value']
            ret_5 = item['5日收益']
            ret_10 = item['10日收益']
            ret_20 = item['20日收益']
            
            report += f"| {date} | {shap_value:.6f} | {ret_5:.4f} ({ret_5*100:.2f}%) | {ret_10:.4f} ({ret_10*100:.2f}%) | {ret_20:.4f} ({ret_20*100:.2f}%) |\n"
            
            factor_returns[5].append(ret_5)
            factor_returns[10].append(ret_10)
            factor_returns[20].append(ret_20)
        
        # 计算并添加平均值
        avg_5 = np.mean(factor_returns[5])
        avg_10 = np.mean(factor_returns[10])
        avg_20 = np.mean(factor_returns[20])
        
        report += f"| **平均** | - | **{avg_5:.4f}** ({avg_5*100:.2f}%) | **{avg_10:.4f}** ({avg_10*100:.2f}%) | **{avg_20:.4f}** ({avg_20*100:.2f}%) |\n"
        
        # 比较与总体平均的差异
        avg_5_all = avg_returns['5日平均收益']
        avg_10_all = avg_returns['10日平均收益']
        avg_20_all = avg_returns['20日平均收益']
        
        diff_5 = avg_5 - avg_5_all
        diff_10 = avg_10 - avg_10_all
        diff_20 = avg_20 - avg_20_all
        
        report += f"| **与总体平均差异** | - | {diff_5:.4f} ({diff_5*100:.2f}%) | {diff_10:.4f} ({diff_10*100:.2f}%) | {diff_20:.4f} ({diff_20*100:.2f}%) |\n"
        report += "\n"
        
        # 判断是否显著高于平均水平
        if diff_5 > 0:
            report += f"- 5日收益: 前10日期平均收益 **高于** 总体平均 (差异: {diff_5*100:.2f}%)\n"
        else:
            report += f"- 5日收益: 前10日期平均收益 **低于** 总体平均 (差异: {diff_5*100:.2f}%)\n"
            
        if diff_10 > 0:
            report += f"- 10日收益: 前10日期平均收益 **高于** 总体平均 (差异: {diff_10*100:.2f}%)\n"
        else:
            report += f"- 10日收益: 前10日期平均收益 **低于** 总体平均 (差异: {diff_10*100:.2f}%)\n"
            
        if diff_20 > 0:
            report += f"- 20日收益: 前10日期平均收益 **高于** 总体平均 (差异: {diff_20*100:.2f}%)\n"
        else:
            report += f"- 20日收益: 前10日期平均收益 **低于** 总体平均 (差异: {diff_20*100:.2f}%)\n"
        
        report += "\n"
    
    # 添加结论
    report += "## 结论\n\n"
    report += "本报告分析了各动量因子SHAP贡献值前10日期的未来收益表现，并与所有日期的平均收益进行了比较。\n\n"
    
    for factor in results.keys():
        report += f"### {factor}\n"
        factor_data = [item for item in results[factor]]
        avg_5 = np.mean([item['5日收益'] for item in factor_data])
        avg_10 = np.mean([item['10日收益'] for item in factor_data])
        avg_20 = np.mean([item['20日收益'] for item in factor_data])
        
        avg_5_all = avg_returns['5日平均收益']
        avg_10_all = avg_returns['10日平均收益']
        avg_20_all = avg_returns['20日平均收益']
        
        if avg_5 > avg_5_all:
            report += f"- 5日窗口：前10日期平均收益高于总体平均\n"
        else:
            report += f"- 5日窗口：前10日期平均收益低于总体平均\n"
            
        if avg_10 > avg_10_all:
            report += f"- 10日窗口：前10日期平均收益高于总体平均\n"
        else:
            report += f"- 10日窗口：前10日期平均收益低于总体平均\n"
            
        if avg_20 > avg_20_all:
            report += f"- 20日窗口：前10日期平均收益高于总体平均\n"
        else:
            report += f"- 20日窗口：前10日期平均收益低于总体平均\n"
        report += "\n"
    
    return report

if __name__ == "__main__":
    report = generate_report()
    
    # 保存报告
    with open('shap_returns_analysis_report.md', 'w', encoding='utf-8') as f:
        f.write(report)
    
    print("分析报告已生成并保存为 shap_returns_analysis_report.md")
    print("\n报告摘要:")
    print("=" * 50)
    
    # 简要输出结果
    results, shap_df, returns_df = analyze_top_shap_dates()
    windows = [5, 10, 20]
    avg_returns = calculate_average_returns(returns_df, windows)
    
    for factor in results.keys():
        print(f"\n{factor}:")
        factor_data = [item for item in results[factor]]
        avg_5 = np.mean([item['5日收益'] for item in factor_data])
        avg_10 = np.mean([item['10日收益'] for item in factor_data])
        avg_20 = np.mean([item['20日收益'] for item in factor_data])
        
        avg_5_all = avg_returns['5日平均收益']
        avg_10_all = avg_returns['10日平均收益']
        avg_20_all = avg_returns['20日平均收益']
        
        print(f"  5日:  {avg_5:.4f} (总体: {avg_5_all:.4f}, 差异: {avg_5-avg_5_all:.4f})")
        print(f"  10日: {avg_10:.4f} (总体: {avg_10_all:.4f}, 差异: {avg_10-avg_10_all:.4f})")
        print(f"  20日: {avg_20:.4f} (总体: {avg_20_all:.4f}, 差异: {avg_20-avg_20_all:.4f})")