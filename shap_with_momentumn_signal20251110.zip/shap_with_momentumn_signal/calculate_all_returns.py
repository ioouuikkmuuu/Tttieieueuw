#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
计算所有日期的5、10、20工作日回报率并保存为CSV文件
"""

import pandas as pd
import numpy as np
from datetime import datetime

def load_data():
    """加载数据"""
    # 加载收益率数据
    returns_df = pd.read_csv('data/csi800_daily_returns.csv')
    returns_df['date'] = pd.to_datetime(returns_df['date'])
    
    return returns_df

def calculate_window_returns(returns_df, target_date, window):
    """
    计算从目标日期开始的窗口期内的总收益（复合收益）
    
    参数:
    returns_df: 包含日期和收益率的DataFrame
    target_date: 目标日期
    window: 窗口期长度（工作日）
    
    返回:
    窗口期内的总收益
    """
    # 确保日期是datetime类型
    target_date = pd.to_datetime(target_date)
    
    # 找到目标日期在DataFrame中的位置
    if target_date not in returns_df['date'].values:
        return np.nan
    
    target_idx = returns_df[returns_df['date'] == target_date].index[0]
    
    # 计算窗口期结束索引
    end_idx = min(target_idx + window, len(returns_df))
    
    # 计算窗口期内的总收益（复合收益）
    window_returns = returns_df.iloc[target_idx:end_idx]['return']
    total_return = (1 + window_returns).prod() - 1
    
    return total_return

def calculate_average_returns(returns_df, windows):
    """计算所有日期的平均收益（与之前分析脚本保持一致）"""
    avg_returns = {}
    
    for window in windows:
        total_returns = []
        # 对于每个日期，计算窗口期收益（排除最后window天以确保窗口完整）
        for i in range(len(returns_df) - window):
            window_return = (1 + returns_df.iloc[i:i+window]['return']).prod() - 1
            total_returns.append(window_return)
        
        avg_returns[f'{window}日平均收益'] = np.mean(total_returns)
    
    return avg_returns

def calculate_all_returns():
    """计算所有日期的5、10、20工作日回报率"""
    returns_df = load_data()
    
    # 初始化结果列表
    results = []
    
    # 定义窗口期
    windows = [5, 10, 20]
    
    # 先计算平均收益用于比较
    avg_returns = calculate_average_returns(returns_df, windows)
    print("所有日期平均收益:")
    for key, value in avg_returns.items():
        print(f"- {key}: {value:.4f} ({value*100:.2f}%)")
    print()
    
    # 遍历所有日期（除了最后可能无法计算完整窗口期的日期）
    max_window = max(windows)
    for i in range(len(returns_df) - max_window):
        date = returns_df.iloc[i]['date']
        daily_return = returns_df.iloc[i]['return']
        
        # 计算不同窗口期的收益
        window_returns = {}
        for window in windows:
            total_return = calculate_window_returns(returns_df, date, window)
            window_returns[f'{window}_day_return'] = total_return
        
        results.append({
            'date': date.strftime('%Y-%m-%d'),
            'daily_return': daily_return,
            **window_returns
        })
    
    return pd.DataFrame(results)

def main():
    """主函数"""
    print("正在计算所有日期的5、10、20工作日回报率...")
    
    # 计算所有日期的回报率
    returns_df = calculate_all_returns()
    
    # 保存到CSV文件
    output_file = 'all_dates_returns.csv'
    returns_df.to_csv(output_file, index=False, encoding='utf-8')
    
    print(f"计算完成！结果已保存到 {output_file}")
    print(f"总共计算了 {len(returns_df)} 个日期的回报率")
    print("\n前5行数据预览:")
    print(returns_df.head())

if __name__ == "__main__":
    main()