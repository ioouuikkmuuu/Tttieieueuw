import os
import pandas as pd
import glob
from typing import List, Dict, Optional


class FileSplitter:
    """
    文件分割器类，用于根据指定列标识符分割文件
    
    功能：
    1. 定位文件夹里相应的文件（基于pattern）
    2. 打开文件
    3. 通过split col identifier确定会split成多少份
    4. 进行split
    5. 对数据的其他特殊处理
    6. 输出split后的文件
    """
    
    def __init__(self, file_pattern: str, split_col_identifier: str, output_format: str, 
                 custom_parameters: Optional[Dict[str, str]] = None):
        """
        初始化文件分割器
        
        :param file_pattern: 文件模式（如 "*.csv"）
        :param split_col_identifier: 分割列标识符（列名）
        :param output_format: 输出文件命名格式（如 "output_{value}.csv"）
        :param custom_parameters: 自定义参数字典，用于替换输出格式中的占位符
        """
        self.file_pattern = file_pattern
        self.split_col_identifier = split_col_identifier
        self.output_format = output_format
        self.custom_parameters = custom_parameters or {}
        self.files_found = []
        
    def locate_files(self, directory: str = ".") -> List[str]:
        """
        定位文件夹中符合模式的文件
        
        :param directory: 搜索目录，默认为当前目录
        :return: 符合模式的文件列表
        """
        # 处理文件模式中的自定义参数
        formatted_pattern = self.file_pattern
        for param_name, param_value in self.custom_parameters.items():
            formatted_pattern = formatted_pattern.replace(f"{{{param_name}}}", param_value)
        
        search_pattern = os.path.join(directory, formatted_pattern)
        self.files_found = glob.glob(search_pattern)
        return self.files_found
    
    def split_files(self, directory: str = ".", output_directory: str = "output") -> None:
        """
        分割所有找到的文件
        
        :param directory: 源文件目录
        :param output_directory: 输出目录
        """
        # 确保输出目录存在
        os.makedirs(output_directory, exist_ok=True)
        
        # 定位文件
        files = self.locate_files(directory)
        
        if not files:
            print(f"未找到匹配模式 '{self.file_pattern}' 的文件")
            return
        
        for file_path in files:
            if file_path.endswith(('.xlsx', '.xls')):
                self._split_single_file_excel(file_path, output_directory)
            else:
                self._split_single_file(file_path, output_directory)
    
    def _split_single_file(self, file_path: str, output_directory: str) -> None:
        """
        分割单个文件
        
        :param file_path: 文件路径
        :param output_directory: 输出目录
        """
        try:
            # 读取文件（支持CSV和Excel）
            if file_path.endswith('.csv'):
                df = pd.read_csv(file_path)
            elif file_path.endswith(('.xlsx', '.xls')):
                df = pd.read_excel(file_path)
            else:
                print(f"不支持的文件格式: {file_path}")
                return
            
            # 检查分割列是否存在
            if self.split_col_identifier not in df.columns:
                print(f"列 '{self.split_col_identifier}' 在文件 '{file_path}' 中不存在")
                return
            
            # 获取唯一值以确定分割份数
            unique_values = df[self.split_col_identifier].unique()
            print(f"文件 '{file_path}' 将被分割为 {len(unique_values)} 份")
            
            # 根据唯一值分割文件
            for value in unique_values:
                # 筛选数据
                filtered_df = df[df[self.split_col_identifier] == value].copy()
                
                # 生成输出文件名
                # 首先处理自定义参数
                formatted_output = self.output_format
                for param_name, param_value in self.custom_parameters.items():
                    formatted_output = formatted_output.replace(f"{{{param_name}}}", param_value)
                
                # 然后处理value参数
                output_filename = formatted_output.format(value=value)
                output_path = os.path.join(output_directory, output_filename)
                
                # 保存文件
                if output_path.endswith('.csv'):
                    filtered_df.to_csv(output_path, index=False)
                elif output_path.endswith(('.xlsx', '.xls')):
                    filtered_df.to_excel(output_path, index=False)
                else:
                    # 默认保存为CSV
                    output_path = output_path.replace(os.path.splitext(output_path)[1], '.csv')
                    filtered_df.to_csv(output_path, index=False)
                
                print(f"已保存: {output_path}")
                
        except Exception as e:
            print(f"处理文件 '{file_path}' 时出错: {str(e)}")

    def _split_single_file_excel(self, file_path: str, output_directory: str) -> None:
        """
        分割单个Excel文件，处理多个工作表
        
        :param file_path: Excel文件路径
        :param output_directory: 输出目录
        """
        try:
            # 读取Excel文件的所有工作表
            excel_data = pd.read_excel(file_path, sheet_name=None)
            
            # 获取所有工作表名称
            sheet_names = list(excel_data.keys())
            print(f"文件 '{file_path}' 包含 {len(sheet_names)} 个工作表: {sheet_names}")
            
            # 检查分割列是否在第一个工作表中存在
            first_sheet_df = excel_data[sheet_names[0]]
            if self.split_col_identifier not in first_sheet_df.columns:
                print(f"列 '{self.split_col_identifier}' 在文件 '{file_path}' 中不存在")
                return
            
            # 获取唯一值以确定分割份数
            unique_values = first_sheet_df[self.split_col_identifier].unique()
            print(f"文件 '{file_path}' 将被分割为 {len(unique_values)} 份")
            
            # 根据唯一值分割文件
            for value in unique_values:
                # 生成输出文件名
                # 首先处理自定义参数
                formatted_output = self.output_format
                for param_name, param_value in self.custom_parameters.items():
                    formatted_output = formatted_output.replace(f"{{{param_name}}}", param_value)
                
                # 然后处理value参数
                output_filename = formatted_output.format(value=value)
                output_path = os.path.join(output_directory, output_filename)
                
                # 确保输出文件是Excel格式
                if not output_path.endswith(('.xlsx', '.xls')):
                    # 默认保存为xlsx
                    output_path = output_path.replace(os.path.splitext(output_path)[1], '.xlsx') if '.' in os.path.basename(output_path) else output_path + '.xlsx'
                
                # 为每个工作表筛选数据并写入
                with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                    for sheet_name in sheet_names:
                        sheet_df = excel_data[sheet_name]
                        # 检查分割列是否在当前工作表中存在
                        if self.split_col_identifier in sheet_df.columns:
                            filtered_df = sheet_df[sheet_df[self.split_col_identifier] == value].copy()
                            filtered_df.to_excel(writer, sheet_name=sheet_name, index=False)
                        else:
                            # 如果当前工作表没有分割列，直接复制整个工作表
                            sheet_df.to_excel(writer, sheet_name=sheet_name, index=False)
                
                print(f"已保存: {output_path}")
                
        except Exception as e:
            print(f"处理Excel文件 '{file_path}' 时出错: {str(e)}")


# 使用示例
if __name__ == "__main__":
    # 示例：根据"Category"列分割所有CSV文件
    splitter = FileSplitter(
        file_pattern="*.csv",
        split_col_identifier="Category",
        output_format="split_{value}.csv"
    )
    
    # 执行分割
    splitter.split_files()