import pandas as pd
from file_split import FileSplitter
import os

def create_test_excel_with_multiple_sheets():
    """创建一个包含多个工作表的测试Excel文件"""
    # 创建第一个工作表的数据（包含多个Category）
    data1 = {
        'Product': ['Apple', 'Banana', 'Orange', 'Beef', 'Pork', 'Carrot', 'Potato'],
        'Category': ['Fruit', 'Fruit', 'Fruit', 'Meat', 'Meat', 'Vegetable', 'Vegetable'],
        'Price': [1.2, 0.5, 0.8, 5.0, 6.5, 0.3, 0.2],
        'Quantity': [100, 150, 120, 80, 60, 200, 180]
    }
    df1 = pd.DataFrame(data1)
    
    # 创建第二个工作表的数据（也包含相同的Category）
    data2 = {
        'Product': ['Grape', 'Strawberry', 'Chicken', 'Fish', 'Lettuce', 'Onion'],
        'Category': ['Fruit', 'Fruit', 'Meat', 'Meat', 'Vegetable', 'Vegetable'],
        'Price': [2.0, 3.5, 4.0, 7.0, 0.4, 0.5],
        'Quantity': [80, 50, 90, 70, 150, 120]
    }
    df2 = pd.DataFrame(data2)
    
    # 创建第三个工作表的数据（不包含Category列，用于测试）
    data3 = {
        'Month': ['January', 'February', 'March', 'April', 'May', 'June'],
        'Sales': [1000, 1200, 1100, 1300, 1400, 1500]
    }
    df3 = pd.DataFrame(data3)
    
    # 写入Excel文件的不同工作表
    with pd.ExcelWriter('test_multiple_sheets.xlsx', engine='openpyxl') as writer:
        df1.to_excel(writer, sheet_name='Inventory', index=False)
        df2.to_excel(writer, sheet_name='Additional', index=False)
        df3.to_excel(writer, sheet_name='Sales', index=False)
    
    print("测试Excel文件 'test_multiple_sheets.xlsx' 已创建")

def test_excel_splitter_with_multiple_sheets():
    """测试处理多工作表Excel文件的分割器"""
    print("\n=== 测试处理多工作表Excel文件 ===")
    
    # 创建FileSplitter实例
    splitter = FileSplitter(
        file_pattern="test_multiple_sheets.xlsx",
        split_col_identifier="Category",
        output_format="split_result_{value}.xlsx"
    )
    
    # 执行分割
    splitter.split_files(output_directory="excel_multi_sheet_output")
    
    # 检查输出文件
    output_dir = "excel_multi_sheet_output"
    if os.path.exists(output_dir):
        print(f"\n输出目录 '{output_dir}' 中的文件:")
        for file in sorted(os.listdir(output_dir)):
            print(f"  - {file}")
            
            # 检查每个Excel文件的工作表
            file_path = os.path.join(output_dir, file)
            if file.endswith(('.xlsx', '.xls')):
                excel_data = pd.read_excel(file_path, sheet_name=None)
                sheet_names = list(excel_data.keys())
                print(f"    包含 {len(sheet_names)} 个工作表: {sheet_names}")
                
                # 显示每个工作表的行数
                for sheet_name, sheet_data in excel_data.items():
                    print(f"      {sheet_name}: {len(sheet_data)} 行")

if __name__ == "__main__":
    # 删除之前的测试文件和输出目录
    if os.path.exists('test_multiple_sheets.xlsx'):
        os.remove('test_multiple_sheets.xlsx')
    if os.path.exists('excel_multi_sheet_output'):
        import shutil
        shutil.rmtree('excel_multi_sheet_output')
    
    # 创建测试文件
    create_test_excel_with_multiple_sheets()
    
    # 测试分割功能
    test_excel_splitter_with_multiple_sheets()
    
    print("\n测试完成!")