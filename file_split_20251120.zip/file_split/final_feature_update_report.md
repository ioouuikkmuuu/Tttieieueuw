# 文件分割器功能更新报告

## 更新概述

本次更新为文件分割器(FileSplitter)增加了对Excel多工作表文件的支持，并增强了自定义参数功能。主要更新内容包括：

1. 新增 `_split_single_file_excel()` 方法用于处理Excel多工作表文件
2. 更新 `split_files()` 方法以区分处理Excel和CSV文件
3. 完善自定义参数功能，支持在输出文件名中使用自定义占位符

## 功能详情

### 1. Excel多工作表支持

#### 实现方式
- 新增 `_split_single_file_excel()` 方法
- 该方法使用 `pd.read_excel(file_path, sheet_name=None)` 读取所有工作表
- 对包含分割列的工作表进行数据筛选
- 对不包含分割列的工作表进行完整保留
- 使用 `pd.ExcelWriter` 将处理后的数据写入新的Excel文件

#### 功能特点
- 保持原有的工作表结构
- 支持多个工作表同时处理
- 智能识别哪些工作表需要筛选，哪些需要完整保留

### 2. 自定义参数增强

#### 实现方式
- 在 `__init__` 方法中增加 `custom_parameters` 参数
- 在文件名生成过程中先处理自定义参数，再处理 `{value}` 参数
- 支持任意数量的自定义参数

#### 使用示例
```python
splitter = FileSplitter(
    file_pattern="data.xlsx",
    split_col_identifier="Category",
    output_format="report_{value}_{DATE}_{VERSION}.xlsx",
    custom_parameters={
        "DATE": "20251117",
        "VERSION": "v1.0"
    }
)
```

## 代码变更

### file_split.py

1. 更新 `split_files()` 方法：
   ```python
   def split_files(self, directory: str = ".", output_directory: str = "output") -> None:
       # ...
       for file_path in files:
           if file_path.endswith(('.xlsx', '.xls')):
               self._split_single_file_excel(file_path, output_directory)
           else:
               self._split_single_file(file_path, output_directory)
   ```

2. 新增 `_split_single_file_excel()` 方法：
   - 读取Excel文件的所有工作表
   - 处理包含分割列的工作表（进行数据筛选）
   - 保留不包含分割列的工作表（完整复制）
   - 生成包含所有工作表的输出文件

## 测试验证

### 测试脚本
创建了两个测试脚本验证新功能：
1. `test_excel_multiple_sheets.py` - 基本功能测试
2. `demo_excel_multi_sheet.py` - 综合演示脚本

### 测试结果
- 成功处理包含多个工作表的Excel文件
- 正确筛选包含分割列的工作表数据
- 完整保留不包含分割列的工作表
- 自定义参数功能正常工作
- 输出文件结构正确

## 使用示例

### 基本Excel多工作表分割
```python
splitter = FileSplitter(
    file_pattern="sales_data.xlsx",
    split_col_identifier="Category",
    output_format="category_{value}_report.xlsx"
)
splitter.split_files()
```

### 带自定义参数的分割
```python
splitter = FileSplitter(
    file_pattern="sales_data.xlsx",
    split_col_identifier="Category",
    output_format="report_{value}_{DATE}_{VERSION}.xlsx",
    custom_parameters={
        "DATE": "20251117",
        "VERSION": "v1.0"
    }
)
splitter.split_files()
```

## 依赖更新

确保 `requirements.txt` 包含 `openpyxl>=3.0.7` 以支持Excel文件处理。

## 文档更新

更新了 `README.md` 文件，添加了关于Excel多工作表支持和自定义参数功能的说明。

## 结论

本次更新成功为文件分割器增加了对Excel多工作表文件的支持，并增强了自定义参数功能。新功能经过充分测试，可以稳定使用。用户现在可以：
1. 处理包含多个工作表的Excel文件
2. 在输出文件名中使用自定义参数
3. 享受更灵活的文件分割功能