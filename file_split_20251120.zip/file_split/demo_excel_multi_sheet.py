"""
Excel多工作表分割功能演示脚本
展示如何使用FileSplitter处理包含多个工作表的Excel文件
"""

import pandas as pd
from file_split import FileSplitter
import os

def create_sample_excel_files():
    """创建示例Excel文件用于演示"""
    print("创建示例Excel文件...")
    
    # 创建销售数据（包含多个工作表）
    sales_data_q1 = {
        'Product': ['Laptop', 'Mouse', 'Keyboard', 'Monitor', 'Headphones'],
        'Category': ['Electronics', 'Accessories', 'Accessories', 'Electronics', 'Accessories'],
        'Quarter': ['Q1', 'Q1', 'Q1', 'Q1', 'Q1'],
        'Sales': [15000, 200, 150, 3000, 500]
    }
    
    sales_data_q2 = {
        'Product': ['Laptop', 'Mouse', 'Keyboard', 'Monitor', 'Headphones'],
        'Category': ['Electronics', 'Accessories', 'Accessories', 'Electronics', 'Accessories'],
        'Quarter': ['Q2', 'Q2', 'Q2', 'Q2', 'Q2'],
        'Sales': [18000, 250, 180, 3500, 600]
    }
    
    inventory_data = {
        'Product': ['Laptop', 'Mouse', 'Keyboard', 'Monitor', 'Headphones'],
        'Stock': [50, 200, 150, 30, 100],
        'Supplier': ['TechCorp', 'TechCorp', 'TechCorp', 'DisplayInc', 'AudioPlus']
    }
    
    # 创建Excel文件
    with pd.ExcelWriter('sales_data_multi_sheet.xlsx', engine='openpyxl') as writer:
        pd.DataFrame(sales_data_q1).to_excel(writer, sheet_name='Q1_Sales', index=False)
        pd.DataFrame(sales_data_q2).to_excel(writer, sheet_name='Q2_Sales', index=False)
        pd.DataFrame(inventory_data).to_excel(writer, sheet_name='Inventory', index=False)
    
    print("示例Excel文件 'sales_data_multi_sheet.xlsx' 已创建")

def demo_basic_excel_split():
    """演示基本的Excel多工作表分割功能"""
    print("\n=== 演示1: 基本Excel多工作表分割 ===")
    
    # 创建分割器实例
    splitter = FileSplitter(
        file_pattern="sales_data_multi_sheet.xlsx",
        split_col_identifier="Category",
        output_format="category_{value}_report.xlsx"
    )
    
    # 执行分割
    splitter.split_files(output_directory="demo_output1")
    
    # 显示结果
    print("分割完成，输出文件:")
    for file in sorted(os.listdir("demo_output1")):
        print(f"  - {file}")

def demo_excel_split_with_custom_params():
    """演示带自定义参数的Excel多工作表分割功能"""
    print("\n=== 演示2: 带自定义参数的Excel多工作表分割 ===")
    
    # 定义自定义参数
    custom_params = {
        "REPORT_DATE": "20251117",
        "VERSION": "v1.0"
    }
    
    # 创建分割器实例
    splitter = FileSplitter(
        file_pattern="sales_data_multi_sheet.xlsx",
        split_col_identifier="Category",
        output_format="report_{value}_{REPORT_DATE}_{VERSION}.xlsx",
        custom_parameters=custom_params
    )
    
    # 执行分割
    splitter.split_files(output_directory="demo_output2")
    
    # 显示结果
    print("分割完成，输出文件:")
    for file in sorted(os.listdir("demo_output2")):
        print(f"  - {file}")

def demo_excel_split_preserve_all_sheets():
    """演示保留所有工作表的Excel分割功能"""
    print("\n=== 演示3: 保留所有工作表的Excel分割 ===")
    
    # 创建分割器实例，这次使用不同的分割列
    splitter = FileSplitter(
        file_pattern="sales_data_multi_sheet.xlsx",
        split_col_identifier="Quarter",
        output_format="quarterly_{value}_data.xlsx"
    )
    
    # 执行分割
    splitter.split_files(output_directory="demo_output3")
    
    # 显示结果和详细信息
    print("分割完成，输出文件:")
    for file in sorted(os.listdir("demo_output3")):
        file_path = os.path.join("demo_output3", file)
        print(f"  - {file}")
        
        # 读取并显示每个Excel文件的信息
        excel_data = pd.read_excel(file_path, sheet_name=None)
        for sheet_name, sheet_data in excel_data.items():
            print(f"    工作表 '{sheet_name}': {len(sheet_data)} 行数据")

if __name__ == "__main__":
    # 清理之前的输出
    for dir_name in ["demo_output1", "demo_output2", "demo_output3"]:
        if os.path.exists(dir_name):
            import shutil
            shutil.rmtree(dir_name)
    
    # 创建示例数据
    create_sample_excel_files()
    
    # 运行演示
    demo_basic_excel_split()
    demo_excel_split_with_custom_params()
    demo_excel_split_preserve_all_sheets()
    
    print("\n所有演示完成!")
    print("\n功能说明:")
    print("1. Excel多工作表分割功能可以处理包含多个工作表的Excel文件")
    print("2. 分割时会保持原有的工作表结构")
    print("3. 只对包含分割列的工作表进行数据筛选")
    print("4. 不包含分割列的工作表会被完整保留")
    print("5. 支持自定义参数替换输出文件名中的占位符")