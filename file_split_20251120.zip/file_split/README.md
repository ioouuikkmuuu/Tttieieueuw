# 文件分割器 (File Splitter)

一个基于Python的文件分割工具，可以根据指定列的值将CSV或Excel文件分割成多个文件。

## 功能特点

- 支持CSV和Excel文件格式
- 根据指定列的唯一值进行分割
- 可自定义输出文件命名格式
- 支持Excel多工作表文件处理
- 支持自定义参数替换输出文件名中的占位符
- 自动创建输出目录
- 包含错误处理机制

## 安装依赖

```bash
pip install -r requirements.txt
```

## 使用方法

### 基本用法

```python
from file_split import FileSplitter

# 创建文件分割器实例
splitter = FileSplitter(
    file_pattern="*.csv",              # 文件模式
    split_col_identifier="Category",   # 分割列标识符
    output_format="split_{value}.csv"  # 输出文件命名格式
)

# 执行分割
splitter.split_files()
```

### 参数说明

- `file_pattern`: 文件模式（如 "*.csv" 或 "data*.xlsx"）
- `split_col_identifier`: 分割列标识符（列名）
- `output_format`: 输出文件命名格式，使用 `{value}` 占位符表示列的值
- `custom_parameters` (可选): 自定义参数字典，用于替换输出格式中的占位符

### 示例

假设有一个名为 `sales_data.csv` 的文件：

```csv
Product,Category,Price,Quantity
Apple,Fruit,1.2,100
Banana,Fruit,0.8,150
Carrot,Vegetable,0.5,200
Broccoli,Vegetable,1.5,80
```

使用以下代码进行分割：

```python
splitter = FileSplitter(
    file_pattern="sales_data.csv",
    split_col_identifier="Category",
    output_format="sales_{value}.csv"
)

splitter.split_files()
```

将会生成两个文件：
- `sales_Fruit.csv`
- `sales_Vegetable.csv`

### Excel多工作表支持

工具现在支持处理包含多个工作表的Excel文件。当分割Excel文件时：
- 所有工作表都会被保留在输出文件中
- 只有包含分割列的工作表会根据分割值进行筛选
- 不包含分割列的工作表会被完整保留

### 自定义参数示例

```python
splitter = FileSplitter(
    file_pattern="sales_data.xlsx",
    split_col_identifier="Category",
    output_format="report_{value}_{DATE}_{VERSION}.xlsx",
    custom_parameters={
        "DATE": "20251117",
        "VERSION": "v1.0"
    }
)

splitter.split_files()
```

这将生成包含日期和版本信息的文件名：
- `report_Fruit_20251117_v1.0.xlsx`
- `report_Vegetable_20251117_v1.0.xlsx`

## 方法说明

### `locate_files(directory=".")`
定位文件夹中符合模式的文件

### `split_files(directory=".", output_directory="output")`
分割所有找到的文件

### `_split_single_file(file_path, output_directory)`
分割单个CSV文件（内部方法）

### `_split_single_file_excel(file_path, output_directory)`
分割单个Excel文件，处理多个工作表（内部方法）

## 注意事项

- 确保输入文件格式正确
- 确保指定的列存在于文件中
- 输出目录将自动创建