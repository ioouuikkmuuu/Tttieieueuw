import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime

def load_data():
    """加载SHAP值和收益数据"""
    print("正在加载数据...")
    # 加载SHAP值数据
    shap_df = pd.read_csv('momentum_shap_contributions.csv')
    
    # 加载收益数据
    returns_df = pd.read_csv('all_dates_returns.csv')
    
    print(f"加载了 {len(shap_df)} 行SHAP数据和 {len(returns_df)} 行收益数据")
    return shap_df, returns_df

def analyze_shap_extremes(shap_df, returns_df):
    """分析SHAP值极值日期的市场特征"""
    print("开始分析SHAP值极值日期的市场特征...")
    
    # 合并数据
    merged_df = pd.merge(shap_df, returns_df, on='date', how='inner')
    
    # 为每个动量因子找出SHAP值最大和最小的日期
    factors = ['短期动量', '中期动量', '长期动量']
    windows = ['5_day_return', '10_day_return', '20_day_return']
    window_names = ['5日收益', '10日收益', '20日收益']
    
    results = {}
    
    for factor in factors:
        results[factor] = {}
        
        # 获取SHAP值最大和最小的日期
        max_shap_idx = merged_df[factor].idxmax()
        min_shap_idx = merged_df[factor].idxmin()
        
        max_shap_date = merged_df.loc[max_shap_idx, 'date']
        min_shap_date = merged_df.loc[min_shap_idx, 'date']
        
        max_shap_value = merged_df.loc[max_shap_idx, factor]
        min_shap_value = merged_df.loc[min_shap_idx, factor]
        
        results[factor]['max_date'] = max_shap_date
        results[factor]['min_date'] = min_shap_date
        results[factor]['max_value'] = max_shap_value
        results[factor]['min_value'] = min_shap_value
        
        # 获取这些日期的市场特征（收益）
        max_row = merged_df.loc[max_shap_idx]
        min_row = merged_df.loc[min_shap_idx]
        
        for i, window in enumerate(windows):
            window_name = window_names[i]
            results[factor][f'max_{window_name}'] = max_row[window]
            results[factor][f'min_{window_name}'] = min_row[window]
        
        # 计算统计特征
        results[factor]['mean'] = merged_df[factor].mean()
        results[factor]['std'] = merged_df[factor].std()
        results[factor]['median'] = merged_df[factor].median()
        
        # 计算极值日期与平均值的偏离
        results[factor]['max_deviation'] = abs(max_shap_value - results[factor]['mean']) / results[factor]['std']
        results[factor]['min_deviation'] = abs(min_shap_value - results[factor]['mean']) / results[factor]['std']
    
    return results

def generate_report(results):
    """生成分析报告"""
    print("生成分析报告...")
    
    report_content = "# SHAP值极值日期市场特征分析报告\n\n"
    report_content += f"报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
    
    factors = ['短期动量', '中期动量', '长期动量']
    windows = ['5日收益', '10日收益', '20日收益']
    
    for factor in factors:
        report_content += f"## {factor}分析\n\n"
        report_content += f"- SHAP值最大日期: {results[factor]['max_date']} (值: {results[factor]['max_value']:.6f})\n"
        report_content += f"- SHAP值最小日期: {results[factor]['min_date']} (值: {results[factor]['min_value']:.6f})\n"
        report_content += f"- 平均值: {results[factor]['mean']:.6f}\n"
        report_content += f"- 标准差: {results[factor]['std']:.6f}\n"
        report_content += f"- 中位数: {results[factor]['median']:.6f}\n"
        report_content += f"- 最大值偏离均值: {results[factor]['max_deviation']:.2f}个标准差\n"
        report_content += f"- 最小值偏离均值: {results[factor]['min_deviation']:.2f}个标准差\n\n"
        
        report_content += "### 极值日期收益表现\n"
        for window in windows:
            max_return = results[factor][f'max_{window}']
            min_return = results[factor][f'min_{window}']
            report_content += f"- {window} - 最大SHAP值日期: {max_return:.4f}, 最小SHAP值日期: {min_return:.4f}\n"
        report_content += "\n"
    
    # 保存报告
    with open('shap_extremes_analysis_report.md', 'w', encoding='utf-8') as f:
        f.write(report_content)
    
    print("分析报告已保存为 shap_extremes_analysis_report.md")

def plot_extremes_comparison(results):
    """绘制极值日期对比图"""
    print("绘制极值日期对比图...")
    
    factors = ['短期动量', '中期动量', '长期动量']
    windows = ['5日收益', '10日收益', '20日收益']
    
    # 准备数据
    data = []
    for factor in factors:
        for window in windows:
            max_return = results[factor][f'max_{window}']
            min_return = results[factor][f'min_{window}']
            data.append({
                'Factor': factor,
                'Window': window,
                'Type': '最大SHAP值日期',
                'Return': max_return
            })
            data.append({
                'Factor': factor,
                'Window': window,
                'Type': '最小SHAP值日期',
                'Return': min_return
            })
    
    df = pd.DataFrame(data)
    
    # 创建图表
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    
    plt.figure(figsize=(14, 10))
    sns.barplot(data=df, x='Window', y='Return', hue='Type', palette='Set1')
    plt.title('SHAP值极值日期收益对比')
    plt.ylabel('收益')
    plt.xlabel('收益窗口')
    plt.legend(title='SHAP值类型')
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    # 保存图表
    plt.savefig('shap_extremes_comparison_plot.png', dpi=300, bbox_inches='tight')
    print("极值日期对比图已保存为 shap_extremes_comparison_plot.png")

def main():
    """主函数"""
    # 加载数据
    shap_df, returns_df = load_data()
    
    # 分析SHAP值极值日期的市场特征
    results = analyze_shap_extremes(shap_df, returns_df)
    
    # 生成报告
    generate_report(results)
    
    # 绘制极值日期对比图
    plot_extremes_comparison(results)
    
    # 打印摘要结果
    print("\n=== SHAP值极值日期市场特征分析摘要 ===")
    factors = ['短期动量', '中期动量', '长期动量']
    windows = ['5日收益', '10日收益', '20日收益']
    
    for factor in factors:
        print(f"\n{factor}:")
        print(f"  SHAP值最大日期: {results[factor]['max_date']} (值: {results[factor]['max_value']:.6f})")
        print(f"  SHAP值最小日期: {results[factor]['min_date']} (值: {results[factor]['min_value']:.6f})")
        print(f"  最大值偏离均值: {results[factor]['max_deviation']:.2f}个标准差")
        print(f"  最小值偏离均值: {results[factor]['min_deviation']:.2f}个标准差")
        
        for window in windows:
            max_return = results[factor][f'max_{window}']
            min_return = results[factor][f'min_{window}']
            print(f"  {window} - 最大SHAP值日期: {max_return:.4f}, 最小SHAP值日期: {min_return:.4f}")

if __name__ == "__main__":
    main()