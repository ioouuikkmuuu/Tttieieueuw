import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
from scipy.stats import pearsonr

def load_data():
    """加载SHAP值和收益数据"""
    print("正在加载数据...")
    # 加载SHAP值数据
    shap_df = pd.read_csv('momentum_shap_contributions.csv')
    
    # 加载收益数据
    returns_df = pd.read_csv('all_dates_returns.csv')
    
    print(f"加载了 {len(shap_df)} 行SHAP数据和 {len(returns_df)} 行收益数据")
    return shap_df, returns_df

def analyze_shap_effectiveness(shap_df, returns_df):
    """研究不同时间窗口下SHAP值的有效性"""
    print("开始研究不同时间窗口下SHAP值的有效性...")
    
    # 合并数据
    merged_df = pd.merge(shap_df, returns_df, on='date', how='inner')
    
    # 为每个动量因子分析不同时间窗口下的有效性
    factors = ['短期动量', '中期动量', '长期动量']
    windows = ['5_day_return', '10_day_return', '20_day_return']
    window_names = ['5日收益', '10日收益', '20日收益']
    
    results = {}
    
    for factor in factors:
        results[factor] = {}
        
        # 计算SHAP值与各时间窗口收益的相关性
        for i, window in enumerate(windows):
            window_name = window_names[i]
            
            # 计算皮尔逊相关系数
            corr, p_value = pearsonr(merged_df[factor], merged_df[window])
            
            results[factor][window_name] = {
                'correlation': corr,
                'p_value': p_value,
                'significant': p_value < 0.05
            }
            
            # 计算SHAP值符号与收益符号的一致性
            same_sign = np.sign(merged_df[factor]) == np.sign(merged_df[window])
            consistency = same_sign.mean()
            
            results[factor][f'{window_name}_consistency'] = consistency
            
            # 计算不同SHAP值区间的平均收益
            positive_shap = merged_df[merged_df[factor] > 0]
            negative_shap = merged_df[merged_df[factor] < 0]
            
            pos_mean_return = positive_shap[window].mean()
            neg_mean_return = negative_shap[window].mean()
            
            results[factor][f'{window_name}_positive_return'] = pos_mean_return
            results[factor][f'{window_name}_negative_return'] = neg_mean_return
    
    return results

def generate_report(results):
    """生成分析报告"""
    print("生成分析报告...")
    
    report_content = "# 不同时间窗口下SHAP值有效性分析报告\n\n"
    report_content += f"报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
    
    factors = ['短期动量', '中期动量', '长期动量']
    windows = ['5日收益', '10日收益', '20日收益']
    
    for factor in factors:
        report_content += f"## {factor}分析\n\n"
        
        for window in windows:
            corr = results[factor][window]['correlation']
            p_value = results[factor][window]['p_value']
            significant = results[factor][window]['significant']
            consistency = results[factor][f'{window}_consistency']
            pos_return = results[factor][f'{window}_positive_return']
            neg_return = results[factor][f'{window}_negative_return']
            
            significance_text = "**显著**" if significant else "不显著"
            
            report_content += f"### {window}\n"
            report_content += f"- SHAP值与收益相关性: {corr:.4f} ({significance_text}, p={p_value:.4f})\n"
            report_content += f"- SHAP值符号与收益符号一致性: {consistency:.2%}\n"
            report_content += f"- 正SHAP值日期平均收益: {pos_return:.4f}\n"
            report_content += f"- 负SHAP值日期平均收益: {neg_return:.4f}\n"
            report_content += f"- 差异: {pos_return - neg_return:.4f}\n\n"
    
    # 保存报告
    with open('shap_effectiveness_analysis_report.md', 'w', encoding='utf-8') as f:
        f.write(report_content)
    
    print("分析报告已保存为 shap_effectiveness_analysis_report.md")

def plot_effectiveness(results):
    """绘制有效性分析图"""
    print("绘制有效性分析图...")
    
    factors = ['短期动量', '中期动量', '长期动量']
    windows = ['5日收益', '10日收益', '20日收益']
    
    # 准备相关性数据
    corr_data = []
    consistency_data = []
    diff_data = []
    
    for factor in factors:
        for window in windows:
            corr = results[factor][window]['correlation']
            consistency = results[factor][f'{window}_consistency']
            pos_return = results[factor][f'{window}_positive_return']
            neg_return = results[factor][f'{window}_negative_return']
            diff = pos_return - neg_return
            
            corr_data.append({
                'Factor': factor,
                'Window': window,
                'Correlation': corr
            })
            
            consistency_data.append({
                'Factor': factor,
                'Window': window,
                'Consistency': consistency
            })
            
            diff_data.append({
                'Factor': factor,
                'Window': window,
                'Difference': diff
            })
    
    corr_df = pd.DataFrame(corr_data)
    consistency_df = pd.DataFrame(consistency_data)
    diff_df = pd.DataFrame(diff_data)
    
    # 创建图表
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    
    # 相关性图
    plt.figure(figsize=(18, 5))
    
    plt.subplot(1, 3, 1)
    sns.barplot(data=corr_df, x='Window', y='Correlation', hue='Factor')
    plt.title('SHAP值与收益相关性')
    plt.ylabel('相关系数')
    plt.xlabel('收益窗口')
    plt.legend(title='动量因子')
    plt.xticks(rotation=45)
    
    # 一致性图
    plt.subplot(1, 3, 2)
    sns.barplot(data=consistency_df, x='Window', y='Consistency', hue='Factor')
    plt.title('SHAP值符号与收益符号一致性')
    plt.ylabel('一致性比例')
    plt.xlabel('收益窗口')
    plt.legend(title='动量因子')
    plt.xticks(rotation=45)
    
    # 收益差异图
    plt.subplot(1, 3, 3)
    sns.barplot(data=diff_df, x='Window', y='Difference', hue='Factor')
    plt.title('正负SHAP值日期收益差异')
    plt.ylabel('收益差异')
    plt.xlabel('收益窗口')
    plt.legend(title='动量因子')
    plt.xticks(rotation=45)
    
    plt.tight_layout()
    
    # 保存图表
    plt.savefig('shap_effectiveness_analysis_plot.png', dpi=300, bbox_inches='tight')
    print("有效性分析图已保存为 shap_effectiveness_analysis_plot.png")

def main():
    """主函数"""
    # 加载数据
    shap_df, returns_df = load_data()
    
    # 分析不同时间窗口下SHAP值的有效性
    results = analyze_shap_effectiveness(shap_df, returns_df)
    
    # 生成报告
    generate_report(results)
    
    # 绘制有效性分析图
    plot_effectiveness(results)
    
    # 打印摘要结果
    print("\n=== 不同时间窗口下SHAP值有效性分析摘要 ===")
    factors = ['短期动量', '中期动量', '长期动量']
    windows = ['5日收益', '10日收益', '20日收益']
    
    for factor in factors:
        print(f"\n{factor}:")
        for window in windows:
            corr = results[factor][window]['correlation']
            p_value = results[factor][window]['p_value']
            significant = results[factor][window]['significant']
            consistency = results[factor][f'{window}_consistency']
            pos_return = results[factor][f'{window}_positive_return']
            neg_return = results[factor][f'{window}_negative_return']
            diff = pos_return - neg_return
            
            significance_text = "**显著**" if significant else "不显著"
            print(f"  {window}:")
            print(f"    相关性: {corr:.4f} ({significance_text}, p={p_value:.4f})")
            print(f"    一致性: {consistency:.2%}")
            print(f"    收益差异: {diff:.4f}")

if __name__ == "__main__":
    main()