import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体支持
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

def load_data():
    """加载数据"""
    # 加载SHAP贡献度数据
    shap_df = pd.read_csv('momentum_shap_contributions.csv')
    shap_df['date'] = pd.to_datetime(shap_df['date'])
    
    # 加载原始收益数据
    returns_df = pd.read_csv('data/csi800_daily_returns.csv')
    returns_df['date'] = pd.to_datetime(returns_df['date'])
    returns_df = returns_df.dropna(subset=['return'])  # 移除空值
    
    return shap_df, returns_df

def calculate_cumulative_returns(returns_df):
    """
    计算累积收益
    :param returns_df: 收益数据
    :return: 包含日期和累积收益的DataFrame
    """
    # 按日期排序
    returns_df = returns_df.sort_values('date').reset_index(drop=True)
    
    # 计算累积收益
    returns_df['cumulative_return'] = (1 + returns_df['return']).cumprod() - 1
    
    return returns_df[['date', 'cumulative_return']]

def get_top_shap_dates(shap_df, n=10):
    """
    获取每个因子SHAP贡献值前n的日期（正向和负向分别处理）
    :param shap_df: SHAP贡献度数据
    :param n: 前n个日期
    :return: 包含前n个日期的字典
    """
    factors = ['短期动量', '中期动量', '长期动量']
    top_dates = {
        'positive': {},  # 正向贡献
        'negative': {}   # 负向贡献
    }
    
    for factor in factors:
        # 正向贡献：按SHAP值降序排列
        positive_df = shap_df[shap_df[factor] > 0].copy()
        # 使用nlargest确保正确排序
        top_dates['positive'][factor] = positive_df.nlargest(n, factor)[['date', factor]].copy()
        
        # 负向贡献：按SHAP值升序排列（最负的在前）
        negative_df = shap_df[shap_df[factor] < 0].copy()
        # 使用nsmallest确保正确排序（因为我们要获取最负的值）
        top_dates['negative'][factor] = negative_df.nsmallest(n, factor)[['date', factor]].copy()
    
    return top_dates

def plot_cumulative_returns_with_shap_markers():
    """绘制累积收益图并标注SHAP贡献值前10日期（正向和负向分开）"""
    # 加载数据
    shap_df, returns_df = load_data()
    
    # 计算累积收益
    cumulative_df = calculate_cumulative_returns(returns_df)
    
    # 获取SHAP贡献值前10的日期（正向和负向分开）
    top_shap_dates = get_top_shap_dates(shap_df, 10)
    
    # 创建图表
    fig, ax = plt.subplots(figsize=(16, 9))
    
    # 绘制累积收益曲线
    ax.plot(cumulative_df['date'], cumulative_df['cumulative_return'], 
            color='blue', linewidth=1.5, label='CSI 800 累积收益')
    
    # 为每个因子的前10个正向和负向日期添加标记
    colors_positive = {'短期动量': 'red', '中期动量': 'green', '长期动量': 'orange'}
    colors_negative = {'短期动量': 'purple', '中期动量': 'brown', '长期动量': 'pink'}
    markers = {'短期动量': '^', '中期动量': 's', '长期动量': 'o'}
    
    # 绘制正向贡献标记
    for factor, dates_df in top_shap_dates['positive'].items():
        factor_cumulative = []
        factor_dates = []
        
        for _, row in dates_df.iterrows():
            date = row['date']
            shap_value = row[factor]
            
            # 在累积收益数据中查找对应日期
            match = cumulative_df[cumulative_df['date'] == date]
            if not match.empty:
                factor_dates.append(date)
                factor_cumulative.append(match['cumulative_return'].iloc[0])
        
        # 绘制正向贡献标记
        ax.scatter(factor_dates, factor_cumulative, 
                  color=colors_positive[factor], marker=markers[factor], 
                  s=120, alpha=0.8, 
                  label=f'{factor} 正向贡献前10', 
                  edgecolors='black', linewidth=0.5)
    
    # 绘制负向贡献标记
    for factor, dates_df in top_shap_dates['negative'].items():
        factor_cumulative = []
        factor_dates = []
        
        for _, row in dates_df.iterrows():
            date = row['date']
            shap_value = row[factor]
            
            # 在累积收益数据中查找对应日期
            match = cumulative_df[cumulative_df['date'] == date]
            if not match.empty:
                factor_dates.append(date)
                factor_cumulative.append(match['cumulative_return'].iloc[0])
        
        # 绘制负向贡献标记
        ax.scatter(factor_dates, factor_cumulative, 
                  color=colors_negative[factor], marker=markers[factor], 
                  s=120, alpha=0.8, 
                  label=f'{factor} 负向贡献前10', 
                  edgecolors='black', linewidth=0.5)
    
    # 设置图表属性
    ax.set_title('CSI 800 累积收益与SHAP贡献值前10日期标记（正向与负向分开）', fontsize=16, pad=20)
    ax.set_xlabel('日期', fontsize=12)
    ax.set_ylabel('累积收益', fontsize=12)
    ax.legend(loc='upper left', bbox_to_anchor=(1.02, 1), borderaxespad=0.)
    ax.grid(True, alpha=0.3)
    
    # 格式化x轴日期
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
    ax.xaxis.set_major_locator(mdates.YearLocator())
    plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    # 调整布局
    plt.tight_layout()
    
    # 保存图表
    plt.savefig('csi800_cumulative_returns_with_shap_markers.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("图表已保存为 csi800_cumulative_returns_with_shap_markers.png")
    
    # 打印前10个SHAP贡献值日期的信息
    print("\n各因子SHAP贡献值前10日期（正向贡献）:")
    print("=" * 70)
    
    for factor, dates_df in top_shap_dates['positive'].items():
        print(f"\n{factor} 正向贡献:")
        print("-" * 40)
        for i, (_, row) in enumerate(dates_df.iterrows(), 1):
            date = row['date'].strftime('%Y-%m-%d')
            shap_value = row[factor]
            print(f"{i:2d}. {date} - SHAP值: {shap_value:.6f}")
    
    print("\n\n各因子SHAP贡献值前10日期（负向贡献）:")
    print("=" * 70)
    
    for factor, dates_df in top_shap_dates['negative'].items():
        print(f"\n{factor} 负向贡献:")
        print("-" * 40)
        for i, (_, row) in enumerate(dates_df.iterrows(), 1):
            date = row['date'].strftime('%Y-%m-%d')
            shap_value = row[factor]
            print(f"{i:2d}. {date} - SHAP值: {shap_value:.6f}")

def plot_cumulative_returns_positive_only():
    """绘制只包含正向SHAP贡献的累积收益图"""
    # 加载数据
    shap_df, returns_df = load_data()
    
    # 计算累积收益
    cumulative_df = calculate_cumulative_returns(returns_df)
    
    # 获取SHAP贡献值前10的日期（仅正向）
    top_shap_dates = get_top_shap_dates(shap_df, 10)
    
    # 创建图表
    fig, ax = plt.subplots(figsize=(16, 9))
    
    # 绘制累积收益曲线
    ax.plot(cumulative_df['date'], cumulative_df['cumulative_return'], 
            color='blue', linewidth=1.5, label='CSI 800 累积收益')
    
    # 为每个因子的前10个正向日期添加标记
    colors_positive = {'短期动量': 'red', '中期动量': 'green', '长期动量': 'orange'}
    markers = {'短期动量': '^', '中期动量': 's', '长期动量': 'o'}
    
    # 绘制正向贡献标记
    for factor, dates_df in top_shap_dates['positive'].items():
        factor_cumulative = []
        factor_dates = []
        
        for _, row in dates_df.iterrows():
            date = row['date']
            shap_value = row[factor]
            
            # 在累积收益数据中查找对应日期
            match = cumulative_df[cumulative_df['date'] == date]
            if not match.empty:
                factor_dates.append(date)
                factor_cumulative.append(match['cumulative_return'].iloc[0])
        
        # 绘制正向贡献标记
        ax.scatter(factor_dates, factor_cumulative, 
                  color=colors_positive[factor], marker=markers[factor], 
                  s=120, alpha=0.8, 
                  label=f'{factor} 正向贡献前10', 
                  edgecolors='black', linewidth=0.5)
    
    # 设置图表属性
    ax.set_title('CSI 800 累积收益与SHAP正向贡献值前10日期标记', fontsize=16, pad=20)
    ax.set_xlabel('日期', fontsize=12)
    ax.set_ylabel('累积收益', fontsize=12)
    ax.legend(loc='upper left', bbox_to_anchor=(1.02, 1), borderaxespad=0.)
    ax.grid(True, alpha=0.3)
    
    # 格式化x轴日期
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
    ax.xaxis.set_major_locator(mdates.YearLocator())
    plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    # 调整布局
    plt.tight_layout()
    
    # 保存图表
    plt.savefig('csi800_cumulative_returns_positive_only.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("图表已保存为 csi800_cumulative_returns_positive_only.png")

def plot_cumulative_returns_negative_only():
    """绘制只包含负向SHAP贡献的累积收益图"""
    # 加载数据
    shap_df, returns_df = load_data()
    
    # 计算累积收益
    cumulative_df = calculate_cumulative_returns(returns_df)
    
    # 获取SHAP贡献值前10的日期（仅负向）
    top_shap_dates = get_top_shap_dates(shap_df, 10)
    
    # 创建图表
    fig, ax = plt.subplots(figsize=(16, 9))
    
    # 绘制累积收益曲线
    ax.plot(cumulative_df['date'], cumulative_df['cumulative_return'], 
            color='blue', linewidth=1.5, label='CSI 800 累积收益')
    
    # 为每个因子的前10个负向日期添加标记
    colors_negative = {'短期动量': 'purple', '中期动量': 'brown', '长期动量': 'pink'}
    markers = {'短期动量': '^', '中期动量': 's', '长期动量': 'o'}
    
    # 绘制负向贡献标记
    for factor, dates_df in top_shap_dates['negative'].items():
        factor_cumulative = []
        factor_dates = []
        
        for _, row in dates_df.iterrows():
            date = row['date']
            shap_value = row[factor]
            
            # 在累积收益数据中查找对应日期
            match = cumulative_df[cumulative_df['date'] == date]
            if not match.empty:
                factor_dates.append(date)
                factor_cumulative.append(match['cumulative_return'].iloc[0])
        
        # 绘制负向贡献标记
        ax.scatter(factor_dates, factor_cumulative, 
                  color=colors_negative[factor], marker=markers[factor], 
                  s=120, alpha=0.8, 
                  label=f'{factor} 负向贡献前10', 
                  edgecolors='black', linewidth=0.5)
    
    # 设置图表属性
    ax.set_title('CSI 800 累积收益与SHAP负向贡献值前10日期标记', fontsize=16, pad=20)
    ax.set_xlabel('日期', fontsize=12)
    ax.set_ylabel('累积收益', fontsize=12)
    ax.legend(loc='upper left', bbox_to_anchor=(1.02, 1), borderaxespad=0.)
    ax.grid(True, alpha=0.3)
    
    # 格式化x轴日期
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
    ax.xaxis.set_major_locator(mdates.YearLocator())
    plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    # 调整布局
    plt.tight_layout()
    
    # 保存图表
    plt.savefig('csi800_cumulative_returns_negative_only.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    print("图表已保存为 csi800_cumulative_returns_negative_only.png")

if __name__ == "__main__":
    plot_cumulative_returns_with_shap_markers()
    plot_cumulative_returns_positive_only()
    plot_cumulative_returns_negative_only()