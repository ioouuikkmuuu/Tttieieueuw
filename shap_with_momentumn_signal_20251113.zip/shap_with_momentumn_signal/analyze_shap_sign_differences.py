import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime

def load_data():
    """加载SHAP值和收益数据"""
    print("正在加载数据...")
    # 加载SHAP值数据
    shap_df = pd.read_csv('momentum_shap_contributions.csv')
    
    # 加载收益数据
    returns_df = pd.read_csv('all_dates_returns.csv')
    
    print(f"加载了 {len(shap_df)} 行SHAP数据和 {len(returns_df)} 行收益数据")
    return shap_df, returns_df

def analyze_shap_sign_differences(shap_df, returns_df):
    """分析SHAP值正负日期的市场趋势差异"""
    print("开始分析SHAP值正负日期的市场趋势差异...")
    
    # 合并数据
    merged_df = pd.merge(shap_df, returns_df, on='date', how='inner')
    
    # 为每个动量因子分析正负SHAP值的收益差异
    factors = ['短期动量', '中期动量', '长期动量']
    windows = ['5_day_return', '10_day_return', '20_day_return']
    window_names = ['5日收益', '10日收益', '20日收益']
    
    results = {}
    
    for factor in factors:
        results[factor] = {}
        
        # 根据SHAP值符号分组
        positive_shap = merged_df[merged_df[factor] > 0]
        negative_shap = merged_df[merged_df[factor] < 0]
        
        results[factor]['positive_count'] = len(positive_shap)
        results[factor]['negative_count'] = len(negative_shap)
        
        # 计算各组的平均收益
        for i, window in enumerate(windows):
            window_name = window_names[i]
            pos_mean = positive_shap[window].mean()
            neg_mean = negative_shap[window].mean()
            
            results[factor][f'{window_name}_positive_mean'] = pos_mean
            results[factor][f'{window_name}_negative_mean'] = neg_mean
            results[factor][f'{window_name}_diff'] = pos_mean - neg_mean
            
            # 进行t检验
            from scipy.stats import ttest_ind
            t_stat, p_value = ttest_ind(positive_shap[window].dropna(), negative_shap[window].dropna())
            results[factor][f'{window_name}_t_stat'] = t_stat
            results[factor][f'{window_name}_p_value'] = p_value
    
    return results

def generate_report(results):
    """生成分析报告"""
    print("生成分析报告...")
    
    report_content = "# SHAP值正负日期市场趋势差异分析报告\n\n"
    report_content += f"报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
    
    factors = ['短期动量', '中期动量', '长期动量']
    windows = ['5日收益', '10日收益', '20日收益']
    
    for factor in factors:
        report_content += f"## {factor}分析\n\n"
        report_content += f"- 正SHAP值日期数量: {results[factor]['positive_count']}\n"
        report_content += f"- 负SHAP值日期数量: {results[factor]['negative_count']}\n\n"
        
        for window in windows:
            pos_mean = results[factor][f'{window}_positive_mean']
            neg_mean = results[factor][f'{window}_negative_mean']
            diff = results[factor][f'{window}_diff']
            p_value = results[factor][f'{window}_p_value']
            
            significance = "**显著**" if p_value < 0.05 else "不显著"
            
            report_content += f"### {window}\n"
            report_content += f"- 正SHAP值日期平均收益: {pos_mean:.4f}\n"
            report_content += f"- 负SHAP值日期平均收益: {neg_mean:.4f}\n"
            report_content += f"- 差异(正-负): {diff:.4f}\n"
            report_content += f"- 统计显著性: {significance} (p={p_value:.4f})\n\n"
    
    # 保存报告
    with open('shap_sign_differences_report.md', 'w', encoding='utf-8') as f:
        f.write(report_content)
    
    print("分析报告已保存为 shap_sign_differences_report.md")

def plot_differences(results):
    """绘制正负SHAP值收益差异图"""
    print("绘制正负SHAP值收益差异图...")
    
    factors = ['短期动量', '中期动量', '长期动量']
    windows = ['5日收益', '10日收益', '20日收益']
    
    # 准备数据
    data = []
    for factor in factors:
        for window in windows:
            diff = results[factor][f'{window}_diff']
            data.append({
                'Factor': factor,
                'Window': window,
                'Difference': diff
            })
    
    df = pd.DataFrame(data)
    
    # 创建图表
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    
    plt.figure(figsize=(12, 8))
    sns.barplot(data=df, x='Window', y='Difference', hue='Factor')
    plt.title('正负SHAP值日期收益差异')
    plt.ylabel('收益差异 (正SHAP - 负SHAP)')
    plt.xlabel('收益窗口')
    plt.legend(title='动量因子')
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    # 保存图表
    plt.savefig('shap_sign_differences_plot.png', dpi=300, bbox_inches='tight')
    print("差异图已保存为 shap_sign_differences_plot.png")

def main():
    """主函数"""
    # 加载数据
    shap_df, returns_df = load_data()
    
    # 分析SHAP值正负日期的市场趋势差异
    results = analyze_shap_sign_differences(shap_df, returns_df)
    
    # 生成报告
    generate_report(results)
    
    # 绘制差异图
    plot_differences(results)
    
    # 打印摘要结果
    print("\n=== SHAP值正负日期市场趋势差异分析摘要 ===")
    factors = ['短期动量', '中期动量', '长期动量']
    windows = ['5日收益', '10日收益', '20日收益']
    
    for factor in factors:
        print(f"\n{factor}:")
        for window in windows:
            diff = results[factor][f'{window}_diff']
            p_value = results[factor][f'{window}_p_value']
            
            significance = "**显著**" if p_value < 0.05 else "不显著"
            print(f"  {window}: 差异 = {diff:.4f} ({significance}, p={p_value:.4f})")

if __name__ == "__main__":
    main()