import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

def load_data():
    """加载SHAP值和市场指标数据"""
    print("正在加载数据...")
    
    # 加载SHAP值数据
    shap_df = pd.read_csv('momentum_shap_contributions.csv')
    shap_df['date'] = pd.to_datetime(shap_df['date'])
    
    # 加载收益数据
    returns_df = pd.read_csv('all_dates_returns.csv')
    returns_df['date'] = pd.to_datetime(returns_df['date'])
    
    # 加载CSI800日收益数据（包含市场指标）
    market_df = pd.read_csv('data/csi800_daily_returns.csv')
    market_df['date'] = pd.to_datetime(market_df['date'])
    
    print(f"SHAP数据加载完成，共{len(shap_df)}条记录")
    print(f"收益数据加载完成，共{len(returns_df)}条记录")
    print(f"市场指标数据加载完成，共{len(market_df)}条记录")
    
    return shap_df, returns_df, market_df

def calculate_market_indicators(market_df):
    """计算市场指标"""
    print("正在计算市场指标...")
    
    # 计算波动率指标（20日历史波动率）
    market_df = market_df.sort_values('date')
    market_df['volatility_20d'] = market_df['return'].rolling(window=20).std()
    
    # 计算市场动量（20日收益）
    market_df['market_momentum_20d'] = market_df['return'].rolling(window=20).sum()
    
    print("市场指标计算完成")
    return market_df

def analyze_shap_with_market_indicators(shap_df, market_df):
    """分析SHAP值与市场指标的关系"""
    print("正在分析SHAP值与市场指标的关系...")
    
    # 合并数据
    merged_df = pd.merge(shap_df, market_df[['date', 'return', 'volatility_20d', 'market_momentum_20d']], on='date', how='inner')
    
    # 分析结果存储
    results = {}
    
    # 对每个动量因子进行分析
    factors = ['短期动量', '中期动量', '长期动量']
    market_indicators = ['return', 'volatility_20d', 'market_momentum_20d']
    indicator_names = ['日收益', '20日波动率', '20日市场动量']
    
    for factor in factors:
        results[factor] = {}
        for i, indicator in enumerate(market_indicators):
            # 移除缺失值
            clean_data = merged_df[[factor, indicator]].dropna()
            
            if len(clean_data) > 10:  # 确保有足够的数据点
                # 计算相关系数
                correlation, p_value = stats.pearsonr(clean_data[factor], clean_data[indicator])
                
                # 计算均值差异（按SHAP值正负分组）
                positive_shap = clean_data[clean_data[factor] > 0][indicator]
                negative_shap = clean_data[clean_data[factor] <= 0][indicator]
                
                mean_diff = positive_shap.mean() - negative_shap.mean()
                mean_diff_p_value = stats.ttest_ind(positive_shap, negative_shap).pvalue
                
                results[factor][indicator_names[i]] = {
                    'correlation': correlation,
                    'p_value': p_value,
                    'mean_diff': mean_diff,
                    'mean_diff_p_value': mean_diff_p_value,
                    'count': len(clean_data)
                }
            else:
                results[factor][indicator_names[i]] = {
                    'correlation': np.nan,
                    'p_value': np.nan,
                    'mean_diff': np.nan,
                    'mean_diff_p_value': np.nan,
                    'count': len(clean_data)
                }
    
    print("SHAP值与市场指标关系分析完成")
    return results, merged_df

def generate_report(results):
    """生成分析报告"""
    print("\n=== SHAP值与市场指标关系分析报告 ===\n")
    
    factors = ['短期动量', '中期动量', '长期动量']
    indicators = ['日收益', '20日波动率', '20日市场动量']
    
    for factor in factors:
        print(f"## {factor}因子分析结果\n")
        
        for indicator in indicators:
            result = results[factor][indicator]
            if not np.isnan(result['correlation']):
                print(f"### 与{indicator}的关系")
                print(f"- 相关系数: {result['correlation']:.4f}")
                print(f"- p值: {result['p_value']:.4f}")
                print(f"- 正SHAP值日期的平均{indicator}: {result['mean_diff']:.6f}")
                print(f"- 正负SHAP值日期{indicator}差异的p值: {result['mean_diff_p_value']:.4f}")
                print(f"- 样本数量: {result['count']}\n")
            else:
                print(f"### 与{indicator}的关系")
                print("- 数据不足，无法计算\n")
    
    # 保存报告到文件
    with open('shap_market_indicators_analysis_report.md', 'w', encoding='utf-8') as f:
        f.write("# SHAP值与市场指标关系分析报告\n\n")
        
        for factor in factors:
            f.write(f"## {factor}因子分析结果\n\n")
            
            for indicator in indicators:
                result = results[factor][indicator]
                if not np.isnan(result['correlation']):
                    f.write(f"### 与{indicator}的关系\n")
                    f.write(f"- 相关系数: {result['correlation']:.4f}\n")
                    f.write(f"- p值: {result['p_value']:.4f}\n")
                    f.write(f"- 正SHAP值日期的平均{indicator}: {result['mean_diff']:.6f}\n")
                    f.write(f"- 正负SHAP值日期{indicator}差异的p值: {result['mean_diff_p_value']:.4f}\n")
                    f.write(f"- 样本数量: {result['count']}\n\n")
                else:
                    f.write(f"### 与{indicator}的关系\n")
                    f.write("- 数据不足，无法计算\n\n")
    
    print("分析报告已保存至 shap_market_indicators_analysis_report.md")

def plot_relationships(results, merged_df):
    """绘制关系图"""
    print("正在生成关系图...")
    
    factors = ['短期动量', '中期动量', '长期动量']
    indicators = ['return', 'volatility_20d', 'market_momentum_20d']
    indicator_names = ['日收益', '20日波动率', '20日市场动量']
    
    # 创建图表
    fig, axes = plt.subplots(3, 3, figsize=(18, 15))
    fig.suptitle('SHAP值与市场指标关系分析', fontsize=16, fontweight='bold')
    
    for i, factor in enumerate(factors):
        for j, indicator in enumerate(indicators):
            ax = axes[i, j]
            
            # 移除缺失值
            clean_data = merged_df[[factor, indicator]].dropna()
            
            if len(clean_data) > 10:
                # 绘制散点图
                ax.scatter(clean_data[factor], clean_data[indicator], alpha=0.6, s=10)
                
                # 添加趋势线
                try:
                    z = np.polyfit(clean_data[factor], clean_data[indicator], 1)
                    p = np.poly1d(z)
                    ax.plot(clean_data[factor], p(clean_data[factor]), "r--", alpha=0.8)
                except:
                    pass
                
                # 设置标题和标签
                correlation = results[factor][indicator_names[j]]['correlation']
                ax.set_title(f'{factor} vs {indicator_names[j]}\n相关系数: {correlation:.3f}')
                ax.set_xlabel(f'{factor} SHAP值')
                ax.set_ylabel(indicator_names[j])
            else:
                ax.set_title(f'{factor} vs {indicator_names[j]}\n(数据不足)')
                ax.text(0.5, 0.5, '数据不足', ha='center', va='center', transform=ax.transAxes)
    
    plt.tight_layout()
    plt.savefig('shap_market_indicators_relationships.png', dpi=300, bbox_inches='tight')
    plt.close()
    print("关系图已保存至 shap_market_indicators_relationships.png")

def main():
    """主函数"""
    print("开始分析SHAP值与市场指标的关系...")
    
    # 加载数据
    shap_df, returns_df, market_df = load_data()
    
    # 计算市场指标
    market_df = calculate_market_indicators(market_df)
    
    # 分析SHAP值与市场指标的关系
    results, merged_df = analyze_shap_with_market_indicators(shap_df, market_df)
    
    # 生成报告
    generate_report(results)
    
    # 绘制关系图
    plot_relationships(results, merged_df)
    
    print("\n分析完成！")
    print("请查看生成的报告文件: shap_market_indicators_analysis_report.md")
    print("请查看生成的图表文件: shap_market_indicators_relationships.png")

if __name__ == "__main__":
    main()