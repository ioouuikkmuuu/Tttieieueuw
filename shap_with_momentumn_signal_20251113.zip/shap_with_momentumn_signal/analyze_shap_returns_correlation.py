#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
分析SHAP值与未来收益的相关性
此脚本计算不同动量因子的SHAP值与未来收益之间的相关性
"""

import pandas as pd
import numpy as np
from scipy.stats import pearsonr, spearmanr
import matplotlib.pyplot as plt
import seaborn as sns

def load_data():
    """加载SHAP贡献值和收益数据"""
    # 读取SHAP贡献值数据
    shap_df = pd.read_csv('momentum_shap_contributions.csv')
    shap_df['date'] = pd.to_datetime(shap_df['date'])
    
    # 读取收益数据
    returns_df = pd.read_csv('all_dates_returns.csv')
    returns_df['date'] = pd.to_datetime(returns_df['date'])
    
    return shap_df, returns_df

def calculate_correlations(shap_df, returns_df):
    """计算SHAP值与未来收益的相关性"""
    # 合并数据
    merged_df = pd.merge(shap_df, returns_df, on='date', how='inner')
    
    # 定义动量因子和收益列
    momentum_factors = ['短期动量', '中期动量', '长期动量']
    return_windows = ['5_day_return', '10_day_return', '20_day_return']
    window_mapping = {
        '5日收益': '5_day_return',
        '10日收益': '10_day_return',
        '20日收益': '20_day_return'
    }
    
    # 存储相关性结果
    correlation_results = {}
    
    # 计算每个因子与各时间窗口收益的相关性
    for factor in momentum_factors:
        correlation_results[factor] = {}
        for window in return_windows:
            # 获取非空数据
            mask = merged_df[factor].notna() & merged_df[window].notna()
            factor_values = merged_df.loc[mask, factor]
            return_values = merged_df.loc[mask, window]
            
            # 计算皮尔逊相关系数和斯皮尔曼相关系数
            if len(factor_values) > 1:
                pearson_corr, pearson_p = pearsonr(factor_values, return_values)
                spearman_corr, spearman_p = spearmanr(factor_values, return_values)
                
                correlation_results[factor][window] = {
                    'pearson': (pearson_corr, pearson_p),
                    'spearman': (spearman_corr, spearman_p),
                    'count': len(factor_values)
                }
            else:
                correlation_results[factor][window] = {
                    'pearson': (np.nan, np.nan),
                    'spearman': (np.nan, np.nan),
                    'count': len(factor_values)
                }
    
    return correlation_results, merged_df

def generate_correlation_report(correlation_results):
    """生成相关性分析报告"""
    report = "# SHAP值与未来收益相关性分析报告\n\n"
    report += "## 相关性分析结果\n\n"
    
    momentum_factors = ['短期动量', '中期动量', '长期动量']
    return_windows = ['5_day_return', '10_day_return', '20_day_return']
    window_names = ['5日收益', '10日收益', '20日收益']
    
    for i, factor in enumerate(momentum_factors):
        report += f"### {factor}相关性分析\n\n"
        report += "| 收益窗口 | Pearson相关系数 | Pearson显著性(p值) | Spearman相关系数 | Spearman显著性(p值) | 样本数 |\n"
        report += "|----------|----------------|--------------------|------------------|---------------------|--------|\n"
        
        for j, window in enumerate(return_windows):
            corr_data = correlation_results[factor][window]
            pearson_corr, pearson_p = corr_data['pearson']
            spearman_corr, spearman_p = corr_data['spearman']
            count = corr_data['count']
            
            # 格式化数值
            pearson_corr_str = f"{pearson_corr:.4f}" if not np.isnan(pearson_corr) else "N/A"
            pearson_p_str = f"{pearson_p:.4f}" if not np.isnan(pearson_p) else "N/A"
            spearman_corr_str = f"{spearman_corr:.4f}" if not np.isnan(spearman_corr) else "N/A"
            spearman_p_str = f"{spearman_p:.4f}" if not np.isnan(spearman_p) else "N/A"
            
            report += f"| {window_names[j]} | {pearson_corr_str} | {pearson_p_str} | {spearman_corr_str} | {spearman_p_str} | {count} |\n"
        report += "\n"
    
    return report

def plot_correlation_heatmap(correlation_results):
    """绘制相关性热力图"""
    # 准备数据
    momentum_factors = ['短期动量', '中期动量', '长期动量']
    return_windows = ['5日收益', '10日收益', '20日收益']
    window_mapping = {
        '5日收益': '5_day_return',
        '10日收益': '10_day_return',
        '20日收益': '20_day_return'
    }
    
    # 提取皮尔逊相关系数
    pearson_data = []
    for factor in momentum_factors:
        row = []
        for window_name in return_windows:
            window = window_mapping[window_name]
            corr_data = correlation_results[factor][window]
            corr, _ = corr_data['pearson']
            row.append(corr if not np.isnan(corr) else 0)
        pearson_data.append(row)
    
    # 创建热力图
    plt.figure(figsize=(10, 6))
    sns.heatmap(pearson_data, 
                xticklabels=return_windows, 
                yticklabels=momentum_factors,
                annot=True, 
                fmt='.4f', 
                cmap='RdYlBu_r',
                center=0,
                vmin=-1, 
                vmax=1)
    plt.title('SHAP值与未来收益相关性热力图 (Pearson相关系数)')
    plt.tight_layout()
    plt.savefig('shap_returns_correlation_heatmap.png', dpi=300, bbox_inches='tight')
    plt.close()

def main():
    """主函数"""
    print("开始分析SHAP值与未来收益的相关性...")
    
    # 加载数据
    shap_df, returns_df = load_data()
    print(f"加载了 {len(shap_df)} 行SHAP数据和 {len(returns_df)} 行收益数据")
    
    # 计算相关性
    correlation_results, merged_df = calculate_correlations(shap_df, returns_df)
    print("相关性计算完成")
    
    # 生成报告
    report = generate_correlation_report(correlation_results)
    
    # 保存报告
    with open('shap_returns_correlation_report.md', 'w', encoding='utf-8') as f:
        f.write(report)
    print("相关性分析报告已保存为 shap_returns_correlation_report.md")
    
    # 绘制热力图
    plot_correlation_heatmap(correlation_results)
    print("相关性热力图已保存为 shap_returns_correlation_heatmap.png")
    
    # 打印摘要结果
    print("\n=== 相关性分析摘要 ===")
    momentum_factors = ['短期动量', '中期动量', '长期动量']
    return_windows = ['5_day_return', '10_day_return', '20_day_return']
    window_mapping = {
        '5日收益': '5_day_return',
        '10日收益': '10_day_return',
        '20日收益': '20_day_return'
    }
    window_names = ['5日收益', '10日收益', '20日收益']
    
    for i, factor in enumerate(momentum_factors):
        print(f"\n{factor}:")
        for j, window_name in enumerate(window_names):
            window = window_mapping[window_name]
            corr_data = correlation_results[factor][window]
            pearson_corr, pearson_p = corr_data['pearson']
            spearman_corr, spearman_p = corr_data['spearman']
            
            if not np.isnan(pearson_corr):
                significance = "**显著**" if pearson_p < 0.05 else "不显著"
                print(f"  {window_name}: Pearson相关系数 = {pearson_corr:.4f} ({significance}, p={pearson_p:.4f})")
            else:
                print(f"  {window_name}: 数据不足，无法计算相关性")

if __name__ == "__main__":
    main()