import logging
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from datetime import datetime

# 配置日志
def setup_logging():
    """设置日志配置"""
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('model.log'),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

def plot_cumulative_returns(predictions, actuals, title="Cumulative Returns Comparison"):
    """绘制累计收益曲线"""
    # 计算累计收益
    pred_cumulative = (1 + predictions).cumprod()
    actual_cumulative = (1 + actuals).cumprod()
    
    # 绘图
    plt.figure(figsize=(12, 6))
    plt.plot(pred_cumulative, label='Predicted Strategy', linewidth=2)
    plt.plot(actual_cumulative, label='Actual Returns', linewidth=2)
    plt.title(title)
    plt.xlabel('Time')
    plt.ylabel('Cumulative Returns')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig('plots/cumulative_returns.png')
    plt.close()

def plot_scatter_predictions(predictions, actuals, title="Predicted vs Actual Returns"):
    """绘制预测值与实际值的散点图"""
    plt.figure(figsize=(10, 8))
    plt.scatter(actuals, predictions, alpha=0.6)
    plt.xlabel('Actual Returns')
    plt.ylabel('Predicted Returns')
    plt.title(title)
    # 添加y=x参考线
    min_val = min(min(predictions), min(actuals))
    max_val = max(max(predictions), max(actuals))
    plt.plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=1)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig('plots/prediction_scatter.png')
    plt.close()

def ensure_dir_exists(dir_path):
    """确保目录存在，如果不存在则创建"""
    import os
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)