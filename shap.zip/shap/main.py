import pandas as pd
import numpy as np
import os
import logging
from datetime import datetime

# 导入自定义模块
from utils import setup_logging, ensure_dir_exists
from data_fetch import fetch_and_preprocess_data, split_data, zscore_normalize
from factor import calculate_factors, normalize_factors, prepare_feature_matrix
from train import train_xgboost_model, cross_validate_model, predict_with_model, save_model
from evaluate import calculate_regression_metrics, calculate_financial_metrics, plot_cumulative_returns, plot_prediction_scatter, generate_evaluation_report
from shap_analysis import calculate_shap_values, plot_shap_summary, plot_shap_dependence, analyze_shap_contributions
from trading_signal import generate_trading_signals, filter_significant_signals, save_signals_to_csv, analyze_signal_performance, plot_signal_returns

def main():
    """
    主函数：执行完整的量价价值+动量因子模型预测流程
    """
    # 设置日志
    logger = setup_logging()
    logger.info("========== 量价价值+动量因子模型预测系统 ==========")
    
    # 确保必要的目录存在
    ensure_dir_exists('plots')
    
    try:
        # 1. 数据获取与预处理
        logger.info("步骤1: 数据获取与预处理")
        # 注意：请替换为您的Tushare Token
        TS_TOKEN = '2876ea85cb005fb5fa17c809a98174f2d5aae8b1f830110a5ead6211'  # 请在此处填入您的Tushare Token
        
        # 获取数据
        df = fetch_and_preprocess_data(TS_TOKEN, start_date='20100101', end_date='20251109')
        
        # 分割数据集
        train_df, val_df, test_df = split_data(df, train_end='20201231', val_end='20231231')
        
        # 2. 因子工程
        logger.info("步骤2: 因子工程")
        # 计算因子
        train_df = calculate_factors(train_df)
        val_df = calculate_factors(val_df)
        test_df = calculate_factors(test_df)
        
        # 因子标准化
        train_df = normalize_factors(train_df)
        val_df = normalize_factors(val_df)
        test_df = normalize_factors(test_df)
        
        # 准备特征矩阵
        X_train = prepare_feature_matrix(train_df)
        X_val = prepare_feature_matrix(val_df)
        X_test = prepare_feature_matrix(test_df)
        
        # 准备目标变量
        y_train = train_df['target']
        y_val = val_df['target']
        y_test = test_df['target']
        
        # 3. 模型训练
        logger.info("步骤3: 模型训练")
        # 训练模型
        model = train_xgboost_model(X_train, y_train, X_val, y_val)
        
        # 保存模型
        save_model(model, 'model.pkl')
        
        # 4. 模型预测
        logger.info("步骤4: 模型预测")
        # 在测试集上进行预测
        test_predictions = predict_with_model(model, X_test)
        
        # 5. 模型评估
        logger.info("步骤5: 模型评估")
        # 计算回归评估指标
        regression_metrics = calculate_regression_metrics(y_test, test_predictions)
        
        # 计算金融评估指标
        financial_metrics, strategy_returns, benchmark_returns = calculate_financial_metrics(
            test_df['return'].values, test_predictions)
        
        # 生成评估报告
        evaluation_report = generate_evaluation_report(regression_metrics, financial_metrics)
        print(evaluation_report)
        
        # 保存评估报告到文件
        with open('evaluation_report.txt', 'w') as f:
            f.write(evaluation_report)
        
        # 绘制评估图表
        plot_cumulative_returns(strategy_returns, benchmark_returns, test_df['trade_date'].values)
        plot_prediction_scatter(y_test, test_predictions)
        
        # 6. SHAP解释
        logger.info("步骤6: SHAP解释")
        # 计算SHAP值
        shap_values, explainer = calculate_shap_values(model, X_test)
        
        # 绘制SHAP摘要图
        plot_shap_summary(shap_values, X_test)
        
        # 绘制SHAP依赖图
        plot_shap_dependence(shap_values, X_test)
        
        # 分析SHAP贡献
        shap_analysis = analyze_shap_contributions(shap_values, X_test, threshold=0.01)
        logger.info(f"SHAP分析结果: {shap_analysis}")
        
        # 7. 信号生成
        logger.info("步骤7: 信号生成")
        # 生成交易信号
        test_dates = test_df['trade_date']
        signals_df = generate_trading_signals(
            test_dates, test_predictions, shap_values, X_test,
            value_threshold=0.01, mom_threshold=0.01, pred_threshold=0.05)
        
        # 过滤显著信号
        significant_signals = filter_significant_signals(signals_df, min_delta_shap=0.01)
        
        # 保存信号到CSV
        save_signals_to_csv(signals_df, 'signals_all.csv')
        save_signals_to_csv(significant_signals, 'signals_significant.csv')
        
        # 分析信号表现
        signal_performance = analyze_signal_performance(signals_df, test_df['return'].values)
        logger.info(f"信号表现: {signal_performance}")
        
        # 绘制信号收益曲线
        plot_signal_returns(signals_df, test_df['return'].values)
        
        logger.info("========== 执行完成 ==========")
        print("模型训练、评估和信号生成已完成！")
        print("请查看以下输出文件：")
        print("- raw_index_data.csv: 从Tushare下载的原始数据")
        print("- evaluation_report.txt: 模型评估报告")
        print("- model.pkl: 训练好的模型")
        print("- signals_all.csv: 所有生成的信号")
        print("- signals_significant.csv: 显著信号")
        print("- plots/ 目录: 包含所有图表")
        
    except Exception as e:
        logger.error(f"程序执行出错: {str(e)}")
        raise

if __name__ == "__main__":
    main()