# 量价价值+动量因子模型预测系统

## 项目概述

本项目基于中证800指数的量价数据，构建价值与动量因子，使用XGBoost模型预测下一交易日回报。通过SHAP解释因子贡献，并在因子贡献发生剧变时生成交易信号。

## 功能特性

1. **数据获取与预处理**：从Tushare获取中证800指数日频数据，进行清洗和标准化处理
2. **因子工程**：构建价值因子、动量因子和波动率因子
3. **模型训练**：使用XGBoost回归模型进行训练，支持时间序列交叉验证
4. **模型评估**：提供回归指标和金融指标评估，包括夏普比率、最大回撤等
5. **SHAP解释**：使用SHAP库解释模型预测，分析因子贡献
6. **信号生成**：在因子贡献剧变时生成交易信号

## 项目结构

```
.
├── main.py              # 主程序入口
├── data_fetch.py        # 数据获取和预处理模块
├── factor.py            # 因子计算模块
├── train.py             # 模型训练模块
├── evaluate.py          # 模型评估模块
├── shap_analysis.py     # SHAP分析模块
├── trading_signal.py    # 信号生成模块
├── utils.py             # 工具函数模块
├── requirements.txt     # 项目依赖
├── README.md            # 项目说明文档
├── model.pkl            # 训练好的模型（运行后生成）
├── shap_analysis_demo.ipynb  # SHAP分析演示Jupyter Notebook
├── SHAP_ANALYSIS_SUMMARY.md  # SHAP分析总结报告
```

## 安装依赖

```bash
pip install -r requirements.txt
```

## 使用方法

### 1. 运行完整流程

```bash
python main.py
```

### 2. 运行SHAP分析演示

```bash
jupyter notebook shap_analysis_demo.ipynb
```

## 输出文件

- `raw_index_data.csv`: 从Tushare下载的原始中证800指数数据
- `evaluation_report.txt`: 模型评估报告
- `model.pkl`: 训练好的模型（运行后生成）
- `signals_all.csv`: 所有生成的信号
- `signals_significant.csv`: 显著信号
- `plots/`: 包含所有图表
  - `cumulative_returns.png`: 累计收益对比图
  - `prediction_scatter.png`: 预测值与实际值散点图
  - `shap_summary.png`: SHAP摘要图
  - `shap_dependence_*.png`: SHAP依赖图
  - `signal_returns.png`: 信号收益曲线
- `SHAP_ANALYSIS_SUMMARY.md`: SHAP分析总结报告
- `shap_analysis_demo.ipynb`: SHAP分析演示Jupyter Notebook

## SHAP显著变化时间点

根据分析，SHAP值发生显著变化的时间点包括：

1. **2024-01-03**：价值因子引发买入信号
2. **2024-10-28至2024-10-30**：波动率因子连续显著变化

详细分析请查看`SHAP_ANALYSIS_SUMMARY.md`文件或运行`shap_analysis_demo.ipynb`演示。
