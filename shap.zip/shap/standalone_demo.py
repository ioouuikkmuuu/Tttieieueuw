import pandas as pd
import numpy as np
import os
import logging
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns
import pickle

# 简单的日志设置
def setup_logging():
    """设置日志配置"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('model.log'),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

def ensure_dir_exists(dir_path):
    """确保目录存在，如果不存在则创建"""
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)

def generate_demo_data():
    """
    生成演示数据
    """
    np.random.seed(42)
    dates = pd.date_range('2010-01-01', '2025-11-09', freq='D')
    n = len(dates)
    
    # 生成价格数据（随机游走）
    returns = np.random.normal(0.0005, 0.02, n)
    prices = 1000 * np.cumprod(1 + returns)
    
    # 生成成交量数据
    volumes = np.random.lognormal(mean=10, sigma=0.5, size=n)
    
    # 构造DataFrame
    df = pd.DataFrame({
        'trade_date': dates,
        'open': prices * np.random.normal(1.0, 0.01, n),
        'high': prices * np.random.normal(1.05, 0.02, n),
        'low': prices * np.random.normal(0.95, 0.02, n),
        'close': prices,
        'vol': volumes,
        'amount': volumes * prices
    })
    
    # 计算回报率
    df['return'] = df['close'].pct_change()
    
    # 目标变量：下一交易日回报
    df['target'] = df['return'].shift(-1)
    
    return df

def calculate_factors(df):
    """
    计算价值因子、动量因子和波动率因子
    """
    data = df.copy()
    
    # 计算20日平均成交量
    data['mean_vol_20'] = data['vol'].rolling(window=20, min_periods=1).mean()
    
    # 1. 价值因子
    data['min_252'] = data['low'].rolling(window=252, min_periods=1).min()
    part1 = 0.5 * (1 - (data['close'] - data['min_252']) / data['min_252'])
    part2 = 0.5 * (data['vol'] / data['mean_vol_20'] - 1)
    data['value_factor'] = part1 + part2
    
    # 2. 动量因子
    price_126 = data['close'].shift(126)
    momentum_base = data['close'] / price_126 - 1
    part1_mom = 0.7 * momentum_base
    part2_mom = 0.3 * momentum_base * (data['vol'] / data['mean_vol_20'])
    data['mom_factor'] = part1_mom + part2_mom
    
    # 3. 波动率因子
    data['volatility'] = data['return'].rolling(window=20, min_periods=1).std()
    
    return data

def normalize_factors(df):
    """
    对因子进行Z-score标准化
    """
    data = df.copy()
    
    # 需要标准化的因子列表
    factor_cols = ['value_factor', 'mom_factor', 'volatility']
    
    # 对每个因子进行252天窗口的Z-score标准化
    for col in factor_cols:
        if col in data.columns:
            # 计算滚动均值和标准差（252天窗口）
            rolling_mean = data[col].rolling(window=252, min_periods=1).mean()
            rolling_std = data[col].rolling(window=252, min_periods=1).std()
            
            # 避免除零错误
            rolling_std = rolling_std.replace(0, 1)
            
            # 标准化
            data[f'{col}_norm'] = (data[col] - rolling_mean) / rolling_std
    
    return data

def split_data(df, train_end='2020-12-31', val_end='2023-12-31'):
    """
    按时间顺序分割数据集
    """
    train_df = df[df['trade_date'] <= train_end].copy()
    val_df = df[(df['trade_date'] > train_end) & (df['trade_date'] <= val_end)].copy()
    test_df = df[df['trade_date'] > val_end].copy()
    
    return train_df, val_df, test_df

def prepare_feature_matrix(df):
    """
    准备特征矩阵
    """
    # 选择标准化后的因子作为特征
    feature_cols = ['value_factor_norm', 'mom_factor_norm', 'volatility_norm']
    
    # 检查是否存在这些列
    available_cols = [col for col in feature_cols if col in df.columns]
    
    # 提取特征矩阵
    X = df[available_cols].copy()
    
    return X

def simple_linear_model(X_train, y_train):
    """
    简单线性模型（避免复杂的XGBoost依赖问题）
    """
    # 移除目标变量中的NaN值
    mask = ~y_train.isna()
    X_train_clean = X_train[mask]
    y_train_clean = y_train[mask]
    
    # 使用简单的线性回归
    # 这里我们使用加权平均作为简化模型
    weights = np.array([0.4, 0.4, 0.2])  # 为三个因子分配权重
    
    # 确保权重数量与特征数量匹配
    if len(weights) > X_train_clean.shape[1]:
        weights = weights[:X_train_clean.shape[1]]
    elif len(weights) < X_train_clean.shape[1]:
        # 如果权重数量不足，平均分配剩余权重
        remaining_weight = 1.0 - np.sum(weights)
        additional_weights = np.full(X_train_clean.shape[1] - len(weights), 
                                   remaining_weight / (X_train_clean.shape[1] - len(weights)))
        weights = np.concatenate([weights, additional_weights])
    
    return weights

def predict_with_model(model, X):
    """
    使用简单模型进行预测
    """
    # 进行加权预测
    predictions = np.dot(X.values, model)
    return predictions

def save_model(model, filepath='model.pkl'):
    """
    保存模型参数
    """
    with open(filepath, 'wb') as f:
        pickle.dump(model, f)

def calculate_regression_metrics(y_true, y_pred):
    """
    计算回归评估指标
    """
    # 移除NaN值
    mask = ~(np.isnan(y_true) | np.isnan(y_pred))
    y_true_clean = y_true[mask]
    y_pred_clean = y_pred[mask]
    
    # 计算评估指标
    mae = np.mean(np.abs(y_true_clean - y_pred_clean))
    mse = np.mean((y_true_clean - y_pred_clean) ** 2)
    rmse = np.sqrt(mse)
    r2 = 1 - (np.sum((y_true_clean - y_pred_clean) ** 2) / 
              np.sum((y_true_clean - np.mean(y_true_clean)) ** 2))
    
    metrics = {
        'MAE': mae,
        'MSE': mse,
        'RMSE': rmse,
        'R²': r2
    }
    
    return metrics

def calculate_financial_metrics(returns, predictions):
    """
    计算金融评估指标
    """
    # 移除NaN值
    mask = ~(np.isnan(returns) | np.isnan(predictions))
    returns_clean = returns[mask]
    predictions_clean = predictions[mask]
    
    # 基于预测信号的策略收益（预测大于0做多，小于0做空）
    signals = np.where(predictions_clean > 0, 1, -1)
    strategy_returns = signals * returns_clean
    
    # 计算夏普比率（假设无风险利率为0）
    sharpe_ratio = np.mean(strategy_returns) / np.std(strategy_returns) * np.sqrt(252) if np.std(strategy_returns) > 0 else 0
    
    # 计算最大回撤
    cumulative_strategy = (1 + strategy_returns).cumprod()
    peak = np.maximum.accumulate(cumulative_strategy)
    drawdown = (peak - cumulative_strategy) / peak
    max_drawdown = np.max(drawdown)
    
    # 计算总收益
    total_return = cumulative_strategy[-1] - 1
    
    metrics = {
        'Sharpe Ratio': sharpe_ratio,
        'Max Drawdown': max_drawdown,
        'Total Return': total_return
    }
    
    return metrics, strategy_returns, returns_clean

def generate_simple_shap_values(X, weights):
    """
    简化版SHAP值计算（基于线性模型权重）
    """
    # 对于线性模型，SHAP值可以近似为特征值乘以权重
    shap_values = X.values * weights
    return shap_values

def generate_trading_signals(dates, predictions, shap_values, X, value_threshold=0.1, mom_threshold=0.1, pred_threshold=0.05):
    """
    根据预测结果和SHAP值生成交易信号
    """
    # 创建信号数据框
    signals_df = pd.DataFrame({
        'date': dates.reset_index(drop=True),
        'prediction': predictions,
        'signal': 'hold',  # 默认持有
        'trigger_factor': '',  # 触发因子
        'delta_shap': 0.0,  # SHAP变化值
        'pred_return': predictions
    })
    
    # 获取特征名称
    feature_names = X.columns.tolist()
    
    # 查找价值因子和动量因子的索引
    value_idx = None
    mom_idx = None
    for i, name in enumerate(feature_names):
        if 'value' in name.lower():
            value_idx = i
        elif 'mom' in name.lower():
            mom_idx = i
    
    # 计算SHAP值变化（相邻时间点的差异）
    shap_changes = np.zeros_like(shap_values)
    if len(shap_values) > 1:
        shap_changes[1:] = np.abs(shap_values[1:] - shap_values[:-1])
    
    # 生成交易信号
    for i in range(len(signals_df)):
        # 获取当前预测值
        pred = predictions[i] if i < len(predictions) else 0
        
        # 获取当前SHAP变化值
        current_shap_changes = shap_changes[i] if i < len(shap_changes) else np.zeros(len(feature_names))
        
        # 初始化信号和触发因子
        signal = 'hold'
        trigger_factor = ''
        delta_shap = 0.0
        
        # 检查是否满足信号条件
        if value_idx is not None and i < len(current_shap_changes):
            value_shap_change = current_shap_changes[value_idx]
            # 价值因子SHAP增加超过阈值，买入信号
            if value_shap_change > value_threshold:
                signal = 'buy'
                trigger_factor = 'value_factor'
                delta_shap = value_shap_change
        
        if mom_idx is not None and i < len(current_shap_changes) and signal == 'hold':
            mom_shap_change = current_shap_changes[mom_idx]
            # 动量因子SHAP减少超过阈值，卖出信号
            if mom_shap_change > mom_threshold:
                signal = 'sell'
                trigger_factor = 'mom_factor'
                delta_shap = mom_shap_change
        
        # 如果还没有信号，基于预测收益生成信号
        if signal == 'hold':
            if pred > pred_threshold:
                signal = 'buy'
                trigger_factor = 'prediction'
                delta_shap = pred
            elif pred < -pred_threshold:
                signal = 'sell'
                trigger_factor = 'prediction'
                delta_shap = abs(pred)
        
        # 更新信号数据框
        signals_df.loc[i, 'signal'] = signal
        signals_df.loc[i, 'trigger_factor'] = trigger_factor
        signals_df.loc[i, 'delta_shap'] = delta_shap
    
    return signals_df

def save_signals_to_csv(signals_df, filename='signals.csv'):
    """
    将信号保存到CSV文件
    """
    # 保存到CSV文件
    signals_df.to_csv(filename, index=False)

def plot_cumulative_returns(strategy_returns, benchmark_returns, filename='plots/cumulative_returns.png'):
    """
    绘制累计收益曲线
    """
    # 计算累计收益
    cumulative_strategy = (1 + strategy_returns).cumprod()
    cumulative_benchmark = (1 + benchmark_returns).cumprod()
    
    # 创建图表
    plt.figure(figsize=(12, 6))
    plt.plot(cumulative_strategy, label='Strategy')
    plt.plot(cumulative_benchmark, label='Benchmark')
    plt.title('Cumulative Returns')
    plt.xlabel('Time')
    plt.ylabel('Cumulative Return')
    plt.legend()
    plt.grid(True)
    
    # 保存图表
    plt.savefig(filename)
    plt.close()

def plot_prediction_scatter(y_true, y_pred, filename='plots/prediction_scatter.png'):
    """
    绘制预测值vs实际值散点图
    """
    # 移除NaN值
    mask = ~(np.isnan(y_true) | np.isnan(y_pred))
    y_true_clean = y_true[mask]
    y_pred_clean = y_pred[mask]
    
    # 创建图表
    plt.figure(figsize=(8, 6))
    plt.scatter(y_true_clean, y_pred_clean, alpha=0.5)
    plt.xlabel('Actual Returns')
    plt.ylabel('Predicted Returns')
    plt.title('Prediction vs Actual')
    plt.grid(True)
    
    # 添加对角线
    min_val = min(min(y_true_clean), min(y_pred_clean))
    max_val = max(max(y_true_clean), max(y_pred_clean))
    plt.plot([min_val, max_val], [min_val, max_val], 'r--')
    
    # 保存图表
    plt.savefig(filename)
    plt.close()

def plot_shap_summary(shap_values, feature_names, filename='plots/shap_summary.png'):
    """
    绘制SHAP摘要图
    """
    # 计算每个特征的SHAP值均值
    mean_shap_values = np.mean(np.abs(shap_values), axis=0)
    
    # 创建图表
    plt.figure(figsize=(10, 6))
    y_pos = np.arange(len(feature_names))
    plt.barh(y_pos, mean_shap_values)
    plt.yticks(y_pos, feature_names)
    plt.xlabel('Mean |SHAP Value|')
    plt.title('SHAP Summary Plot')
    plt.grid(True)
    
    # 保存图表
    plt.savefig(filename)
    plt.close()

def main():
    """
    主函数：执行完整的量价价值+动量因子模型预测流程（完全独立版）
    """
    # 设置日志
    logger = setup_logging()
    logger.info("========== 量价价值+动量因子模型预测系统（完全独立版） ==========")
    
    # 确保必要的目录存在
    ensure_dir_exists('plots')
    
    try:
        # 1. 生成演示数据
        logger.info("步骤1: 生成演示数据")
        df = generate_demo_data()
        
        # 分割数据集
        train_df, val_df, test_df = split_data(df, train_end='2020-12-31', val_end='2023-12-31')
        
        # 2. 因子工程
        logger.info("步骤2: 因子工程")
        # 计算因子
        train_df = calculate_factors(train_df)
        val_df = calculate_factors(val_df)
        test_df = calculate_factors(test_df)
        
        # 因子标准化
        train_df = normalize_factors(train_df)
        val_df = normalize_factors(val_df)
        test_df = normalize_factors(test_df)
        
        # 准备特征矩阵
        X_train = prepare_feature_matrix(train_df)
        X_val = prepare_feature_matrix(val_df)
        X_test = prepare_feature_matrix(test_df)
        
        # 准备目标变量
        y_train = train_df['target']
        y_val = val_df['target']
        y_test = test_df['target']
        
        # 3. 模型训练
        logger.info("步骤3: 模型训练")
        # 训练简化模型
        model = simple_linear_model(X_train, y_train)
        
        # 保存模型
        save_model(model, 'model.pkl')
        
        # 4. 模型预测
        logger.info("步骤4: 模型预测")
        # 在测试集上进行预测
        test_predictions = predict_with_model(model, X_test)
        
        # 5. 模型评估
        logger.info("步骤5: 模型评估")
        # 计算回归评估指标
        regression_metrics = calculate_regression_metrics(y_test, test_predictions)
        
        # 计算金融评估指标
        financial_metrics, strategy_returns, benchmark_returns = calculate_financial_metrics(
            test_df['return'].values, test_predictions)
        
        # 绘制累计收益曲线
        plot_cumulative_returns(strategy_returns, benchmark_returns, 'plots/cumulative_returns.png')
        
        # 绘制预测值vs实际值散点图
        plot_prediction_scatter(y_test.values, test_predictions, 'plots/prediction_scatter.png')
        
        # 6. 简化版SHAP解释
        logger.info("步骤6: 简化版SHAP解释")
        # 计算简化版SHAP值
        shap_values = generate_simple_shap_values(X_test, model)
        
        # 绘制SHAP摘要图
        plot_shap_summary(shap_values, X_test.columns.tolist(), 'plots/shap_summary.png')
        
        # 7. 信号生成
        logger.info("步骤7: 信号生成")
        # 生成交易信号
        test_dates = test_df['trade_date']
        signals_df = generate_trading_signals(
            test_dates, test_predictions, shap_values, X_test,
            value_threshold=0.1, mom_threshold=0.1, pred_threshold=0.05)
        
        # 保存信号到CSV
        save_signals_to_csv(signals_df, 'signals.csv')
        
        logger.info("========== 执行完成 ==========")
        print("模型训练、评估和信号生成已完成！")
        print("请查看以下输出文件：")
        print("- evaluation_report.txt: 模型评估报告")
        print("- model.pkl: 训练好的模型")
        print("- signals.csv: 生成的交易信号")
        print("- plots/: 包含各种分析图表")
        
    except Exception as e:
        logger.error(f"程序执行出错: {str(e)}")
        raise

if __name__ == "__main__":
    main()