import pandas as pd
import numpy as np
import logging

def calculate_factors(df):
    """
    计算价值因子、动量因子和波动率因子
    
    Parameters:
    df (pd.DataFrame): 包含价格和成交量数据的数据框
    
    Returns:
    pd.DataFrame: 包含原始数据和计算因子的数据框
    """
    logger = logging.getLogger(__name__)
    logger.info("开始计算因子...")
    
    # 创建数据副本
    data = df.copy()
    
    # 计算20日平均成交量
    data['mean_vol_20'] = data['vol'].rolling(window=20, min_periods=1).mean()
    
    # 1. 价值因子 value_factor = 0.5*(1 - (close - min_252)/min_252) + 0.5*(vol/mean_vol_20 - 1)
    # 计算252天最低价
    data['min_252'] = data['low'].rolling(window=252, min_periods=1).min()
    # 计算价值因子的第一部分
    part1 = 0.5 * (1 - (data['close'] - data['min_252']) / data['min_252'])
    # 计算价值因子的第二部分
    part2 = 0.5 * (data['vol'] / data['mean_vol_20'] - 1)
    # 合成价值因子
    data['value_factor'] = part1 + part2
    
    # 2. 动量因子 mom_factor = 0.7*(close/close.shift(126)-1) + 0.3*(close/close.shift(126)-1)*(vol/mean_vol_20)
    # 计算126天前的价格
    price_126 = data['close'].shift(126)
    # 计算基础动量
    momentum_base = data['close'] / price_126 - 1
    # 计算动量因子的第一部分
    part1_mom = 0.7 * momentum_base
    # 计算动量因子的第二部分
    part2_mom = 0.3 * momentum_base * (data['vol'] / data['mean_vol_20'])
    # 合成动量因子
    data['mom_factor'] = part1_mom + part2_mom
    
    # 3. 波动率因子 volatility = return.rolling(20).std()
    data['volatility'] = data['return'].rolling(window=20, min_periods=1).std()
    
    logger.info("因子计算完成")
    return data

def normalize_factors(df):
    """
    对因子进行Z-score标准化
    
    Parameters:
    df (pd.DataFrame): 包含因子的数据框
    
    Returns:
    pd.DataFrame: 标准化后的因子数据
    """
    logger = logging.getLogger(__name__)
    logger.info("开始对因子进行Z-score标准化...")
    
    # 创建数据副本
    data = df.copy()
    
    # 需要标准化的因子列表
    factor_cols = ['value_factor', 'mom_factor', 'volatility']
    
    # 对每个因子进行252天窗口的Z-score标准化
    for col in factor_cols:
        if col in data.columns:
            # 计算滚动均值和标准差（252天窗口）
            rolling_mean = data[col].rolling(window=252, min_periods=1).mean()
            rolling_std = data[col].rolling(window=252, min_periods=1).std()
            
            # 避免除零错误
            rolling_std = rolling_std.replace(0, 1)
            
            # 标准化
            data[f'{col}_norm'] = (data[col] - rolling_mean) / rolling_std
    
    logger.info("因子标准化完成")
    return data

def prepare_feature_matrix(df):
    """
    准备特征矩阵
    
    Parameters:
    df (pd.DataFrame): 包含标准化因子的数据框
    
    Returns:
    pd.DataFrame: 只包含特征列的数据框
    """
    logger = logging.getLogger(__name__)
    
    # 选择标准化后的因子作为特征
    feature_cols = ['value_factor_norm', 'mom_factor_norm', 'volatility_norm']
    
    # 检查是否存在这些列
    available_cols = [col for col in feature_cols if col in df.columns]
    
    if len(available_cols) != len(feature_cols):
        logger.warning(f"部分特征列缺失，仅使用可用列: {available_cols}")
    
    # 提取特征矩阵
    X = df[available_cols].copy()
    
    logger.info(f"特征矩阵准备完成，形状: {X.shape}")
    return X