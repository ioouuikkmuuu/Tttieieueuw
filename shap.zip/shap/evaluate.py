import pandas as pd
import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import seaborn as sns
import logging

def calculate_regression_metrics(y_true, y_pred):
    """
    计算回归评估指标
    
    Parameters:
    y_true (array-like): 真实值
    y_pred (array-like): 预测值
    
    Returns:
    dict: 包含评估指标的字典
    """
    logger = logging.getLogger(__name__)
    logger.info("计算回归评估指标...")
    
    # 移除NaN值
    mask = ~(np.isnan(y_true) | np.isnan(y_pred))
    y_true_clean = y_true[mask]
    y_pred_clean = y_pred[mask]
    
    # 计算评估指标
    mae = mean_absolute_error(y_true_clean, y_pred_clean)
    mse = mean_squared_error(y_true_clean, y_pred_clean)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_true_clean, y_pred_clean)
    
    metrics = {
        'MAE': mae,
        'MSE': mse,
        'RMSE': rmse,
        'R²': r2
    }
    
    logger.info("回归评估指标计算完成")
    return metrics

def calculate_financial_metrics(returns, predictions):
    """
    计算金融评估指标
    
    Parameters:
    returns (array-like): 实际收益率
    predictions (array-like): 预测收益率
    
    Returns:
    dict: 包含金融评估指标的字典
    """
    logger = logging.getLogger(__name__)
    logger.info("计算金融评估指标...")
    
    # 移除NaN值
    mask = ~(np.isnan(returns) | np.isnan(predictions))
    returns_clean = returns[mask]
    predictions_clean = predictions[mask]
    
    # 基于预测信号的策略收益（预测大于0做多，小于0做空）
    signals = np.where(predictions_clean > 0, 1, -1)
    strategy_returns = signals * returns_clean
    
    # 计算累计收益
    cumulative_strategy = (1 + strategy_returns).cumprod()
    cumulative_benchmark = (1 + returns_clean).cumprod()
    
    # 计算夏普比率（假设无风险利率为0）
    sharpe_ratio = np.mean(strategy_returns) / np.std(strategy_returns) * np.sqrt(252) if np.std(strategy_returns) > 0 else 0
    
    # 计算最大回撤
    peak = np.maximum.accumulate(cumulative_strategy)
    drawdown = (peak - cumulative_strategy) / peak
    max_drawdown = np.max(drawdown)
    
    # 计算总收益
    total_return = cumulative_strategy[-1] - 1
    benchmark_return = cumulative_benchmark[-1] - 1
    
    metrics = {
        'Sharpe Ratio': sharpe_ratio,
        'Max Drawdown': max_drawdown,
        'Total Return': total_return,
        'Benchmark Return': benchmark_return
    }
    
    logger.info("金融评估指标计算完成")
    return metrics, strategy_returns, returns_clean

def plot_cumulative_returns(strategy_returns, benchmark_returns, dates=None, title="Cumulative Returns Comparison"):
    """
    绘制累计收益曲线
    
    Parameters:
    strategy_returns (array-like): 策略收益
    benchmark_returns (array-like): 基准收益
    dates (array-like): 日期数组，用于x轴显示
    title (str): 图表标题
    """
    logger = logging.getLogger(__name__)
    logger.info("绘制累计收益曲线...")
    
    # 计算累计收益
    cumulative_strategy = (1 + strategy_returns).cumprod()
    cumulative_benchmark = (1 + benchmark_returns).cumprod()
    
    # 绘图
    plt.figure(figsize=(12, 6))
    if dates is not None:
        # 转换日期格式
        date_index = pd.to_datetime(dates)
        plt.plot(date_index, cumulative_strategy, label='Predicted Strategy', linewidth=2)
        plt.plot(date_index, cumulative_benchmark, label='Buy and Hold Benchmark', linewidth=2)
        
        # 设置时间轴格式
        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
        plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=3))
        plt.xticks(rotation=45)
    else:
        plt.plot(cumulative_strategy, label='Predicted Strategy', linewidth=2)
        plt.plot(cumulative_benchmark, label='Buy and Hold Benchmark', linewidth=2)
    
    plt.title(title)
    plt.xlabel('Time')
    plt.ylabel('Cumulative Returns')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig('plots/cumulative_returns.png')
    plt.close()
    
    logger.info("累计收益曲线绘制完成")

def plot_prediction_scatter(y_true, y_pred, title="Predicted vs Actual Returns"):
    """
    绘制预测值与实际值的散点图
    
    Parameters:
    y_true (array-like): 真实值
    y_pred (array-like): 预测值
    title (str): 图表标题
    """
    logger = logging.getLogger(__name__)
    logger.info("绘制预测值与实际值散点图...")
    
    # 移除NaN值
    mask = ~(np.isnan(y_true) | np.isnan(y_pred))
    y_true_clean = y_true[mask]
    y_pred_clean = y_pred[mask]
    
    # 绘图
    plt.figure(figsize=(10, 8))
    plt.scatter(y_true_clean, y_pred_clean, alpha=0.6)
    plt.xlabel('Actual Returns')
    plt.ylabel('Predicted Returns')
    plt.title(title)
    # 添加y=x参考线
    min_val = min(min(y_true_clean), min(y_pred_clean))
    max_val = max(max(y_true_clean), max(y_pred_clean))
    plt.plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=1)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig('plots/prediction_scatter.png')
    plt.close()
    
    logger.info("预测值与实际值散点图绘制完成")

def generate_evaluation_report(regression_metrics, financial_metrics):
    """
    生成评估报告
    
    Parameters:
    regression_metrics (dict): 回归评估指标
    financial_metrics (dict): 金融评估指标
    
    Returns:
    str: 评估报告文本
    """
    logger = logging.getLogger(__name__)
    logger.info("生成评估报告...")
    
    report = "========== 模型评估报告 ==========\n\n"
    
    report += "1. 回归评估指标:\n"
    for metric, value in regression_metrics.items():
        report += f"   {metric}: {value:.6f}\n"
    
    report += "\n2. 金融评估指标:\n"
    for metric, value in financial_metrics.items():
        if isinstance(value, float):
            report += f"   {metric}: {value:.6f}\n"
        else:
            report += f"   {metric}: {value}\n"
    
    # 添加模型性能判断
    sharpe_ratio = financial_metrics.get('Sharpe Ratio', 0)
    if sharpe_ratio > 0.5:
        report += "\n结论: 模型表现良好 (Sharpe Ratio > 0.5)\n"
    else:
        report += "\n结论: 模型表现一般 (Sharpe Ratio <= 0.5)\n"
    
    report += "================================\n"
    
    logger.info("评估报告生成完成")
    return report