import pandas as pd
import numpy as np
import logging
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

def generate_trading_signals(dates, predictions, shap_values, X, value_threshold=0.01, mom_threshold=0.01, pred_threshold=0.05):
    """
    根据预测结果和SHAP值生成交易信号
    
    Parameters:
    dates (pd.Series): 日期序列
    predictions (np.array): 预测收益
    shap_values (np.array): SHAP值
    X (pd.DataFrame): 特征矩阵
    value_threshold (float): 价值因子SHAP变化阈值
    mom_threshold (float): 动量因子SHAP变化阈值
    pred_threshold (float): 预测收益阈值
    
    Returns:
    pd.DataFrame: 交易信号数据框
    """
    logger = logging.getLogger(__name__)
    logger.info("开始生成交易信号...")
    
    # 创建信号数据框
    signals_df = pd.DataFrame({
        'date': dates.reset_index(drop=True),
        'prediction': predictions,
        'signal': 'hold',  # 默认持有
        'trigger_factor': '',  # 触发因子
        'delta_shap': 0.0,  # SHAP变化值
        'pred_return': predictions
    })
    
    # 获取特征名称
    feature_names = X.columns.tolist()
    
    # 查找价值因子和动量因子的索引
    value_idx = None
    mom_idx = None
    for i, name in enumerate(feature_names):
        if 'value' in name.lower():
            value_idx = i
        elif 'mom' in name.lower():
            mom_idx = i
    
    # 计算SHAP值变化（相邻时间点的差异）
    shap_changes = np.zeros_like(shap_values)
    if len(shap_values) > 1:
        shap_changes[1:] = np.abs(shap_values[1:] - shap_values[:-1])
    
    # 生成交易信号
    for i in range(len(signals_df)):
        # 获取当前预测值
        pred = predictions[i] if i < len(predictions) else 0
        
        # 获取当前SHAP变化值
        current_shap_changes = shap_changes[i] if i < len(shap_changes) else np.zeros(len(feature_names))
        
        # 初始化信号和触发因子
        signal = 'hold'
        trigger_factor = ''
        delta_shap = 0.0
        
        # 检查是否满足信号条件
        if value_idx is not None and i < len(current_shap_changes):
            value_shap_change = current_shap_changes[value_idx]
            # 添加调试信息
            if i < 5:  # 只打印前5个样本的调试信息
                logger.debug(f"样本 {i}: 价值因子SHAP变化={value_shap_change}, 阈值={value_threshold}")
            # 价值因子SHAP增加超过阈值，买入信号
            if value_shap_change > value_threshold:
                signal = 'buy'
                trigger_factor = 'value_factor'
                delta_shap = value_shap_change
                if i < 5:  # 只打印前5个样本的调试信息
                    logger.debug(f"样本 {i}: 触发买入信号, SHAP变化={value_shap_change}")
        
        if mom_idx is not None and i < len(current_shap_changes) and signal == 'hold':
            mom_shap_change = current_shap_changes[mom_idx]
            # 添加调试信息
            if i < 5:  # 只打印前5个样本的调试信息
                logger.debug(f"样本 {i}: 动量因子SHAP变化={mom_shap_change}, 阈值={mom_threshold}")
            # 动量因子SHAP减少超过阈值，卖出信号
            if mom_shap_change > mom_threshold:
                signal = 'sell'
                trigger_factor = 'mom_factor'
                delta_shap = mom_shap_change
                if i < 5:  # 只打印前5个样本的调试信息
                    logger.debug(f"样本 {i}: 触发卖出信号, SHAP变化={mom_shap_change}")
        
        # 如果还没有信号，基于预测收益生成信号
        if signal == 'hold':
            if pred > pred_threshold:
                signal = 'buy'
                trigger_factor = 'prediction'
                delta_shap = pred
            elif pred < -pred_threshold:
                signal = 'sell'
                trigger_factor = 'prediction'
                delta_shap = abs(pred)
        
        # 更新信号数据框
        signals_df.loc[i, 'signal'] = signal
        signals_df.loc[i, 'trigger_factor'] = trigger_factor
        signals_df.loc[i, 'delta_shap'] = delta_shap
    
    logger.info(f"交易信号生成完成，共生成{len(signals_df)}个信号")
    return signals_df

def filter_significant_signals(signals_df, min_delta_shap=0.01):
    """
    过滤出具有显著SHAP变化的信号
    
    Parameters:
    signals_df (pd.DataFrame): 信号数据框
    min_delta_shap (float): 最小SHAP变化阈值
    
    Returns:
    pd.DataFrame: 过滤后的信号数据框
    """
    logger = logging.getLogger(__name__)
    logger.info("过滤显著信号...")
    
    # 过滤条件：非持有信号且SHAP变化大于阈值
    filtered_signals = signals_df[
        (signals_df['signal'] != 'hold') & 
        (signals_df['delta_shap'] >= min_delta_shap)
    ].copy()
    
    logger.info(f"过滤完成，剩余{len(filtered_signals)}个显著信号")
    return filtered_signals

def save_signals_to_csv(signals_df, filename='signals.csv'):
    """
    将信号保存到CSV文件
    
    Parameters:
    signals_df (pd.DataFrame): 信号数据框
    filename (str): 文件名
    """
    logger = logging.getLogger(__name__)
    logger.info(f"保存信号到 {filename}...")
    
    # 保存到CSV文件
    signals_df.to_csv(filename, index=False)
    
    logger.info("信号保存完成")

def analyze_signal_performance(signals_df, returns):
    """
    分析信号表现
    
    Parameters:
    signals_df (pd.DataFrame): 信号数据框
    returns (pd.Series): 实际收益序列
    
    Returns:
    dict: 表现分析结果
    """
    logger = logging.getLogger(__name__)
    logger.info("分析信号表现...")
    
    # 合并信号和收益数据
    analysis_df = signals_df.merge(
        pd.DataFrame({'date': signals_df['date'], 'return': returns}), 
        on='date', 
        how='left'
    )
    
    # 计算不同信号后的平均收益
    buy_signals = analysis_df[analysis_df['signal'] == 'buy']
    sell_signals = analysis_df[analysis_df['signal'] == 'sell']
    
    performance = {
        'total_signals': len(analysis_df),
        'buy_signals': len(buy_signals),
        'sell_signals': len(sell_signals),
        'avg_return_buy': buy_signals['return'].mean() if len(buy_signals) > 0 else 0,
        'avg_return_sell': sell_signals['return'].mean() if len(sell_signals) > 0 else 0,
        'win_rate_buy': (buy_signals['return'] > 0).mean() if len(buy_signals) > 0 else 0,
        'win_rate_sell': (sell_signals['return'] < 0).mean() if len(sell_signals) > 0 else 0
    }
    
    logger.info("信号表现分析完成")
    return performance

def plot_signal_returns(signals_df, returns, title="Signal-Based Returns"):
    """
    绘制基于信号的收益曲线
    
    Parameters:
    signals_df (pd.DataFrame): 信号数据框
    returns (pd.Series): 实际收益序列
    title (str): 图表标题
    """
    logger = logging.getLogger(__name__)
    logger.info("绘制信号收益曲线...")
    
    # 合并信号和收益数据
    analysis_df = signals_df.merge(
        pd.DataFrame({'date': signals_df['date'], 'return': returns}), 
        on='date', 
        how='left'
    )
    
    # 基于信号计算策略收益
    analysis_df['position'] = analysis_df['signal'].map({'buy': 1, 'sell': -1, 'hold': 0})
    analysis_df['strategy_return'] = analysis_df['position'] * analysis_df['return']
    
    # 计算累计收益
    cumulative_strategy = (1 + analysis_df['strategy_return']).cumprod()
    cumulative_benchmark = (1 + analysis_df['return']).cumprod()
    
    # 转换日期格式
    dates = pd.to_datetime(analysis_df['date'])
    
    # 绘图
    plt.figure(figsize=(12, 6))
    plt.plot(dates, cumulative_strategy, label='Signal-Based Strategy', linewidth=2)
    plt.plot(dates, cumulative_benchmark, label='Buy and Hold Benchmark', linewidth=2)
    
    # 设置时间轴格式
    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
    plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=3))
    plt.xticks(rotation=45)
    
    plt.title(title)
    plt.xlabel('Time')
    plt.ylabel('Cumulative Returns')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig('plots/signal_returns.png')
    plt.close()
    
    logger.info("信号收益曲线绘制完成")