import pandas as pd
import numpy as np
from sklearn.model_selection import TimeSeriesSplit, GridSearchCV
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import xgboost as xgb
import logging
import pickle

def train_xgboost_model(X_train, y_train, X_val=None, y_val=None):
    """
    训练XGBoost回归模型
    
    Parameters:
    X_train (pd.DataFrame): 训练特征
    y_train (pd.Series): 训练标签
    X_val (pd.DataFrame): 验证特征（可选）
    y_val (pd.Series): 验证标签（可选）
    
    Returns:
    xgb.XGBRegressor: 训练好的模型
    """
    logger = logging.getLogger(__name__)
    logger.info("开始训练XGBoost模型...")
    
    # 移除目标变量中的NaN值
    mask = ~y_train.isna()
    X_train_clean = X_train[mask]
    y_train_clean = y_train[mask]
    
    # 设置模型参数
    params = {
        'n_estimators': 200,
        'max_depth': 5,
        'learning_rate': 0.05,
        'subsample': 0.8,
        'random_state': 42,
        'base_score': 0.0
    }
    
    # 创建XGBoost回归器
    model = xgb.XGBRegressor(**params)
    
    # 如果提供了验证集，使用早停
    if X_val is not None and y_val is not None:
        # 移除验证集中的NaN值
        mask_val = ~y_val.isna()
        X_val_clean = X_val[mask_val]
        y_val_clean = y_val[mask_val]
        
        logger.info("使用验证集进行训练和早停...")
        model.fit(
            X_train_clean, y_train_clean,
            eval_set=[(X_val_clean, y_val_clean)],
            verbose=False
        )
    else:
        # 仅使用训练集训练
        logger.info("仅使用训练集进行训练...")
        model.fit(X_train_clean, y_train_clean)
    
    logger.info("模型训练完成")
    return model

def cross_validate_model(X, y, cv_folds=5):
    """
    使用时间序列交叉验证评估模型
    
    Parameters:
    X (pd.DataFrame): 特征矩阵
    y (pd.Series): 目标变量
    cv_folds (int): 交叉验证折数
    
    Returns:
    dict: 包含评估指标的字典
    """
    logger = logging.getLogger(__name__)
    logger.info(f"开始{cv_folds}折时间序列交叉验证...")
    
    # 移除目标变量中的NaN值
    mask = ~y.isna()
    X_clean = X[mask]
    y_clean = y[mask]
    
    # 创建时间序列交叉验证对象
    tscv = TimeSeriesSplit(n_splits=cv_folds)
    
    # 存储每折的评估结果
    mae_scores = []
    mse_scores = []
    r2_scores = []
    
    fold = 1
    for train_index, val_index in tscv.split(X_clean):
        logger.info(f"正在训练第{fold}折...")
        
        # 分割数据
        X_train_fold, X_val_fold = X_clean.iloc[train_index], X_clean.iloc[val_index]
        y_train_fold, y_val_fold = y_clean.iloc[train_index], y_clean.iloc[val_index]
        
        # 训练模型
        model = xgb.XGBRegressor(n_estimators=200, max_depth=5, learning_rate=0.05, subsample=0.8, random_state=42)
        model.fit(X_train_fold, y_train_fold, verbose=False)
        
        # 预测
        y_pred = model.predict(X_val_fold)
        
        # 计算评估指标
        mae_scores.append(mean_absolute_error(y_val_fold, y_pred))
        mse_scores.append(mean_squared_error(y_val_fold, y_pred))
        r2_scores.append(r2_score(y_val_fold, y_pred))
        
        fold += 1
    
    # 计算平均评估指标
    results = {
        'mae_mean': np.mean(mae_scores),
        'mae_std': np.std(mae_scores),
        'mse_mean': np.mean(mse_scores),
        'mse_std': np.std(mse_scores),
        'r2_mean': np.mean(r2_scores),
        'r2_std': np.std(r2_scores)
    }
    
    logger.info("交叉验证完成")
    return results

def predict_with_model(model, X):
    """
    使用训练好的模型进行预测
    
    Parameters:
    model: 训练好的模型
    X (pd.DataFrame): 特征矩阵
    
    Returns:
    np.array: 预测结果
    """
    logger = logging.getLogger(__name__)
    logger.info("开始使用模型进行预测...")
    
    # 进行预测
    predictions = model.predict(X)
    
    logger.info("预测完成")
    return predictions

def save_model(model, filepath='model.pkl'):
    """
    保存训练好的模型
    
    Parameters:
    model: 训练好的模型
    filepath (str): 模型保存路径
    """
    logger = logging.getLogger(__name__)
    logger.info(f"正在保存模型到 {filepath}...")
    
    with open(filepath, 'wb') as f:
        pickle.dump(model, f)
    
    logger.info("模型保存完成")

def load_model(filepath='model.pkl'):
    """
    加载保存的模型
    
    Parameters:
    filepath (str): 模型文件路径
    
    Returns:
    model: 加载的模型
    """
    logger = logging.getLogger(__name__)
    logger.info(f"正在从 {filepath} 加载模型...")
    
    with open(filepath, 'rb') as f:
        model = pickle.load(f)
    
    logger.info("模型加载完成")
    return model