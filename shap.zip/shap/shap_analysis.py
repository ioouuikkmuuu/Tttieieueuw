import pandas as pd
import numpy as np
import shap
import matplotlib.pyplot as plt
import seaborn as sns
import logging

def calculate_shap_values(model, X):
    """
    计算模型的SHAP值
    
    Parameters:
    model: 训练好的模型
    X (pd.DataFrame): 特征矩阵
    
    Returns:
    tuple: (shap_values, explainer)
    """
    logger = logging.getLogger(__name__)
    logger.info("开始计算SHAP值...")
    
    # 创建SHAP解释器
    try:
        explainer = shap.TreeExplainer(model)
    except Exception as e:
        logger.warning(f"TreeExplainer初始化失败: {e}")
        logger.info("尝试使用LinearExplainer...")
        explainer = shap.LinearExplainer(model, X)
    
    # 计算SHAP值
    shap_values = explainer.shap_values(X)
    
    # 保存SHAP值供后续检查
    np.save('shap_values.npy', shap_values)
    
    logger.info("SHAP值计算完成")
    return shap_values, explainer

def plot_shap_summary(shap_values, X, feature_names=None, max_display=10):
    """
    绘制SHAP摘要图
    
    Parameters:
    shap_values: SHAP值
    X (pd.DataFrame): 特征矩阵
    feature_names (list): 特征名称列表
    max_display (int): 最大显示特征数
    """
    logger = logging.getLogger(__name__)
    logger.info("绘制SHAP摘要图...")
    
    # 如果没有提供特征名称，则使用X的列名
    if feature_names is None:
        feature_names = X.columns.tolist()
    
    # 绘制SHAP摘要图
    plt.figure(figsize=(10, 8))
    shap.summary_plot(shap_values, X.values, feature_names=feature_names, max_display=max_display, show=False)
    plt.tight_layout()
    plt.savefig('plots/shap_summary.png')
    plt.close()
    
    logger.info("SHAP摘要图绘制完成")

def plot_shap_dependence(shap_values, X, feature_names=None, interaction_index=None):
    """
    绘制SHAP依赖图
    
    Parameters:
    shap_values: SHAP值
    X (pd.DataFrame): 特征矩阵
    feature_names (list): 特征名称列表
    interaction_index: 交互特征索引
    """
    logger = logging.getLogger(__name__)
    logger.info("绘制SHAP依赖图...")
    
    # 如果没有提供特征名称，则使用X的列名
    if feature_names is None:
        feature_names = X.columns.tolist()
    
    # 为每个特征绘制依赖图
    for i, feature_name in enumerate(feature_names):
        plt.figure(figsize=(10, 6))
        shap.dependence_plot(i, shap_values, X.values, feature_names=feature_names, 
                           interaction_index=interaction_index, show=False)
        plt.tight_layout()
        plt.savefig(f'plots/shap_dependence_{feature_name}.png')
        plt.close()
    
    logger.info("SHAP依赖图绘制完成")

def calculate_shap_changes(shap_values):
    """
    计算SHAP值的变化
    
    Parameters:
    shap_values: SHAP值
    
    Returns:
    np.array: SHAP值变化的绝对值
    """
    logger = logging.getLogger(__name__)
    logger.info("计算SHAP值变化...")
    
    # 计算相邻时间点SHAP值的差异
    shap_changes = np.abs(np.diff(shap_values, axis=0))
    
    logger.info("SHAP值变化计算完成")
    return shap_changes

def analyze_shap_contributions(shap_values, X, threshold=0.1):
    """
    分析SHAP贡献
    
    Parameters:
    shap_values: SHAP值
    X (pd.DataFrame): 特征矩阵
    threshold (float): 变化阈值
    
    Returns:
    dict: 包含分析结果的字典
    """
    logger = logging.getLogger(__name__)
    logger.info("分析SHAP贡献...")
    
    # 获取特征名称
    feature_names = X.columns.tolist()
    
    # 计算SHAP值变化
    shap_changes = calculate_shap_changes(shap_values)
    
    # 识别变化超过阈值的时间点
    significant_changes = np.any(shap_changes > threshold, axis=1)
    
    # 统计每个特征的显著变化次数
    feature_change_counts = {}
    for i, feature_name in enumerate(feature_names):
        count = np.sum(shap_changes[:, i] > threshold)
        feature_change_counts[feature_name] = count
    
    analysis_result = {
        'significant_changes_count': np.sum(significant_changes),
        'feature_change_counts': feature_change_counts,
        'mean_shap_changes': np.mean(shap_changes, axis=0),
        'max_shap_changes': np.max(shap_changes, axis=0)
    }
    
    logger.info("SHAP贡献分析完成")
    return analysis_result