import tushare as ts
import pandas as pd
import numpy as np
from datetime import datetime
import logging

def fetch_and_preprocess_data(ts_token, start_date='20100101', end_date='20251109'):
    """
    获取并预处理中证800指数数据
    
    Parameters:
    ts_token (str): Tushare token
    start_date (str): 开始日期，格式YYYYMMDD
    end_date (str): 结束日期，格式YYYYMMDD
    
    Returns:
    pd.DataFrame: 预处理后的数据
    """
    logger = logging.getLogger(__name__)
    
    try:
        # 设置Tushare token
        ts.set_token(ts_token)
        pro = ts.pro_api()
        
        # 获取中证800指数数据
        logger.info("正在获取中证800指数数据...")
        df = pro.index_daily(ts_code='000906.SH', start_date=start_date, end_date=end_date)
        
        # 数据预处理
        logger.info("正在进行数据预处理...")
        
        # 按日期排序
        df = df.sort_values('trade_date').reset_index(drop=True)
        
        # 将日期列转换为datetime格式
        df['trade_date'] = pd.to_datetime(df['trade_date'], format='%Y%m%d')
        
        # 处理缺失值 - 向前填充
        df = df.fillna(method='ffill')
        
        # 计算回报率
        df['return'] = df['close'].pct_change()
        
        # 目标变量：下一交易日回报
        df['target'] = df['return'].shift(-1)
        
        logger.info(f"数据获取完成，共获取{len(df)}条记录")
        
        # 保存原始数据到CSV文件
        raw_data_file = 'raw_index_data.csv'
        df.to_csv(raw_data_file, index=False)
        logger.info(f"原始数据已保存到 {raw_data_file}")
        
        return df
    
    except Exception as e:
        logger.error(f"数据获取失败: {str(e)}")
        raise

def split_data(df, train_end='20201231', val_end='20231231'):
    """
    按时间顺序分割数据集
    
    Parameters:
    df (pd.DataFrame): 完整数据集
    train_end (str): 训练集结束日期
    val_end (str): 验证集结束日期
    
    Returns:
    tuple: (train_df, val_df, test_df)
    """
    logger = logging.getLogger(__name__)
    
    # 转换日期字符串为datetime
    train_end_dt = pd.to_datetime(train_end, format='%Y%m%d')
    val_end_dt = pd.to_datetime(val_end, format='%Y%m%d')
    
    # 分割数据
    train_df = df[df['trade_date'] <= train_end_dt].copy()
    val_df = df[(df['trade_date'] > train_end_dt) & (df['trade_date'] <= val_end_dt)].copy()
    test_df = df[df['trade_date'] > val_end_dt].copy()
    
    logger.info(f"数据分割完成:")
    logger.info(f"  训练集: {len(train_df)} 条记录")
    logger.info(f"  验证集: {len(val_df)} 条记录")
    logger.info(f"  测试集: {len(test_df)} 条记录")
    
    return train_df, val_df, test_df

def zscore_normalize(df, window=252):
    """
    对数据进行Z-score标准化
    
    Parameters:
    df (pd.DataFrame): 数据集
    window (int): 滚动窗口大小
    
    Returns:
    pd.DataFrame: 标准化后的数据
    """
    logger = logging.getLogger(__name__)
    
    # 创建副本以避免修改原始数据
    df_norm = df.copy()
    
    # 对价格和成交量进行标准化
    price_cols = ['open', 'high', 'low', 'close']
    volume_cols = ['vol', 'amount']
    
    # 价格标准化
    for col in price_cols:
        if col in df_norm.columns:
            rolling_mean = df_norm[col].rolling(window=window, min_periods=1).mean()
            rolling_std = df_norm[col].rolling(window=window, min_periods=1).std()
            df_norm[f'{col}_norm'] = (df_norm[col] - rolling_mean) / rolling_std
    
    # 成交量标准化
    for col in volume_cols:
        if col in df_norm.columns:
            rolling_mean = df_norm[col].rolling(window=window, min_periods=1).mean()
            rolling_std = df_norm[col].rolling(window=window, min_periods=1).std()
            df_norm[f'{col}_norm'] = (df_norm[col] - rolling_mean) / rolling_std
    
    logger.info(f"已完成Z-score标准化，窗口大小: {window}")
    return df_norm